package outbox_test

import (
	"context"
	"testing"

	outbox "github.com/fineract/cbdc/outbox-relay"
	"github.com/fineract/cbdc/outbox-relay/store"
)

func TestMessageValidation(t *testing.T) {
	s := store.NewMemory()
	if err := s.Append(context.Background(), &outbox.Message{ID: "x"}); err == nil {
		t.Fatal("want validation error for incomplete message")
	}
}

func TestNewMessageDefaults(t *testing.T) {
	m := outbox.NewMessage("payment", "pay-1", "payment.settled", []byte(`{}`))
	if m.ID == "" || m.Status != outbox.StatusPending {
		t.Fatalf("unexpected new message: %+v", m)
	}
	if err := m.Validate(); err != nil {
		t.Fatalf("valid message rejected: %v", err)
	}
}
