package relay_test

import (
	"context"
	"errors"
	"testing"

	outbox "github.com/fineract/cbdc/outbox-relay"
	"github.com/fineract/cbdc/outbox-relay/publisher"
	"github.com/fineract/cbdc/outbox-relay/relay"
	"github.com/fineract/cbdc/outbox-relay/store"
)

func seed(t *testing.T, s *store.Memory, n int) {
	t.Helper()
	for i := 0; i < n; i++ {
		m := outbox.NewMessage("payment", "pay-1", "payment.settled", []byte(`{"ok":true}`))
		if err := s.Append(context.Background(), m); err != nil {
			t.Fatalf("append: %v", err)
		}
	}
}

func TestRelayPublishesPending(t *testing.T) {
	s := store.NewMemory()
	pub := publisher.NewInMemory()
	seed(t, s, 3)
	r := relay.New(s, pub)
	res, err := r.RelayOnce(context.Background())
	if err != nil {
		t.Fatalf("relay: %v", err)
	}
	if res.Published != 3 || pub.Count() != 3 {
		t.Fatalf("want 3 published, got res=%+v pubCount=%d", res, pub.Count())
	}
	res2, _ := r.RelayOnce(context.Background())
	if res2.Published != 0 {
		t.Fatalf("want 0 on second pass, got %d", res2.Published)
	}
}

type failingPublisher struct {
	failures int
	calls    int
	inner    *publisher.InMemory
}

func (f *failingPublisher) Publish(ctx context.Context, m outbox.Message) error {
	f.calls++
	if f.calls <= f.failures {
		return errors.New("broker unavailable")
	}
	return f.inner.Publish(ctx, m)
}

func TestRelayRetriesUntilDelivered(t *testing.T) {
	s := store.NewMemory()
	inner := publisher.NewInMemory()
	pub := &failingPublisher{failures: 2, inner: inner}
	m := outbox.NewMessage("payment", "pay-9", "payment.settled", []byte(`{}`))
	_ = s.Append(context.Background(), m)

	r := relay.New(s, pub)
	_, _ = r.RelayOnce(context.Background())
	_, _ = r.RelayOnce(context.Background())
	if got, _ := s.Get(m.ID); got.Status != outbox.StatusPending || got.Attempts != 2 {
		t.Fatalf("after 2 failures want PENDING attempts=2, got status=%s attempts=%d", got.Status, got.Attempts)
	}
	res, _ := r.RelayOnce(context.Background())
	if res.Published != 1 || inner.Count() != 1 {
		t.Fatalf("want delivered on 3rd pass, got res=%+v count=%d", res, inner.Count())
	}
	if got, _ := s.Get(m.ID); got.Status != outbox.StatusPublished {
		t.Fatalf("want PUBLISHED, got %s", got.Status)
	}
}

type alwaysFail struct{}

func (alwaysFail) Publish(context.Context, outbox.Message) error { return errors.New("down") }

func TestRelayDeadLettersAfterMaxAttempts(t *testing.T) {
	s := store.NewMemory()
	m := outbox.NewMessage("payment", "pay-x", "payment.settled", []byte(`{}`))
	_ = s.Append(context.Background(), m)
	r := relay.New(s, alwaysFail{}, relay.WithMaxAttempts(3))
	for i := 0; i < 4; i++ {
		_, _ = r.RelayOnce(context.Background())
	}
	got, _ := s.Get(m.ID)
	if got.Status != outbox.StatusFailed {
		t.Fatalf("want FAILED (dead-letter) after max attempts, got %s (attempts=%d)", got.Status, got.Attempts)
	}
}
