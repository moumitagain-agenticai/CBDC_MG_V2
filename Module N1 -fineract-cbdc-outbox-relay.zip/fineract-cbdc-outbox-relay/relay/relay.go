// Package relay reads pending outbox messages from a store and publishes them,
// guaranteeing at-least-once delivery with bounded retries and a dead-letter
// state. It depends on the outbox domain, the store port, and the publisher
// port — which keeps the dependency graph acyclic.
package relay

import (
	"context"
	"time"

	"github.com/fineract/cbdc/outbox-relay/publisher"
	"github.com/fineract/cbdc/outbox-relay/store"
)

// Relay moves messages from the outbox store to the publisher.
type Relay struct {
	store       store.Store
	pub         publisher.Publisher
	batch       int
	maxAttempts int
}

// Option customises a Relay.
type Option func(*Relay)

// WithBatchSize sets how many messages a single pass processes (default 100).
func WithBatchSize(n int) Option {
	return func(r *Relay) {
		if n > 0 {
			r.batch = n
		}
	}
}

// WithMaxAttempts sets how many delivery attempts are made before a message is
// dead-lettered (default 10).
func WithMaxAttempts(n int) Option {
	return func(r *Relay) {
		if n > 0 {
			r.maxAttempts = n
		}
	}
}

// New builds a relay over a store and publisher.
func New(s store.Store, p publisher.Publisher, opts ...Option) *Relay {
	r := &Relay{store: s, pub: p, batch: 100, maxAttempts: 10}
	for _, o := range opts {
		o(r)
	}
	return r
}

// PassResult summarises one relay pass.
type PassResult struct {
	Published    int
	Retried      int
	DeadLettered int
}

// RelayOnce performs a single pass: it fetches pending messages and attempts to
// publish each. Successful ones are marked published; failures are retried on a
// later pass (or dead-lettered once maxAttempts is reached). It is safe to call
// repeatedly and is the unit the loop in Run is built on.
func (r *Relay) RelayOnce(ctx context.Context) (PassResult, error) {
	var res PassResult
	pending, err := r.store.FetchPending(ctx, r.batch)
	if err != nil {
		return res, err
	}
	for i := range pending {
		m := pending[i]
		if m.Attempts >= r.maxAttempts {
			if err := r.store.MarkDead(ctx, m.ID, "max attempts exceeded"); err != nil {
				return res, err
			}
			res.DeadLettered++
			continue
		}
		if perr := r.pub.Publish(ctx, m); perr != nil {
			if err := r.store.MarkFailed(ctx, m.ID, perr.Error()); err != nil {
				return res, err
			}
			res.Retried++
			continue
		}
		if err := r.store.MarkPublished(ctx, m.ID); err != nil {
			return res, err
		}
		res.Published++
	}
	return res, nil
}

// Run relays continuously until ctx is cancelled, pausing interval between
// passes. It returns ctx.Err() when cancelled.
func (r *Relay) Run(ctx context.Context, interval time.Duration) error {
	if interval <= 0 {
		interval = time.Second
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
			if _, err := r.RelayOnce(ctx); err != nil {
				// transient errors: keep looping; messages stay pending and are
				// retried on the next tick.
				continue
			}
		}
	}
}
