# BUILD REPORT — fineract-cbdc-outbox-relay (Module N1)

Toolchain: Go 1.22 (module declares `go 1.21`). Module path:
`github.com/fineract/cbdc/outbox-relay`.

| Check | Command | Result |
|-------|---------|--------|
| Formatting | `gofmt -l .` | clean |
| Dependencies | `go mod tidy` | clean (`google/uuid`, `lib/pq`) |
| Build | `go build ./...` | pass (exit 0) |
| Vet | `go vet ./...` | pass (exit 0) |
| Unit tests | `go test ./...` | pass (outbox, relay, store) |
| Example | `go run ./examples` | appends 3, relays all 3 |

Requirement coverage (finalised list, N1): guaranteed async event delivery so
messages are not lost on crash — implemented as a transactional outbox
(`Store.Append` / `Postgres.AppendTx` in the business transaction) plus a relay
with at-least-once delivery, bounded retries, and a dead-letter state.

Tests: relay publishes all pending and is idempotent across passes; retries a
transient publish failure until delivered (message stays PENDING, attempts
increment, then PUBLISHED); dead-letters after max attempts; message validation;
new-message defaults. A DB-gated Postgres round-trip test runs when
`DATABASE_DSN` is set.

Design note: the relay lives in its own package (`relay`) so the dependency graph
is acyclic — `relay` depends on `outbox`, `store`, and `publisher`, none of which
depend back on it. Nothing pushed to any remote.
