package store

import (
	"context"
	"sort"
	"sync"
	"time"

	outbox "github.com/fineract/cbdc/outbox-relay"
)

// Memory is an in-memory Store for tests and local development.
type Memory struct {
	mu   sync.Mutex
	msgs map[string]*outbox.Message
}

var _ Store = (*Memory)(nil)

// NewMemory returns a ready in-memory store.
func NewMemory() *Memory { return &Memory{msgs: make(map[string]*outbox.Message)} }

func clone(m *outbox.Message) outbox.Message {
	cp := *m
	cp.Payload = append([]byte(nil), m.Payload...)
	if m.PublishedAt != nil {
		t := *m.PublishedAt
		cp.PublishedAt = &t
	}
	return cp
}

// Append stores a new PENDING message.
func (s *Memory) Append(_ context.Context, m *outbox.Message) error {
	if err := m.Validate(); err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	c := clone(m)
	c.Status = outbox.StatusPending
	s.msgs[m.ID] = &c
	return nil
}

// FetchPending returns up to limit PENDING messages, oldest first.
func (s *Memory) FetchPending(_ context.Context, limit int) ([]outbox.Message, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var pending []outbox.Message
	for _, m := range s.msgs {
		if m.Status == outbox.StatusPending {
			pending = append(pending, clone(m))
		}
	}
	sort.Slice(pending, func(i, j int) bool { return pending[i].CreatedAt.Before(pending[j].CreatedAt) })
	if limit > 0 && len(pending) > limit {
		pending = pending[:limit]
	}
	return pending, nil
}

// MarkPublished marks a message delivered.
func (s *Memory) MarkPublished(_ context.Context, id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	m, ok := s.msgs[id]
	if !ok {
		return outbox.ErrNotFound
	}
	now := time.Now().UTC()
	m.Status = outbox.StatusPublished
	m.PublishedAt = &now
	m.LastError = ""
	return nil
}

// MarkFailed records a failed attempt, keeping the message PENDING for retry.
func (s *Memory) MarkFailed(_ context.Context, id, cause string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	m, ok := s.msgs[id]
	if !ok {
		return outbox.ErrNotFound
	}
	m.Attempts++
	m.LastError = cause
	return nil
}

// MarkDead marks a message FAILED (dead-letter) after retries are exhausted.
func (s *Memory) MarkDead(_ context.Context, id, cause string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	m, ok := s.msgs[id]
	if !ok {
		return outbox.ErrNotFound
	}
	m.Status = outbox.StatusFailed
	m.LastError = cause
	return nil
}

// Ping is always healthy.
func (s *Memory) Ping(_ context.Context) error { return nil }

// Get returns a copy of a message by id (test helper).
func (s *Memory) Get(id string) (outbox.Message, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	m, ok := s.msgs[id]
	if !ok {
		return outbox.Message{}, false
	}
	return clone(m), true
}
