// Package store defines the outbox persistence port and provides two
// implementations: an in-memory store for tests/local use and a PostgreSQL store
// (using lib/pq) for production.
package store

import (
	"context"

	outbox "github.com/fineract/cbdc/outbox-relay"
)

// Store persists outbox messages and their delivery state.
//
// Append is intended to be called inside the SAME database transaction as the
// business change it accompanies; the PostgreSQL store supports this via
// AppendTx. The relay uses FetchPending / MarkPublished / MarkFailed / MarkDead.
type Store interface {
	// Append stores a new PENDING message.
	Append(ctx context.Context, m *outbox.Message) error
	// FetchPending returns up to limit PENDING messages, oldest first.
	FetchPending(ctx context.Context, limit int) ([]outbox.Message, error)
	// MarkPublished marks a message delivered.
	MarkPublished(ctx context.Context, id string) error
	// MarkFailed records a failed attempt and keeps the message PENDING so it is
	// retried on a later pass.
	MarkFailed(ctx context.Context, id, cause string) error
	// MarkDead marks a message FAILED after its retries are exhausted.
	MarkDead(ctx context.Context, id, cause string) error
	// Ping checks backend health.
	Ping(ctx context.Context) error
}
