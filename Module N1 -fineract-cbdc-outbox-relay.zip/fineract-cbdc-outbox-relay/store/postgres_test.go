package store_test

import (
	"context"
	"os"
	"testing"

	outbox "github.com/fineract/cbdc/outbox-relay"
	"github.com/fineract/cbdc/outbox-relay/store"
)

func TestPostgresRoundTrip(t *testing.T) {
	dsn := os.Getenv("DATABASE_DSN")
	if dsn == "" {
		t.Skip("DATABASE_DSN not set")
	}
	db, err := store.Open(dsn)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer db.Close()
	pg := store.NewPostgres(db)
	ctx := context.Background()
	if err := pg.Migrate(ctx); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	m := outbox.NewMessage("payment", "pay-1", "payment.settled", []byte(`{"ok":true}`))
	if err := pg.Append(ctx, m); err != nil {
		t.Fatalf("append: %v", err)
	}
	pending, err := pg.FetchPending(ctx, 10)
	if err != nil {
		t.Fatalf("fetch: %v", err)
	}
	if len(pending) == 0 {
		t.Fatal("expected at least one pending message")
	}
	if err := pg.MarkPublished(ctx, m.ID); err != nil {
		t.Fatalf("mark published: %v", err)
	}
}
