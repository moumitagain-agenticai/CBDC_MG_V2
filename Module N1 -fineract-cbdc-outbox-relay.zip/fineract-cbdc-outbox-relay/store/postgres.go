package store

import (
	"context"
	"database/sql"
	"errors"

	outbox "github.com/fineract/cbdc/outbox-relay"
	_ "github.com/lib/pq"
)

// Postgres is a PostgreSQL-backed Store.
type Postgres struct{ db *sql.DB }

var _ Store = (*Postgres)(nil)

// NewPostgres wraps an existing *sql.DB.
func NewPostgres(db *sql.DB) *Postgres { return &Postgres{db: db} }

// Open opens a PostgreSQL database from a DSN.
func Open(dsn string) (*sql.DB, error) { return sql.Open("postgres", dsn) }

const schema = `
CREATE TABLE IF NOT EXISTS outbox_messages (
    id             TEXT PRIMARY KEY,
    aggregate_type TEXT NOT NULL,
    aggregate_id   TEXT NOT NULL,
    event_type     TEXT NOT NULL,
    payload        BYTEA NOT NULL,
    status         TEXT NOT NULL DEFAULT 'PENDING',
    attempts       INTEGER NOT NULL DEFAULT 0,
    last_error     TEXT NOT NULL DEFAULT '',
    created_at     TIMESTAMPTZ NOT NULL,
    published_at   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON outbox_messages (status, created_at);
`

// Migrate creates the outbox table and index if they do not exist.
func (s *Postgres) Migrate(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, schema)
	return err
}

const insertSQL = `INSERT INTO outbox_messages
    (id, aggregate_type, aggregate_id, event_type, payload, status, attempts, last_error, created_at)
    VALUES ($1,$2,$3,$4,$5,'PENDING',0,'',$6)`

// Append stores a new PENDING message.
func (s *Postgres) Append(ctx context.Context, m *outbox.Message) error {
	if err := m.Validate(); err != nil {
		return err
	}
	_, err := s.db.ExecContext(ctx, insertSQL, m.ID, m.AggregateType, m.AggregateID, m.EventType, m.Payload, m.CreatedAt)
	return err
}

// AppendTx stores a new PENDING message inside an existing transaction, so the
// outbox write commits atomically with the business change. This is the
// recommended way to use the outbox.
func (s *Postgres) AppendTx(ctx context.Context, tx *sql.Tx, m *outbox.Message) error {
	if err := m.Validate(); err != nil {
		return err
	}
	_, err := tx.ExecContext(ctx, insertSQL, m.ID, m.AggregateType, m.AggregateID, m.EventType, m.Payload, m.CreatedAt)
	return err
}

// FetchPending returns up to limit PENDING messages, oldest first. FOR UPDATE
// SKIP LOCKED lets multiple relay workers run without processing the same rows.
func (s *Postgres) FetchPending(ctx context.Context, limit int) ([]outbox.Message, error) {
	const q = `SELECT id, aggregate_type, aggregate_id, event_type, payload, status, attempts, last_error, created_at, published_at
	    FROM outbox_messages WHERE status='PENDING' ORDER BY created_at LIMIT $1 FOR UPDATE SKIP LOCKED`
	rows, err := s.db.QueryContext(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []outbox.Message
	for rows.Next() {
		var m outbox.Message
		if err := rows.Scan(&m.ID, &m.AggregateType, &m.AggregateID, &m.EventType, &m.Payload,
			&m.Status, &m.Attempts, &m.LastError, &m.CreatedAt, &m.PublishedAt); err != nil {
			return nil, err
		}
		out = append(out, m)
	}
	return out, rows.Err()
}

// MarkPublished marks a message delivered.
func (s *Postgres) MarkPublished(ctx context.Context, id string) error {
	return s.exec(ctx, `UPDATE outbox_messages SET status='PUBLISHED', published_at=now(), last_error='' WHERE id=$1`, id)
}

// MarkFailed records a failed attempt and keeps the message PENDING.
func (s *Postgres) MarkFailed(ctx context.Context, id, cause string) error {
	return s.exec(ctx, `UPDATE outbox_messages SET attempts=attempts+1, last_error=$2 WHERE id=$1`, id, cause)
}

// MarkDead marks a message FAILED after retries are exhausted.
func (s *Postgres) MarkDead(ctx context.Context, id, cause string) error {
	return s.exec(ctx, `UPDATE outbox_messages SET status='FAILED', last_error=$2 WHERE id=$1`, id, cause)
}

func (s *Postgres) exec(ctx context.Context, q string, args ...any) error {
	res, err := s.db.ExecContext(ctx, q, args...)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return outbox.ErrNotFound
	}
	return nil
}

// Ping checks database health.
func (s *Postgres) Ping(ctx context.Context) error {
	if err := s.db.PingContext(ctx); err != nil {
		return errors.Join(errors.New("outbox: database ping failed"), err)
	}
	return nil
}
