// Command example demonstrates the outbox relay: it appends events to an
// in-memory outbox, then relays them to an in-memory publisher, showing
// at-least-once delivery.
//
//	go run ./examples
package main

import (
	"context"
	"fmt"

	outbox "github.com/fineract/cbdc/outbox-relay"
	"github.com/fineract/cbdc/outbox-relay/publisher"
	relaypkg "github.com/fineract/cbdc/outbox-relay/relay"
	"github.com/fineract/cbdc/outbox-relay/store"
)

func main() {
	ctx := context.Background()
	s := store.NewMemory()
	pub := publisher.NewInMemory()

	// A service would call Append inside the same DB transaction as its write.
	for _, id := range []string{"pay-1", "pay-2", "pay-3"} {
		_ = s.Append(ctx, outbox.NewMessage("payment", id, "payment.settled", []byte(`{"id":"`+id+`"}`)))
	}
	fmt.Println("appended 3 pending events")

	relay := relaypkg.New(s, pub)
	res, _ := relay.RelayOnce(ctx)
	fmt.Printf("relay pass: published=%d retried=%d dead=%d\n", res.Published, res.Retried, res.DeadLettered)

	fmt.Println("delivered events:")
	for _, m := range pub.Published() {
		fmt.Printf("  %s  %s/%s  %s\n", m.EventType, m.AggregateType, m.AggregateID, string(m.Payload))
	}
}
