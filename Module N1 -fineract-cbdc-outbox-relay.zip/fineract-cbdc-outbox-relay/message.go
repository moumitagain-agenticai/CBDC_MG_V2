// Package outbox is Module N1 of the E1 CBDC platform: a transactional outbox
// and relay that guarantee async events survive a crash and are delivered
// at-least-once.
//
// The pattern: a service writes its business change AND an outbox message in the
// SAME database transaction (via the store's Append). A separate relay then
// reads pending messages and publishes them to the broker, marking each
// published only after the broker accepts it. If the process crashes between the
// commit and the publish, the message is still in the outbox and is delivered on
// the next pass — so no event is ever lost. Delivery is at-least-once, so
// consumers must be idempotent (see the idempotency-gateway, N2).
package outbox

import (
	"strings"
	"time"

	"github.com/google/uuid"
)

// Status is the delivery status of an outbox message.
type Status string

// Message statuses.
const (
	StatusPending   Status = "PENDING"   // not yet published
	StatusPublished Status = "PUBLISHED" // delivered to the broker
	StatusFailed    Status = "FAILED"    // retries exhausted (dead-letter)
)

// Message is one event captured in the outbox.
type Message struct {
	ID            string     `json:"id"`
	AggregateType string     `json:"aggregate_type"` // e.g. "payment"
	AggregateID   string     `json:"aggregate_id"`   // e.g. the payment id
	EventType     string     `json:"event_type"`     // e.g. "payment.settled"
	Payload       []byte     `json:"payload"`        // opaque event body
	Status        Status     `json:"status"`
	Attempts      int        `json:"attempts"`
	LastError     string     `json:"last_error,omitempty"`
	CreatedAt     time.Time  `json:"created_at"`
	PublishedAt   *time.Time `json:"published_at,omitempty"`
}

// NewMessage builds a PENDING message with a fresh id and creation time. Callers
// pass it to Store.Append inside their business transaction.
func NewMessage(aggregateType, aggregateID, eventType string, payload []byte) *Message {
	return &Message{
		ID:            uuid.NewString(),
		AggregateType: strings.TrimSpace(aggregateType),
		AggregateID:   strings.TrimSpace(aggregateID),
		EventType:     strings.TrimSpace(eventType),
		Payload:       payload,
		Status:        StatusPending,
		CreatedAt:     time.Now().UTC(),
	}
}

// Validate reports whether the message is well-formed enough to store.
func (m *Message) Validate() error {
	if m.ID == "" {
		return ErrInvalid("id is required")
	}
	if m.AggregateType == "" {
		return ErrInvalid("aggregate_type is required")
	}
	if m.EventType == "" {
		return ErrInvalid("event_type is required")
	}
	return nil
}
