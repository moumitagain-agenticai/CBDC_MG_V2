// Package publisher defines the broker port the relay publishes to, plus a
// no-op and an in-memory capturing implementation for tests and examples. A
// production deployment provides an adapter for its broker (Kafka, NATS, ...)
// behind the same interface.
package publisher

import (
	"context"
	"sync"

	outbox "github.com/fineract/cbdc/outbox-relay"
)

// Publisher delivers a message to the broker. Returning an error causes the
// relay to retry the message later.
type Publisher interface {
	Publish(ctx context.Context, m outbox.Message) error
}

// Noop accepts and discards every message.
type Noop struct{}

// Publish always succeeds.
func (Noop) Publish(context.Context, outbox.Message) error { return nil }

// InMemory captures published messages for inspection in tests and examples.
type InMemory struct {
	mu        sync.Mutex
	published []outbox.Message
}

// NewInMemory returns a ready capturing publisher.
func NewInMemory() *InMemory { return &InMemory{} }

// Publish records the message.
func (p *InMemory) Publish(_ context.Context, m outbox.Message) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.published = append(p.published, m)
	return nil
}

// Published returns a copy of everything published so far.
func (p *InMemory) Published() []outbox.Message {
	p.mu.Lock()
	defer p.mu.Unlock()
	return append([]outbox.Message(nil), p.published...)
}

// Count returns how many messages were published.
func (p *InMemory) Count() int {
	p.mu.Lock()
	defer p.mu.Unlock()
	return len(p.published)
}
