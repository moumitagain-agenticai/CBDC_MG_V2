# fineract-cbdc-outbox-relay  (Module N1 — P0 new build)

**Guaranteed at-least-once async event delivery** via the transactional outbox
pattern. It exists so that **no event is lost on a crash** — every async write on
the platform goes through the outbox.

Module path: `github.com/fineract/cbdc/outbox-relay` · Go 1.21+.

## The problem it solves

If a service updates its database and then publishes an event to a broker as two
separate steps, a crash in between loses the event. The **transactional outbox**
removes that gap: the service writes its business change **and** an outbox row in
the **same database transaction**. A separate **relay** then publishes pending
rows and marks each published only after the broker accepts it.

```
business write  ─┐ (one DB transaction)
outbox INSERT   ─┘
                      ▼
            relay: fetch PENDING ─▶ publish ─▶ mark PUBLISHED
```

If the process dies after the commit but before publishing, the row is still
`PENDING` and is delivered on the next pass. Delivery is therefore
**at-least-once** — consumers must be idempotent (that is the job of **N2**, the
idempotency-gateway).

## How to use it

```go
// 1) In the service's business transaction, append an outbox message:
msg := outbox.NewMessage("payment", paymentID, "payment.settled", payloadJSON)
pg.AppendTx(ctx, tx, msg)   // commits atomically with the business change

// 2) Run the relay (e.g. as a background worker):
r := relay.New(store, publisher, relay.WithBatchSize(200), relay.WithMaxAttempts(10))
r.Run(ctx, time.Second)     // or r.RelayOnce(ctx) for a single pass
```

## Delivery semantics

- **At-least-once.** A message may be delivered more than once (e.g. broker
  accepted but the mark-published write failed) — consumers must dedupe.
- **Bounded retries.** Each failed attempt increments `attempts` and keeps the
  message `PENDING`; once `attempts` reaches `maxAttempts` the message is
  **dead-lettered** (`FAILED`) rather than retried forever.
- **Ordering.** Pending messages are fetched oldest-first; the PostgreSQL store
  uses `FOR UPDATE SKIP LOCKED` so multiple relay workers can run safely.

## Packages

| Path | Responsibility |
|------|----------------|
| `message.go` (`outbox`) | The `Message` type, statuses, and `NewMessage`. |
| `store/` | The `Store` port + an in-memory store and a PostgreSQL store (`AppendTx` for same-transaction writes, `Migrate`). |
| `publisher/` | The `Publisher` broker port + no-op and in-memory implementations. |
| `relay/` | The `Relay`: `RelayOnce` (single pass) and `Run` (loop). |
| `migrations/001_init.sql` | The `outbox_messages` table DDL. |

## Build, test, run

```bash
go build ./...
go vet ./...
go test ./...                       # unit tests (in-memory)
DATABASE_DSN=postgres://... go test ./store/...   # DB-gated Postgres test
go run ./examples
```

## Dependencies

`github.com/google/uuid` (ids) and `github.com/lib/pq` (PostgreSQL driver). The
broker publisher is behind an interface, so a Kafka/NATS adapter plugs in without
changing the relay.
