package outbox

import "errors"

// ErrInvalid builds a validation error with a message.
func ErrInvalid(msg string) error { return &InvalidError{Msg: msg} }

// InvalidError indicates a malformed outbox message.
type InvalidError struct{ Msg string }

func (e *InvalidError) Error() string { return "outbox: invalid: " + e.Msg }

// ErrNotFound is returned when a message id does not exist.
var ErrNotFound = errors.New("outbox: message not found")
