// Command example demonstrates the connector abstraction end to end using the
// in-memory mock connector: it issues, locks, releases, transfers, burns, and
// redeems CBDC, then prints balances and a metrics snapshot.
//
// Run it with:
//
//	go run ./examples
package main

import (
	"context"
	"fmt"
	"log"

	connector "github.com/fineract/cbdc/connector-abstraction"
	"github.com/fineract/cbdc/connector-abstraction/config"
	"github.com/fineract/cbdc/connector-abstraction/metrics"
	"github.com/fineract/cbdc/connector-abstraction/reqctx"
	"github.com/fineract/cbdc/connector-abstraction/test/mock"
	"github.com/fineract/cbdc/connector-abstraction/types"
)

func main() {
	cfg := config.Default()
	if err := cfg.Validate(); err != nil {
		log.Fatalf("config invalid: %v", err)
	}

	rec := metrics.NewInMemory()
	conn := mock.New(
		connector.Info{Name: cfg.Name, Network: cfg.Network, Currency: cfg.Currency},
		mock.WithMetrics(rec),
	)

	// Attach a request id so all operations in this run can be correlated.
	ctx, reqID := reqctx.EnsureRequestID(context.Background())
	fmt.Printf("connector: %s  network=%s  currency=%s\n", conn.Info().Name, conn.Info().Network, conn.Info().Currency)
	fmt.Printf("request id: %s\n\n", reqID)

	inr := func(minor int64) types.Amount { return types.NewAmount(minor, types.INR) }
	const alice, bob = types.WalletID("wallet-alice"), types.WalletID("wallet-bob")

	// 1) Issue 1,000.00 INR (100000 paise) to Alice.
	r, err := conn.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(100000), Reference: "seed"})
	show("issue", r, err)

	// 2) Lock 400.00 INR of Alice's balance, then release it.
	lock, err := conn.Lock(ctx, connector.LockRequest{Wallet: alice, Amount: inr(40000), Reference: "hold"})
	show("lock", lock, err)
	r, err = conn.Release(ctx, connector.ReleaseRequest{LockID: lock.LockID})
	show("release", r, err)

	// 3) Transfer 200.00 INR from Alice to Bob.
	r, err = conn.Transfer(ctx, connector.TransferRequest{From: alice, To: bob, Amount: inr(20000), Reference: "pay"})
	show("transfer", r, err)

	// 4) Burn 100.00 INR from Alice.
	r, err = conn.Burn(ctx, connector.BurnRequest{Wallet: alice, Amount: inr(10000), Reference: "burn"})
	show("burn", r, err)

	// 5) Redeem 50.00 INR from Bob back to bank money.
	r, err = conn.Redeem(ctx, connector.RedeemRequest{Wallet: bob, Amount: inr(5000), Reference: "cash-out"})
	show("redeem", r, err)

	// Final balances.
	aBal, _ := conn.Balance(ctx, alice)
	bBal, _ := conn.Balance(ctx, bob)
	fmt.Printf("\nfinal balances:\n  alice: %s\n  bob:   %s\n", aBal, bBal)

	// Metrics snapshot.
	fmt.Println("\nmetrics (operation/status -> count):")
	for key, stat := range rec.Snapshot() {
		fmt.Printf("  %-18s count=%d total=%dns\n", key, stat.Count, stat.TotalNanos)
	}
}

func show(label string, r connector.Receipt, err error) {
	if err != nil {
		log.Fatalf("%s failed: %v", label, err)
	}
	if r.LockID != "" {
		fmt.Printf("%-9s ok  txn=%s  amount=%s  lock=%s\n", label, r.TxnID, r.Amount, r.LockID)
	} else {
		fmt.Printf("%-9s ok  txn=%s  amount=%s\n", label, r.TxnID, r.Amount)
	}
}
