// Package metrics defines a small recorder interface for connector operations,
// with a no-op default and a thread-safe in-memory implementation useful in
// tests and examples.
//
// A real deployment can provide an adapter that forwards to Prometheus (or any
// other system) behind the same Recorder interface, without changing connector
// code. Keeping the interface here avoids forcing a specific metrics dependency
// on every importer.
package metrics

import (
	"sync"
	"time"
)

// Recorder records the outcome and latency of connector operations.
type Recorder interface {
	// RecordOp records that an operation with the given name finished with the
	// given status (for example "ok" or an error code), taking dur.
	RecordOp(operation, status string, dur time.Duration)
}

// Noop is a Recorder that discards everything. It is the safe default when no
// metrics backend is configured.
type Noop struct{}

// RecordOp does nothing.
func (Noop) RecordOp(string, string, time.Duration) {}

// OpStat is an aggregated view of one operation/status pair.
type OpStat struct {
	Count      int64
	TotalNanos int64
}

// InMemory is a thread-safe Recorder that aggregates counts and total latency
// per operation/status. It is intended for tests and local runs.
type InMemory struct {
	mu    sync.Mutex
	stats map[string]OpStat
}

// NewInMemory returns a ready-to-use in-memory recorder.
func NewInMemory() *InMemory {
	return &InMemory{stats: make(map[string]OpStat)}
}

// RecordOp aggregates the observation under the key "operation/status".
func (m *InMemory) RecordOp(operation, status string, dur time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	key := operation + "/" + status
	s := m.stats[key]
	s.Count++
	s.TotalNanos += dur.Nanoseconds()
	m.stats[key] = s
}

// Snapshot returns a copy of the current statistics keyed by "operation/status".
func (m *InMemory) Snapshot() map[string]OpStat {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make(map[string]OpStat, len(m.stats))
	for k, v := range m.stats {
		out[k] = v
	}
	return out
}
