# fineract-cbdc-connector-abstraction

**Module 1** of the E1 Cross-Border CBDC Payment Platform (External Integration &
Adapters layer). It defines the **standard interface every CBDC connector implements**
— the "universal adapter" that lets the rest of the platform issue, transfer, lock,
release, burn, and redeem central-bank digital currency the same way, regardless of
which network (India e₹, UAE Digital Dirham, GIFT City, …) is underneath.

Module path: `github.com/fineract/cbdc/connector-abstraction` · Go 1.21+.

> This is the buildable, vetting-clean Go-module layout (proper `go.mod`/`go.sum`, one
> package per directory, real file names) — the restructured "Tusshar" format, not a
> flat file dump.

## The interface

```go
type Connector interface {
    Info() Info

    Issue(ctx, IssueRequest)       (Receipt, error) // mint CBDC into a wallet
    Transfer(ctx, TransferRequest) (Receipt, error) // move between wallets
    Lock(ctx, LockRequest)         (Receipt, error) // reserve funds (returns LockID)
    Release(ctx, ReleaseRequest)   (Receipt, error) // return a lock to spendable
    Burn(ctx, BurnRequest)         (Receipt, error) // destroy CBDC (optionally a lock)
    Redeem(ctx, RedeemRequest)     (Receipt, error) // convert CBDC back to bank money

    Balance(ctx, WalletID) (types.Amount, error)
    HealthCheck(ctx)       error
}
```

`Lock` / `Release` / `Burn` underpin the platform's **lock-release-burn** settlement
flow. Every method takes a `context.Context` and returns a classified `*Error` on
failure.

## Package layout

| Path | Package | Responsibility |
|------|---------|----------------|
| `connector.go` | `connector` | The `Connector` interface and `Info`. |
| `models.go` | `connector` | Request and `Receipt` types, each with `Validate()`. |
| `errors.go` | `connector` | The classified `Error` type, `Code`s, and `CodeOf`. |
| `types/` | `types` | Currencies, networks, operations, statuses, and the integer-minor-unit `Amount`. |
| `validation/` | `validation` | Small standard-library field validators. |
| `config/` | `config` | Connector `Config` with `Default()`, `LoadFromEnv()`, `Validate()`. |
| `metrics/` | `metrics` | A `Recorder` interface with a no-op and an in-memory implementation. |
| `tracing/` | `tracing` | A minimal `Tracer`/`Span` abstraction with a no-op default. |
| `reqctx/` | `reqctx` | Carries a request id through `context` for correlation. |
| `test/mock/` | `mock` | An in-memory `Connector` implementation for tests, examples, and local dev. |
| `examples/` | `main` | A runnable end-to-end demonstration. |
| `testdata/config.yaml` | — | A documented sample configuration. |

## Build, test, run

```bash
go mod download
go build ./...      # compiles all 9 packages
go vet ./...        # static checks
go test ./...       # unit tests
go run ./examples   # end-to-end demo against the mock connector
```

The example prints each operation, the final balances, and a metrics snapshot.

## Usage

```go
import (
    connector "github.com/fineract/cbdc/connector-abstraction"
    "github.com/fineract/cbdc/connector-abstraction/test/mock"
    "github.com/fineract/cbdc/connector-abstraction/types"
)

conn := mock.New(connector.Info{
    Name: "india-erupee-connector", Network: types.NetworkIndiaERupee, Currency: types.INR,
})

r, err := conn.Issue(ctx, connector.IssueRequest{
    To: "wallet-alice", Amount: types.NewAmount(100000, types.INR), // 1,000.00 INR in paise
})
```

A real connector implements the same `Connector` interface against its network's API;
the platform depends only on the interface, never on a concrete connector.

## Error model

Every failure is an `*Error` with a stable `Code`, which callers can branch on via
`connector.CodeOf(err)`:

`validation` · `not_found` · `insufficient_funds` · `conflict` · `unsupported` ·
`unavailable` · `internal`.

## Money and idempotency

- **Integer minor units.** All amounts are integers (paise, fils) via `types.Amount`
  — no floating-point money.
- **Idempotency.** Issue/Transfer/Lock/Burn/Redeem accept an optional
  `IdempotencyKey`; replaying the same key returns the original receipt without
  applying the effect twice.

## Dependencies

This module keeps its dependency surface intentionally minimal — a single, ubiquitous
library (`github.com/google/uuid`) — so it builds anywhere and has a small
supply-chain footprint. `metrics`, `tracing`, and `validation` are provided as small
in-house packages behind clean interfaces; a deployment can supply adapters that
forward to Prometheus, OpenTelemetry, or a full validator library without changing any
connector code.

## Continuous integration

`.github/workflows/go.yml` runs `gofmt` check, `go build ./...`, `go vet ./...`, and
`go test ./...` on every push — so a non-compiling or unformatted layout is caught
automatically rather than after handoff.
