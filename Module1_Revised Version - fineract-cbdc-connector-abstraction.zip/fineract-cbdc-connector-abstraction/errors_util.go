package connector

import "errors"

// as is a thin wrapper over errors.As so the rest of the package can classify
// errors without importing the standard library "errors" in multiple files.
func as(err error, target interface{}) bool { return errors.As(err, target) }
