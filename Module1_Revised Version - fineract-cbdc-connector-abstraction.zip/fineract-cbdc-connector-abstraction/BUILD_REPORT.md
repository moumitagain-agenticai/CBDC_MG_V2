# BUILD REPORT — fineract-cbdc-connector-abstraction (Module 1)

Toolchain: Go 1.22 (module declares `go 1.21`). Module path:
`github.com/fineract/cbdc/connector-abstraction`.

| Check | Command | Result |
|-------|---------|--------|
| Formatting | `gofmt -l .` | clean (no files listed) |
| Dependencies | `go mod tidy` | clean (`github.com/google/uuid v1.6.0`) |
| Build | `go build ./...` | pass (exit 0) — 9 packages |
| Vet | `go vet ./...` | pass (exit 0) |
| Unit tests | `go test ./...` | pass (root + types) |
| Example binary | `go build -o bin ./examples` | links (~2.8 MB) and runs end to end |

Packages built:

```
github.com/fineract/cbdc/connector-abstraction
github.com/fineract/cbdc/connector-abstraction/config
github.com/fineract/cbdc/connector-abstraction/examples
github.com/fineract/cbdc/connector-abstraction/metrics
github.com/fineract/cbdc/connector-abstraction/reqctx
github.com/fineract/cbdc/connector-abstraction/test/mock
github.com/fineract/cbdc/connector-abstraction/tracing
github.com/fineract/cbdc/connector-abstraction/types
github.com/fineract/cbdc/connector-abstraction/validation
```

Test coverage: issue + balance; transfer moves funds; insufficient funds → conflict
code; lock/release round-trip (locked funds not spendable, restored on release); burn
consuming a lock; release of an unknown lock → not_found; validation rejects empty
wallet, zero amount, and same-wallet transfer; currency mismatch → validation;
idempotent replay returns the same receipt and credits once; Amount add/sub, currency
mismatch, and validation.

Format notes: this is the restructured, buildable Go-module layout ("Tusshar" format)
— proper `go.mod`/`go.sum`, one package per directory, plain file names
(`connector.go`, `models.go`, …), no numbered `*.go.go` files. Dependency surface is
deliberately minimal (only `google/uuid`); `metrics`, `tracing`, and `validation` are
in-house packages behind interfaces so Prometheus/OpenTelemetry/validator adapters can
be plugged in without touching connector code. Nothing was pushed to any remote.
