// Package mock provides an in-memory implementation of connector.Connector,
// backed by a simple ledger. It is intended for tests, examples, and local
// development; it never talks to a real CBDC network.
//
// The mock maintains, per wallet, an available balance and a set of active
// locks. It enforces the same invariants a real connector would (sufficient
// funds, valid state transitions) and records each operation through an
// optional metrics.Recorder.
package mock

import (
	"context"
	"sync"
	"time"

	connector "github.com/fineract/cbdc/connector-abstraction"
	"github.com/fineract/cbdc/connector-abstraction/metrics"
	"github.com/fineract/cbdc/connector-abstraction/reqctx"
	"github.com/fineract/cbdc/connector-abstraction/types"
	"github.com/google/uuid"
)

// Connector is an in-memory mock CBDC connector.
type Connector struct {
	info    connector.Info
	metrics metrics.Recorder

	mu       sync.Mutex
	balances map[types.WalletID]int64     // available minor units per wallet
	locks    map[string]lockRec           // active locks by lock id
	seen     map[string]connector.Receipt // idempotency key -> prior receipt
}

type lockRec struct {
	wallet types.WalletID
	minor  int64
}

// Option customises a mock Connector.
type Option func(*Connector)

// WithMetrics attaches a metrics recorder.
func WithMetrics(r metrics.Recorder) Option {
	return func(c *Connector) {
		if r != nil {
			c.metrics = r
		}
	}
}

// New returns a mock connector with the given info and options.
func New(info connector.Info, opts ...Option) *Connector {
	c := &Connector{
		info:     info,
		metrics:  metrics.Noop{},
		balances: make(map[types.WalletID]int64),
		locks:    make(map[string]lockRec),
		seen:     make(map[string]connector.Receipt),
	}
	for _, o := range opts {
		o(c)
	}
	return c
}

// Info returns the connector metadata.
func (c *Connector) Info() connector.Info { return c.info }

// record observes an operation's outcome for metrics.
func (c *Connector) record(op types.Operation, start time.Time, err error) {
	status := "ok"
	if err != nil {
		status = string(connector.CodeOf(err))
	}
	c.metrics.RecordOp(string(op), status, time.Since(start))
}

// checkCurrency ensures the amount is in the connector's currency.
func (c *Connector) checkCurrency(a types.Amount) error {
	if a.Currency != c.info.Currency {
		return connector.NewValidationError("currency does not match connector currency", nil)
	}
	return nil
}

// replay returns a stored receipt for an idempotency key, if present.
func (c *Connector) replay(key string) (connector.Receipt, bool) {
	if key == "" {
		return connector.Receipt{}, false
	}
	r, ok := c.seen[key]
	return r, ok
}

func (c *Connector) remember(key string, r connector.Receipt) {
	if key != "" {
		c.seen[key] = r
	}
}

func newReceipt(op types.Operation, amount types.Amount) connector.Receipt {
	return connector.Receipt{
		TxnID:     uuid.NewString(),
		Operation: op,
		Status:    types.StatusCompleted,
		Amount:    amount,
		CreatedAt: time.Now().UTC(),
	}
}

// Issue mints CBDC into a wallet.
func (c *Connector) Issue(ctx context.Context, req connector.IssueRequest) (connector.Receipt, error) {
	ctx, _ = reqctx.EnsureRequestID(ctx)
	start := time.Now()
	var err error
	defer func() { c.record(types.OpIssue, start, err) }()

	if err = req.Validate(); err != nil {
		return connector.Receipt{}, err
	}
	if err = c.checkCurrency(req.Amount); err != nil {
		return connector.Receipt{}, err
	}

	c.mu.Lock()
	defer c.mu.Unlock()
	if r, ok := c.replay(req.IdempotencyKey); ok {
		return r, nil
	}
	c.balances[req.To] += req.Amount.Minor
	r := newReceipt(types.OpIssue, req.Amount)
	c.remember(req.IdempotencyKey, r)
	return r, nil
}

// Transfer moves CBDC between wallets.
func (c *Connector) Transfer(ctx context.Context, req connector.TransferRequest) (connector.Receipt, error) {
	ctx, _ = reqctx.EnsureRequestID(ctx)
	start := time.Now()
	var err error
	defer func() { c.record(types.OpTransfer, start, err) }()

	if err = req.Validate(); err != nil {
		return connector.Receipt{}, err
	}
	if err = c.checkCurrency(req.Amount); err != nil {
		return connector.Receipt{}, err
	}

	c.mu.Lock()
	defer c.mu.Unlock()
	if r, ok := c.replay(req.IdempotencyKey); ok {
		return r, nil
	}
	if c.balances[req.From] < req.Amount.Minor {
		err = connector.NewInsufficientFundsError("insufficient available balance", nil)
		return connector.Receipt{}, err
	}
	c.balances[req.From] -= req.Amount.Minor
	c.balances[req.To] += req.Amount.Minor
	r := newReceipt(types.OpTransfer, req.Amount)
	c.remember(req.IdempotencyKey, r)
	return r, nil
}

// Lock reserves an amount in a wallet.
func (c *Connector) Lock(ctx context.Context, req connector.LockRequest) (connector.Receipt, error) {
	ctx, _ = reqctx.EnsureRequestID(ctx)
	start := time.Now()
	var err error
	defer func() { c.record(types.OpLock, start, err) }()

	if err = req.Validate(); err != nil {
		return connector.Receipt{}, err
	}
	if err = c.checkCurrency(req.Amount); err != nil {
		return connector.Receipt{}, err
	}

	c.mu.Lock()
	defer c.mu.Unlock()
	if r, ok := c.replay(req.IdempotencyKey); ok {
		return r, nil
	}
	if c.balances[req.Wallet] < req.Amount.Minor {
		err = connector.NewInsufficientFundsError("insufficient available balance to lock", nil)
		return connector.Receipt{}, err
	}
	c.balances[req.Wallet] -= req.Amount.Minor
	lockID := uuid.NewString()
	c.locks[lockID] = lockRec{wallet: req.Wallet, minor: req.Amount.Minor}
	r := newReceipt(types.OpLock, req.Amount)
	r.LockID = lockID
	c.remember(req.IdempotencyKey, r)
	return r, nil
}

// Release returns a locked amount to spendable balance.
func (c *Connector) Release(ctx context.Context, req connector.ReleaseRequest) (connector.Receipt, error) {
	ctx, _ = reqctx.EnsureRequestID(ctx)
	start := time.Now()
	var err error
	defer func() { c.record(types.OpRelease, start, err) }()

	if err = req.Validate(); err != nil {
		return connector.Receipt{}, err
	}

	c.mu.Lock()
	defer c.mu.Unlock()
	lk, ok := c.locks[req.LockID]
	if !ok {
		err = connector.NewNotFoundError("lock not found", nil)
		return connector.Receipt{}, err
	}
	c.balances[lk.wallet] += lk.minor
	delete(c.locks, req.LockID)
	r := newReceipt(types.OpRelease, types.NewAmount(lk.minor, c.info.Currency))
	r.LockID = req.LockID
	return r, nil
}

// Burn destroys CBDC, optionally consuming a lock.
func (c *Connector) Burn(ctx context.Context, req connector.BurnRequest) (connector.Receipt, error) {
	ctx, _ = reqctx.EnsureRequestID(ctx)
	start := time.Now()
	var err error
	defer func() { c.record(types.OpBurn, start, err) }()

	if err = req.Validate(); err != nil {
		return connector.Receipt{}, err
	}
	if err = c.checkCurrency(req.Amount); err != nil {
		return connector.Receipt{}, err
	}

	c.mu.Lock()
	defer c.mu.Unlock()
	if r, ok := c.replay(req.IdempotencyKey); ok {
		return r, nil
	}

	if req.LockID != "" {
		lk, ok := c.locks[req.LockID]
		if !ok {
			err = connector.NewNotFoundError("lock not found", nil)
			return connector.Receipt{}, err
		}
		if lk.minor != req.Amount.Minor {
			err = connector.NewConflictError("burn amount does not match locked amount", nil)
			return connector.Receipt{}, err
		}
		delete(c.locks, req.LockID)
	} else {
		if c.balances[req.Wallet] < req.Amount.Minor {
			err = connector.NewInsufficientFundsError("insufficient available balance to burn", nil)
			return connector.Receipt{}, err
		}
		c.balances[req.Wallet] -= req.Amount.Minor
	}
	r := newReceipt(types.OpBurn, req.Amount)
	r.LockID = req.LockID
	c.remember(req.IdempotencyKey, r)
	return r, nil
}

// Redeem converts CBDC back to bank money, removing it from the wallet.
func (c *Connector) Redeem(ctx context.Context, req connector.RedeemRequest) (connector.Receipt, error) {
	ctx, _ = reqctx.EnsureRequestID(ctx)
	start := time.Now()
	var err error
	defer func() { c.record(types.OpRedeem, start, err) }()

	if err = req.Validate(); err != nil {
		return connector.Receipt{}, err
	}
	if err = c.checkCurrency(req.Amount); err != nil {
		return connector.Receipt{}, err
	}

	c.mu.Lock()
	defer c.mu.Unlock()
	if r, ok := c.replay(req.IdempotencyKey); ok {
		return r, nil
	}
	if c.balances[req.Wallet] < req.Amount.Minor {
		err = connector.NewInsufficientFundsError("insufficient available balance to redeem", nil)
		return connector.Receipt{}, err
	}
	c.balances[req.Wallet] -= req.Amount.Minor
	r := newReceipt(types.OpRedeem, req.Amount)
	c.remember(req.IdempotencyKey, r)
	return r, nil
}

// Balance returns the spendable balance of a wallet.
func (c *Connector) Balance(ctx context.Context, wallet types.WalletID) (types.Amount, error) {
	_, _ = reqctx.EnsureRequestID(ctx)
	c.mu.Lock()
	defer c.mu.Unlock()
	return types.NewAmount(c.balances[wallet], c.info.Currency), nil
}

// HealthCheck always reports healthy for the in-memory mock.
func (c *Connector) HealthCheck(_ context.Context) error { return nil }

// compile-time assurance that the mock satisfies the interface.
var _ connector.Connector = (*Connector)(nil)
