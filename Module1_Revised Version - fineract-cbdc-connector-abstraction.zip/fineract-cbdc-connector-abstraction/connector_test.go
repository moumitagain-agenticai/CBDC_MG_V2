package connector_test

import (
	"context"
	"testing"

	connector "github.com/fineract/cbdc/connector-abstraction"
	"github.com/fineract/cbdc/connector-abstraction/metrics"
	"github.com/fineract/cbdc/connector-abstraction/test/mock"
	"github.com/fineract/cbdc/connector-abstraction/types"
)

func newConn() *mock.Connector {
	return mock.New(connector.Info{Name: "test", Network: types.NetworkIndiaERupee, Currency: types.INR},
		mock.WithMetrics(metrics.NewInMemory()))
}

func inr(minor int64) types.Amount { return types.NewAmount(minor, types.INR) }

const alice, bob = types.WalletID("alice"), types.WalletID("bob")

func TestIssueAndBalance(t *testing.T) {
	c := newConn()
	ctx := context.Background()
	if _, err := c.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(100000)}); err != nil {
		t.Fatalf("issue: %v", err)
	}
	bal, err := c.Balance(ctx, alice)
	if err != nil {
		t.Fatalf("balance: %v", err)
	}
	if bal.Minor != 100000 {
		t.Fatalf("want 100000, got %d", bal.Minor)
	}
}

func TestTransferMovesFunds(t *testing.T) {
	c := newConn()
	ctx := context.Background()
	_, _ = c.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(100000)})
	if _, err := c.Transfer(ctx, connector.TransferRequest{From: alice, To: bob, Amount: inr(30000)}); err != nil {
		t.Fatalf("transfer: %v", err)
	}
	a, _ := c.Balance(ctx, alice)
	b, _ := c.Balance(ctx, bob)
	if a.Minor != 70000 || b.Minor != 30000 {
		t.Fatalf("want 70000/30000, got %d/%d", a.Minor, b.Minor)
	}
}

func TestTransferInsufficientFunds(t *testing.T) {
	c := newConn()
	ctx := context.Background()
	_, err := c.Transfer(ctx, connector.TransferRequest{From: alice, To: bob, Amount: inr(1)})
	if connector.CodeOf(err) != connector.CodeInsufficientFunds {
		t.Fatalf("want insufficient_funds, got %v", err)
	}
}

func TestLockReleaseRoundTrip(t *testing.T) {
	c := newConn()
	ctx := context.Background()
	_, _ = c.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(100000)})
	lock, err := c.Lock(ctx, connector.LockRequest{Wallet: alice, Amount: inr(40000)})
	if err != nil {
		t.Fatalf("lock: %v", err)
	}
	if lock.LockID == "" {
		t.Fatal("expected a lock id")
	}
	// locked funds are not spendable
	if bal, _ := c.Balance(ctx, alice); bal.Minor != 60000 {
		t.Fatalf("want 60000 available after lock, got %d", bal.Minor)
	}
	if _, err := c.Release(ctx, connector.ReleaseRequest{LockID: lock.LockID}); err != nil {
		t.Fatalf("release: %v", err)
	}
	if bal, _ := c.Balance(ctx, alice); bal.Minor != 100000 {
		t.Fatalf("want 100000 after release, got %d", bal.Minor)
	}
}

func TestBurnConsumesLock(t *testing.T) {
	c := newConn()
	ctx := context.Background()
	_, _ = c.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(100000)})
	lock, _ := c.Lock(ctx, connector.LockRequest{Wallet: alice, Amount: inr(40000)})
	if _, err := c.Burn(ctx, connector.BurnRequest{Wallet: alice, Amount: inr(40000), LockID: lock.LockID}); err != nil {
		t.Fatalf("burn: %v", err)
	}
	// available stays 60000 (the 40000 was locked then burned)
	if bal, _ := c.Balance(ctx, alice); bal.Minor != 60000 {
		t.Fatalf("want 60000 after burn of locked funds, got %d", bal.Minor)
	}
}

func TestReleaseUnknownLock(t *testing.T) {
	c := newConn()
	_, err := c.Release(context.Background(), connector.ReleaseRequest{LockID: "does-not-exist"})
	if connector.CodeOf(err) != connector.CodeNotFound {
		t.Fatalf("want not_found, got %v", err)
	}
}

func TestValidationRejectsBadRequests(t *testing.T) {
	c := newConn()
	ctx := context.Background()
	if _, err := c.Issue(ctx, connector.IssueRequest{To: "", Amount: inr(1)}); connector.CodeOf(err) != connector.CodeValidation {
		t.Fatalf("want validation for empty wallet, got %v", err)
	}
	if _, err := c.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(0)}); connector.CodeOf(err) != connector.CodeValidation {
		t.Fatalf("want validation for zero amount, got %v", err)
	}
	if _, err := c.Transfer(ctx, connector.TransferRequest{From: alice, To: alice, Amount: inr(1)}); connector.CodeOf(err) != connector.CodeValidation {
		t.Fatalf("want validation for same-wallet transfer, got %v", err)
	}
}

func TestCurrencyMismatchRejected(t *testing.T) {
	c := newConn()
	_, err := c.Issue(context.Background(), connector.IssueRequest{To: alice, Amount: types.NewAmount(100, types.AED)})
	if connector.CodeOf(err) != connector.CodeValidation {
		t.Fatalf("want validation for currency mismatch, got %v", err)
	}
}

func TestIdempotencyReplay(t *testing.T) {
	c := newConn()
	ctx := context.Background()
	r1, _ := c.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(100000), IdempotencyKey: "k1"})
	r2, _ := c.Issue(ctx, connector.IssueRequest{To: alice, Amount: inr(100000), IdempotencyKey: "k1"})
	if r1.TxnID != r2.TxnID {
		t.Fatalf("idempotent replay should return same txn id: %s vs %s", r1.TxnID, r2.TxnID)
	}
	// balance credited only once
	if bal, _ := c.Balance(ctx, alice); bal.Minor != 100000 {
		t.Fatalf("want 100000 (single credit), got %d", bal.Minor)
	}
}
