// Package connector defines the standard interface that every CBDC network
// connector on the Fineract Cross-Border CBDC platform implements.
//
// A connector hides the details of a specific central-bank digital-currency
// network (India's e₹, the UAE Digital Dirham, GIFT City, and so on) behind one
// common contract, so the rest of the platform can issue, transfer, lock,
// release, burn, and redeem CBDC the same way regardless of the underlying
// network. This is the "universal adapter" at the edge of the system.
//
// The interface is deliberately small and free of any network-specific detail.
// Concrete connectors live in their own modules; a fully-featured in-memory
// implementation for tests and examples is provided in test/mock.
package connector

import (
	"context"

	"github.com/fineract/cbdc/connector-abstraction/types"
)

// Info describes a connector: a human-readable name, the network it talks to,
// and the currency it deals in.
type Info struct {
	Name     string         `json:"name"`
	Network  types.Network  `json:"network"`
	Currency types.Currency `json:"currency"`
}

// Connector is the standard CBDC connector interface (the CbdcConnectorInterface
// from the specification). Every method takes a context so callers can apply
// deadlines and cancellation, and returns a classified *Error on failure.
type Connector interface {
	// Info returns static metadata about this connector.
	Info() Info

	// Issue mints new CBDC into a wallet.
	Issue(ctx context.Context, req IssueRequest) (Receipt, error)

	// Transfer moves CBDC from one wallet to another.
	Transfer(ctx context.Context, req TransferRequest) (Receipt, error)

	// Lock reserves an amount so it cannot be spent until released or burned.
	// The returned Receipt carries the LockID.
	Lock(ctx context.Context, req LockRequest) (Receipt, error)

	// Release returns a previously locked amount to spendable balance.
	Release(ctx context.Context, req ReleaseRequest) (Receipt, error)

	// Burn permanently destroys CBDC, optionally consuming a lock.
	Burn(ctx context.Context, req BurnRequest) (Receipt, error)

	// Redeem converts CBDC back into commercial-bank money.
	Redeem(ctx context.Context, req RedeemRequest) (Receipt, error)

	// Balance returns the spendable (unlocked) balance of a wallet.
	Balance(ctx context.Context, wallet types.WalletID) (types.Amount, error)

	// HealthCheck reports whether the connector and its upstream network are
	// reachable and ready.
	HealthCheck(ctx context.Context) error
}
