module github.com/fineract/cbdc/connector-abstraction

go 1.21

require github.com/google/uuid v1.6.0
