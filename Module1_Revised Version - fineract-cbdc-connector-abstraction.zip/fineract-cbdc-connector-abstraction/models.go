package connector

import (
	"time"

	"github.com/fineract/cbdc/connector-abstraction/types"
	"github.com/fineract/cbdc/connector-abstraction/validation"
)

// IssueRequest asks the network to issue (mint) new CBDC into a wallet.
type IssueRequest struct {
	To             types.WalletID `json:"to"`
	Amount         types.Amount   `json:"amount"`
	Reference      string         `json:"reference"`
	IdempotencyKey string         `json:"idempotency_key"`
}

// Validate checks the request and returns a classified validation error.
func (r IssueRequest) Validate() error {
	if err := validation.Wallet("to", r.To); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.PositiveAmount("amount", r.Amount); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.IdempotencyKey(r.IdempotencyKey); err != nil {
		return NewValidationError(err.Error(), err)
	}
	return nil
}

// TransferRequest moves CBDC from one wallet to another.
type TransferRequest struct {
	From           types.WalletID `json:"from"`
	To             types.WalletID `json:"to"`
	Amount         types.Amount   `json:"amount"`
	Reference      string         `json:"reference"`
	IdempotencyKey string         `json:"idempotency_key"`
}

// Validate checks the request.
func (r TransferRequest) Validate() error {
	if err := validation.Wallet("from", r.From); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.Wallet("to", r.To); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if r.From == r.To {
		return NewValidationError("from and to must differ", nil)
	}
	if err := validation.PositiveAmount("amount", r.Amount); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.IdempotencyKey(r.IdempotencyKey); err != nil {
		return NewValidationError(err.Error(), err)
	}
	return nil
}

// LockRequest reserves an amount in a wallet so it cannot be spent until it is
// released or burned. This underpins the platform's lock-release-burn
// settlement flow.
type LockRequest struct {
	Wallet         types.WalletID `json:"wallet"`
	Amount         types.Amount   `json:"amount"`
	Reference      string         `json:"reference"`
	IdempotencyKey string         `json:"idempotency_key"`
}

// Validate checks the request.
func (r LockRequest) Validate() error {
	if err := validation.Wallet("wallet", r.Wallet); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.PositiveAmount("amount", r.Amount); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.IdempotencyKey(r.IdempotencyKey); err != nil {
		return NewValidationError(err.Error(), err)
	}
	return nil
}

// ReleaseRequest returns a previously locked amount to spendable balance.
type ReleaseRequest struct {
	LockID    string `json:"lock_id"`
	Reference string `json:"reference"`
}

// Validate checks the request.
func (r ReleaseRequest) Validate() error {
	if err := validation.NonEmpty("lock_id", r.LockID); err != nil {
		return NewValidationError(err.Error(), err)
	}
	return nil
}

// BurnRequest destroys CBDC. If LockID is set, the burn consumes that lock;
// otherwise it burns from the wallet's available balance.
type BurnRequest struct {
	Wallet         types.WalletID `json:"wallet"`
	Amount         types.Amount   `json:"amount"`
	LockID         string         `json:"lock_id,omitempty"`
	Reference      string         `json:"reference"`
	IdempotencyKey string         `json:"idempotency_key"`
}

// Validate checks the request.
func (r BurnRequest) Validate() error {
	if err := validation.Wallet("wallet", r.Wallet); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.PositiveAmount("amount", r.Amount); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.IdempotencyKey(r.IdempotencyKey); err != nil {
		return NewValidationError(err.Error(), err)
	}
	return nil
}

// RedeemRequest converts CBDC back into commercial-bank money, removing it from
// the wallet.
type RedeemRequest struct {
	Wallet         types.WalletID `json:"wallet"`
	Amount         types.Amount   `json:"amount"`
	Reference      string         `json:"reference"`
	IdempotencyKey string         `json:"idempotency_key"`
}

// Validate checks the request.
func (r RedeemRequest) Validate() error {
	if err := validation.Wallet("wallet", r.Wallet); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.PositiveAmount("amount", r.Amount); err != nil {
		return NewValidationError(err.Error(), err)
	}
	if err := validation.IdempotencyKey(r.IdempotencyKey); err != nil {
		return NewValidationError(err.Error(), err)
	}
	return nil
}

// Receipt is the common result of a connector operation.
type Receipt struct {
	TxnID     string          `json:"txn_id"`
	Operation types.Operation `json:"operation"`
	Status    types.Status    `json:"status"`
	Amount    types.Amount    `json:"amount"`
	// LockID is set only for a Lock operation.
	LockID    string    `json:"lock_id,omitempty"`
	CreatedAt time.Time `json:"created_at"`
}
