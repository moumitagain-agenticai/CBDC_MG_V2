// Package reqctx carries a request identifier through a context.Context so that
// logs, metrics, and traces for a single connector call can be correlated.
package reqctx

import (
	"context"

	"github.com/google/uuid"
)

type ctxKey int

const requestIDKey ctxKey = iota

// NewRequestID returns a fresh, unique request identifier.
func NewRequestID() string { return uuid.NewString() }

// WithRequestID returns a copy of ctx carrying the given request id.
func WithRequestID(ctx context.Context, id string) context.Context {
	return context.WithValue(ctx, requestIDKey, id)
}

// RequestID returns the request id carried by ctx, or "" if none is set.
func RequestID(ctx context.Context) string {
	if v, ok := ctx.Value(requestIDKey).(string); ok {
		return v
	}
	return ""
}

// EnsureRequestID returns ctx unchanged if it already carries a request id;
// otherwise it attaches a fresh one. It also returns the id in effect.
func EnsureRequestID(ctx context.Context) (context.Context, string) {
	if id := RequestID(ctx); id != "" {
		return ctx, id
	}
	id := NewRequestID()
	return WithRequestID(ctx, id), id
}
