// Package config holds the configuration a concrete connector needs, along with
// helpers to load it from the environment and validate it. Loading is done with
// the standard library only; a sample YAML file is provided in testdata for
// reference.
package config

import (
	"errors"
	"os"
	"strconv"
	"time"

	"github.com/fineract/cbdc/connector-abstraction/types"
)

// Config is the settings a connector is constructed with.
type Config struct {
	// Name is a human-readable connector name.
	Name string
	// Network is the CBDC network the connector talks to.
	Network types.Network
	// Currency is the currency the network deals in.
	Currency types.Currency
	// Endpoint is the base URL of the upstream network API.
	Endpoint string
	// Timeout bounds a single upstream call.
	Timeout time.Duration
	// MaxRetries is the number of times a transient upstream failure is retried.
	MaxRetries int
}

// Default returns a Config populated with safe defaults for the India e₹
// network. Callers typically override fields as needed.
func Default() Config {
	return Config{
		Name:       "india-erupee-connector",
		Network:    types.NetworkIndiaERupee,
		Currency:   types.INR,
		Endpoint:   "http://localhost:8080",
		Timeout:    30 * time.Second,
		MaxRetries: 3,
	}
}

// Validate reports whether the configuration is usable.
func (c Config) Validate() error {
	if c.Name == "" {
		return errors.New("config: name is required")
	}
	if !c.Network.Valid() {
		return errors.New("config: invalid or missing network")
	}
	if !c.Currency.Valid() {
		return errors.New("config: invalid or missing currency")
	}
	if c.Endpoint == "" {
		return errors.New("config: endpoint is required")
	}
	if c.Timeout <= 0 {
		return errors.New("config: timeout must be positive")
	}
	if c.MaxRetries < 0 {
		return errors.New("config: max_retries must not be negative")
	}
	return nil
}

// LoadFromEnv builds a Config from environment variables, starting from
// Default() and overriding any value that is set. Recognised variables:
//
//	CBDC_CONNECTOR_NAME
//	CBDC_NETWORK
//	CBDC_CURRENCY
//	CBDC_ENDPOINT
//	CBDC_TIMEOUT_SECONDS
//	CBDC_MAX_RETRIES
//
// It returns an error if a numeric variable is set but unparseable, or if the
// resulting configuration is invalid.
func LoadFromEnv() (Config, error) {
	c := Default()
	if v := os.Getenv("CBDC_CONNECTOR_NAME"); v != "" {
		c.Name = v
	}
	if v := os.Getenv("CBDC_NETWORK"); v != "" {
		c.Network = types.Network(v)
	}
	if v := os.Getenv("CBDC_CURRENCY"); v != "" {
		c.Currency = types.Currency(v)
	}
	if v := os.Getenv("CBDC_ENDPOINT"); v != "" {
		c.Endpoint = v
	}
	if v := os.Getenv("CBDC_TIMEOUT_SECONDS"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil {
			return Config{}, errors.New("config: CBDC_TIMEOUT_SECONDS is not a number")
		}
		c.Timeout = time.Duration(n) * time.Second
	}
	if v := os.Getenv("CBDC_MAX_RETRIES"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil {
			return Config{}, errors.New("config: CBDC_MAX_RETRIES is not a number")
		}
		c.MaxRetries = n
	}
	if err := c.Validate(); err != nil {
		return Config{}, err
	}
	return c, nil
}
