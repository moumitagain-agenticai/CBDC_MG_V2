// Package validation provides small, dependency-free validators for the
// connector abstraction's request fields. Each function returns a plain error
// describing the problem; the caller wraps it into a classified connector
// error. Keeping validation here (rather than pulling in a large third-party
// validator library) keeps the module self-contained and its dependency
// surface minimal.
package validation

import (
	"errors"
	"regexp"
	"strings"

	"github.com/fineract/cbdc/connector-abstraction/types"
)

// walletPattern allows letters, digits, dot, dash and underscore, 1–128 chars.
var walletPattern = regexp.MustCompile(`^[a-zA-Z0-9._-]{1,128}$`)

// idempotencyPattern allows letters, digits, dash and underscore, up to 128
// chars, used when an idempotency key is present.
var idempotencyPattern = regexp.MustCompile(`^[a-zA-Z0-9_-]{1,128}$`)

// NonEmpty checks that a string field is not blank.
func NonEmpty(field, value string) error {
	if strings.TrimSpace(value) == "" {
		return errors.New(field + " is required")
	}
	return nil
}

// Wallet checks that a wallet identifier is present and well-formed.
func Wallet(field string, w types.WalletID) error {
	if err := NonEmpty(field, string(w)); err != nil {
		return err
	}
	if !walletPattern.MatchString(string(w)) {
		return errors.New(field + " has an invalid format")
	}
	return nil
}

// PositiveAmount checks that an amount is well-formed and strictly positive.
func PositiveAmount(field string, a types.Amount) error {
	if err := a.Validate(); err != nil {
		return errors.New(field + ": " + err.Error())
	}
	if !a.IsPositive() {
		return errors.New(field + " must be positive")
	}
	return nil
}

// IdempotencyKey checks the optional idempotency key: if present it must match
// the allowed format; an empty key is permitted.
func IdempotencyKey(value string) error {
	if value == "" {
		return nil
	}
	if !idempotencyPattern.MatchString(value) {
		return errors.New("idempotency_key has an invalid format")
	}
	return nil
}
