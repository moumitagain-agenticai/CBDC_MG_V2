// Package tracing defines a minimal tracing abstraction for connector
// operations, with a no-op default. A deployment can supply an adapter that
// forwards to OpenTelemetry (or another tracer) behind the same interface,
// without pulling a tracing dependency into every importer.
package tracing

import "context"

// Span represents an in-progress traced operation.
type Span interface {
	// SetError records that the operation failed.
	SetError(err error)
	// End finishes the span.
	End()
}

// Tracer starts spans.
type Tracer interface {
	// Start begins a span named name and returns a context carrying it.
	Start(ctx context.Context, name string) (context.Context, Span)
}

// noopSpan is a span that records nothing.
type noopSpan struct{}

func (noopSpan) SetError(error) {}
func (noopSpan) End()           {}

// noopTracer is a Tracer that produces no-op spans.
type noopTracer struct{}

func (noopTracer) Start(ctx context.Context, _ string) (context.Context, Span) {
	return ctx, noopSpan{}
}

// NewNoop returns a Tracer that does nothing. It is the safe default when no
// tracing backend is configured.
func NewNoop() Tracer { return noopTracer{} }
