package types

import (
	"errors"
	"strconv"
)

// ErrCurrencyMismatch is returned when two amounts of different currencies are
// combined.
var ErrCurrencyMismatch = errors.New("currency mismatch")

// Amount is a monetary value held as an integer number of minor units (for
// example paise or fils) together with its currency. Using integers avoids the
// rounding errors that floating-point money is prone to.
type Amount struct {
	Minor    int64    `json:"minor"`
	Currency Currency `json:"currency"`
}

// NewAmount builds an Amount from a minor-unit value and a currency.
func NewAmount(minor int64, currency Currency) Amount {
	return Amount{Minor: minor, Currency: currency}
}

// IsZero reports whether the amount is exactly zero.
func (a Amount) IsZero() bool { return a.Minor == 0 }

// IsPositive reports whether the amount is greater than zero.
func (a Amount) IsPositive() bool { return a.Minor > 0 }

// Validate reports whether the amount is well-formed: a valid currency and a
// non-negative value.
func (a Amount) Validate() error {
	if !a.Currency.Valid() {
		return errors.New("invalid currency")
	}
	if a.Minor < 0 {
		return errors.New("amount must not be negative")
	}
	return nil
}

// Add returns the sum of two amounts of the same currency.
func (a Amount) Add(b Amount) (Amount, error) {
	if a.Currency != b.Currency {
		return Amount{}, ErrCurrencyMismatch
	}
	return Amount{Minor: a.Minor + b.Minor, Currency: a.Currency}, nil
}

// Sub returns a minus b, for two amounts of the same currency.
func (a Amount) Sub(b Amount) (Amount, error) {
	if a.Currency != b.Currency {
		return Amount{}, ErrCurrencyMismatch
	}
	return Amount{Minor: a.Minor - b.Minor, Currency: a.Currency}, nil
}

// GreaterThanOrEqual reports whether a >= b. Amounts of different currencies are
// never comparable and return false.
func (a Amount) GreaterThanOrEqual(b Amount) bool {
	return a.Currency == b.Currency && a.Minor >= b.Minor
}

// String renders the amount as "<minor> <currency>", for example "100000 INR".
func (a Amount) String() string {
	return strconv.FormatInt(a.Minor, 10) + " " + string(a.Currency)
}
