// Package types holds the primitive value types shared across the connector
// abstraction: currencies, networks, operations, statuses, and identifiers.
//
// These types deliberately contain no I/O and depend on nothing outside the
// standard library, so every other package can import them freely without
// creating cycles.
package types

// Currency is an ISO-4217 three-letter currency code (for example "INR").
type Currency string

// Well-known currencies used by the platform.
const (
	INR Currency = "INR" // Indian rupee
	AED Currency = "AED" // UAE dirham
	USD Currency = "USD" // US dollar
)

// Valid reports whether c looks like a three-letter uppercase code.
func (c Currency) Valid() bool {
	if len(c) != 3 {
		return false
	}
	for _, r := range c {
		if r < 'A' || r > 'Z' {
			return false
		}
	}
	return true
}

// Network identifies a CBDC network a connector talks to.
type Network string

// Supported CBDC networks.
const (
	NetworkIndiaERupee     Network = "india-erupee"       // India digital rupee (e₹)
	NetworkUAEDigitalDiria Network = "uae-digital-dirham" // UAE Digital Dirham
	NetworkGiftCity        Network = "giftcity"           // GIFT City provider
)

// Valid reports whether n is a recognised network.
func (n Network) Valid() bool {
	switch n {
	case NetworkIndiaERupee, NetworkUAEDigitalDiria, NetworkGiftCity:
		return true
	default:
		return false
	}
}

// Operation is one of the CBDC operations a connector can perform.
type Operation string

// The connector operations. These mirror the CbdcConnectorInterface:
// issue, transfer, lock, release, burn, redeem.
const (
	OpIssue    Operation = "issue"
	OpTransfer Operation = "transfer"
	OpLock     Operation = "lock"
	OpRelease  Operation = "release"
	OpBurn     Operation = "burn"
	OpRedeem   Operation = "redeem"
)

// Valid reports whether o is a recognised operation.
func (o Operation) Valid() bool {
	switch o {
	case OpIssue, OpTransfer, OpLock, OpRelease, OpBurn, OpRedeem:
		return true
	default:
		return false
	}
}

// Status is the outcome status of a connector operation.
type Status string

// Operation statuses.
const (
	StatusPending   Status = "PENDING"
	StatusCompleted Status = "COMPLETED"
	StatusFailed    Status = "FAILED"
)

// WalletID identifies a CBDC wallet on a network.
type WalletID string

// String returns the wallet id as a plain string.
func (w WalletID) String() string { return string(w) }
