package types

import "testing"

func TestAmountAddSub(t *testing.T) {
	a := NewAmount(100000, INR)
	b := NewAmount(40000, INR)
	sum, err := a.Add(b)
	if err != nil || sum.Minor != 140000 {
		t.Fatalf("add: %v %d", err, sum.Minor)
	}
	diff, err := a.Sub(b)
	if err != nil || diff.Minor != 60000 {
		t.Fatalf("sub: %v %d", err, diff.Minor)
	}
}

func TestAmountCurrencyMismatch(t *testing.T) {
	if _, err := NewAmount(1, INR).Add(NewAmount(1, AED)); err != ErrCurrencyMismatch {
		t.Fatalf("want ErrCurrencyMismatch, got %v", err)
	}
}

func TestAmountValidate(t *testing.T) {
	if err := NewAmount(-1, INR).Validate(); err == nil {
		t.Fatal("negative amount should be invalid")
	}
	if err := NewAmount(1, "rupee").Validate(); err == nil {
		t.Fatal("bad currency should be invalid")
	}
	if err := NewAmount(100, INR).Validate(); err != nil {
		t.Fatalf("valid amount rejected: %v", err)
	}
}
