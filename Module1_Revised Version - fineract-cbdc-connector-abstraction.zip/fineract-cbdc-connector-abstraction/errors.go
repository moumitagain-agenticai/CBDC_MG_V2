package connector

import "fmt"

// Code is a stable, machine-readable classification of a connector error. It
// lets callers react to the kind of failure without parsing messages.
type Code string

// Error codes returned by connectors.
const (
	CodeValidation        Code = "validation"         // the request was malformed
	CodeNotFound          Code = "not_found"          // a wallet or lock does not exist
	CodeInsufficientFunds Code = "insufficient_funds" // not enough available balance
	CodeConflict          Code = "conflict"           // idempotency clash or invalid state
	CodeUnsupported       Code = "unsupported"        // the operation is not supported
	CodeUnavailable       Code = "unavailable"        // the upstream network is unreachable
	CodeInternal          Code = "internal"           // an unexpected internal failure
)

// Error is the error type returned by every connector operation. It carries a
// classification Code, a human-readable Message, and an optional wrapped cause.
type Error struct {
	Code    Code
	Message string
	Err     error
}

// Error implements the error interface.
func (e *Error) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

// Unwrap exposes the wrapped cause for errors.Is / errors.As.
func (e *Error) Unwrap() error { return e.Err }

func newError(code Code, message string, err error) *Error {
	return &Error{Code: code, Message: message, Err: err}
}

// The following constructors build a classified Error. Pass nil for cause when
// there is no underlying error to wrap.

// NewValidationError reports a malformed request.
func NewValidationError(message string, cause error) *Error {
	return newError(CodeValidation, message, cause)
}

// NewNotFoundError reports a missing wallet or lock.
func NewNotFoundError(message string, cause error) *Error {
	return newError(CodeNotFound, message, cause)
}

// NewInsufficientFundsError reports that available balance is too low.
func NewInsufficientFundsError(message string, cause error) *Error {
	return newError(CodeInsufficientFunds, message, cause)
}

// NewConflictError reports an idempotency clash or an invalid state transition.
func NewConflictError(message string, cause error) *Error {
	return newError(CodeConflict, message, cause)
}

// NewUnsupportedError reports an operation a connector does not support.
func NewUnsupportedError(message string, cause error) *Error {
	return newError(CodeUnsupported, message, cause)
}

// NewUnavailableError reports that the upstream network is unreachable.
func NewUnavailableError(message string, cause error) *Error {
	return newError(CodeUnavailable, message, cause)
}

// NewInternalError reports an unexpected internal failure.
func NewInternalError(message string, cause error) *Error {
	return newError(CodeInternal, message, cause)
}

// CodeOf returns the Code of err if it is (or wraps) an *Error, and
// CodeInternal otherwise. It is safe to call with a nil error, in which case it
// returns an empty Code.
func CodeOf(err error) Code {
	if err == nil {
		return ""
	}
	var e *Error
	if as(err, &e) {
		return e.Code
	}
	return CodeInternal
}
