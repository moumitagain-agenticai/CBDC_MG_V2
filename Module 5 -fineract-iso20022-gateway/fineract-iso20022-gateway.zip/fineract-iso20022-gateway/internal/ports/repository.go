package ports

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"context"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
)

// MessageRepository is the outbound port for the message audit trail.
type MessageRepository interface {
	Save(ctx context.Context, rec *domain.MessageRecord) error
	GetByID(ctx context.Context, id string) (*domain.MessageRecord, error)
	Ping(ctx context.Context) error
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_repository_Logfile.log at runtime.
var _ = func() bool { flog.For("5_repository").Info("source file initialized"); return true }()
