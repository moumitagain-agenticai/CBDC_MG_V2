package domain

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"

// Party is a debtor/creditor/initiating party.
type Party struct {
	Name    string `json:"name"`
	Country string `json:"country,omitempty"`
}

// CreditTransfer is one credit-transfer transaction in a payment message.
type CreditTransfer struct {
	EndToEndID          string `json:"end_to_end_id"`
	InstructionID       string `json:"instruction_id,omitempty"`
	TransactionID       string `json:"transaction_id,omitempty"`
	Amount              string `json:"amount"`
	Currency            string `json:"currency"`
	CreditorName        string `json:"creditor_name"`
	CreditorAgentBIC    string `json:"creditor_agent_bic"`
	CreditorAccountIBAN string `json:"creditor_account_iban"`
	RemittanceInfo      string `json:"remittance_info,omitempty"`
}

// Pain001Request is the canonical input for generating a pain.001 message
// (customer credit transfer initiation).
type Pain001Request struct {
	MessageID              string           `json:"message_id"`
	CreationDateTime       string           `json:"creation_date_time,omitempty"` // RFC3339; defaults to now
	InitiatingParty        string           `json:"initiating_party"`
	PaymentInfoID          string           `json:"payment_info_id"`
	RequestedExecutionDate string           `json:"requested_execution_date"` // YYYY-MM-DD
	DebtorName             string           `json:"debtor_name"`
	DebtorAccountIBAN      string           `json:"debtor_account_iban"`
	DebtorAgentBIC         string           `json:"debtor_agent_bic"`
	Transactions           []CreditTransfer `json:"transactions"`
}

// Pacs008Request is the canonical input for generating a pacs.008 message
// (FI-to-FI customer credit transfer).
type Pacs008Request struct {
	MessageID           string           `json:"message_id"`
	CreationDateTime    string           `json:"creation_date_time,omitempty"`
	InstructingAgentBIC string           `json:"instructing_agent_bic"`
	InstructedAgentBIC  string           `json:"instructed_agent_bic"`
	SettlementMethod    string           `json:"settlement_method,omitempty"` // default CLRG
	DebtorName          string           `json:"debtor_name"`
	DebtorAccountIBAN   string           `json:"debtor_account_iban"`
	DebtorAgentBIC      string           `json:"debtor_agent_bic"`
	Transactions        []CreditTransfer `json:"transactions"`
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_payment_Logfile.log at runtime.
var _ = func() bool { flog.For("5_payment").Info("source file initialized"); return true }()
