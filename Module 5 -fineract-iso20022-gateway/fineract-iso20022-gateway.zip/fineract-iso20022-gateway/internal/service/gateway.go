package service

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"context"
	"strings"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/internal/iso20022"
	"github.com/fineract/cbdc/iso20022-gateway/internal/ports"
	"github.com/fineract/cbdc/iso20022-gateway/pkg/metrics"
	"github.com/fineract/cbdc/iso20022-gateway/pkg/utils"
)

// Gateway is the core ISO 20022 service: it generates, parses and validates
// pain.001 and pacs.008 messages and records an audit trail.
type Gateway struct {
	repo    ports.MessageRepository // optional; nil disables the audit trail
	metrics *metrics.Metrics
	log     *zap.Logger
}

// NewGateway wires the service. repo may be nil when persistence is disabled.
func NewGateway(repo ports.MessageRepository, m *metrics.Metrics, log *zap.Logger) *Gateway {
	return &Gateway{repo: repo, metrics: m, log: log}
}

// GeneratePain001 builds a pain.001 message and guarantees the output validates
// before returning it.
func (g *Gateway) GeneratePain001(ctx context.Context, req domain.Pain001Request) ([]byte, error) {
	defer g.observe("generate_pain001")()

	xmlBytes, err := iso20022.BuildPain001(req)
	if err != nil {
		return nil, g.fail("generate_pain001", err)
	}
	if err := g.ensureValid("generate_pain001", xmlBytes); err != nil {
		return nil, err
	}

	amts := amountsOf(req.Transactions)
	ctrlSum, _ := utils.SumAmounts(amts)
	g.audit(ctx, domain.MsgPain001, req.MessageID, domain.DirectionOutbound, len(req.Transactions), ctrlSum, currencyOf(req.Transactions), true)
	g.metrics.MessagesTotal.WithLabelValues(string(domain.MsgPain001), "generate").Inc()
	return xmlBytes, nil
}

// GeneratePacs008 builds a pacs.008 message and guarantees it validates.
func (g *Gateway) GeneratePacs008(ctx context.Context, req domain.Pacs008Request) ([]byte, error) {
	defer g.observe("generate_pacs008")()

	xmlBytes, err := iso20022.BuildPacs008(req)
	if err != nil {
		return nil, g.fail("generate_pacs008", err)
	}
	if err := g.ensureValid("generate_pacs008", xmlBytes); err != nil {
		return nil, err
	}

	amts := amountsOf(req.Transactions)
	total, _ := utils.SumAmounts(amts)
	g.audit(ctx, domain.MsgPacs008, req.MessageID, domain.DirectionOutbound, len(req.Transactions), total, currencyOf(req.Transactions), true)
	g.metrics.MessagesTotal.WithLabelValues(string(domain.MsgPacs008), "generate").Inc()
	return xmlBytes, nil
}

// ParsePain001 parses inbound pain.001 XML into its document model.
func (g *Gateway) ParsePain001(ctx context.Context, data []byte) (*iso20022.Pain001Document, error) {
	defer g.observe("parse_pain001")()
	doc, err := iso20022.ParsePain001(data)
	if err != nil {
		return nil, g.fail("parse_pain001", err)
	}
	g.metrics.MessagesTotal.WithLabelValues(string(domain.MsgPain001), "parse").Inc()
	return doc, nil
}

// ParsePacs008 parses inbound pacs.008 XML into its document model.
func (g *Gateway) ParsePacs008(ctx context.Context, data []byte) (*iso20022.Pacs008Document, error) {
	defer g.observe("parse_pacs008")()
	doc, err := iso20022.ParsePacs008(data)
	if err != nil {
		return nil, g.fail("parse_pacs008", err)
	}
	g.metrics.MessagesTotal.WithLabelValues(string(domain.MsgPacs008), "parse").Inc()
	return doc, nil
}

// Validate detects the message type and runs its rule set.
func (g *Gateway) Validate(ctx context.Context, data []byte) (iso20022.ValidationResult, error) {
	defer g.observe("validate")()
	res, err := iso20022.ValidateXML(data)
	if err != nil {
		return iso20022.ValidationResult{}, g.fail("validate", err)
	}
	g.audit(ctx, domain.MessageType(res.MessageType), "", domain.DirectionInbound, 0, "", "", res.Valid)
	g.metrics.MessagesTotal.WithLabelValues(res.MessageType, "validate").Inc()
	return res, nil
}

// ---- helpers ----

func (g *Gateway) ensureValid(op string, xmlBytes []byte) error {
	vr, err := iso20022.ValidateXML(xmlBytes)
	if err != nil {
		return g.fail(op, err)
	}
	if !vr.Valid {
		return g.fail(op, domain.NewValidationError("generated message failed validation: "+strings.Join(vr.Errors, "; "), nil))
	}
	return nil
}

func (g *Gateway) observe(op string) func() {
	start := time.Now()
	return func() {
		g.metrics.MessageLatency.WithLabelValues(op).Observe(time.Since(start).Seconds())
	}
}

func (g *Gateway) fail(op string, err error) error {
	de := domain.AsDomainError(err)
	g.metrics.MessageErrors.WithLabelValues(op, string(de.Code)).Inc()
	g.log.Warn("iso20022 operation failed", zap.String("op", op), zap.Error(err))
	return de
}

func (g *Gateway) audit(ctx context.Context, mt domain.MessageType, msgID string, dir domain.Direction, n int, ctrlSum, ccy string, valid bool) {
	if g.repo == nil {
		return
	}
	rec := &domain.MessageRecord{
		ID:          uuid.NewString(),
		MessageID:   msgID,
		MessageType: mt,
		Direction:   dir,
		NumTxs:      n,
		ControlSum:  ctrlSum,
		Currency:    ccy,
		Valid:       valid,
		CreatedAt:   time.Now().UTC(),
	}
	if err := g.repo.Save(ctx, rec); err != nil {
		g.log.Error("failed to persist message audit record", zap.Error(err))
	}
}

func amountsOf(txs []domain.CreditTransfer) []string {
	out := make([]string, 0, len(txs))
	for _, t := range txs {
		out = append(out, t.Amount)
	}
	return out
}

func currencyOf(txs []domain.CreditTransfer) string {
	if len(txs) == 0 {
		return ""
	}
	return txs[0].Currency
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_gateway_Logfile.log at runtime.
var _ = func() bool { flog.For("5_gateway").Info("source file initialized"); return true }()
