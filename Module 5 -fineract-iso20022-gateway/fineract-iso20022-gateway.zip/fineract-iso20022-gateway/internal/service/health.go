package service

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import "context"

// HealthReport is the aggregated health of the gateway.
type HealthReport struct {
	Status string            `json:"status"`
	Checks map[string]string `json:"checks"`
}

// Liveness reports process health with no I/O.
func (g *Gateway) Liveness() HealthReport {
	return HealthReport{Status: "ok", Checks: map[string]string{"process": "ok"}}
}

// Readiness reports whether the gateway can serve traffic. The message engine is
// always ready; the database (if enabled) must respond.
func (g *Gateway) Readiness(ctx context.Context) HealthReport {
	checks := map[string]string{"engine": "ok"}
	status := "ok"
	if g.repo != nil {
		if err := g.repo.Ping(ctx); err != nil {
			checks["database"] = "error: " + err.Error()
			status = "degraded"
		} else {
			checks["database"] = "ok"
		}
	}
	return HealthReport{Status: status, Checks: checks}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_health_Logfile.log at runtime.
var _ = func() bool { flog.For("5_health").Info("source file initialized"); return true }()
