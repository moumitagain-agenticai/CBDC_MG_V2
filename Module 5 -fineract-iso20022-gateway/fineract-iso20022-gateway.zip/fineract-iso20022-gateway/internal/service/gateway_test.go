package service_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/internal/iso20022"
	"github.com/fineract/cbdc/iso20022-gateway/internal/service"
	"github.com/fineract/cbdc/iso20022-gateway/pkg/metrics"
	"github.com/fineract/cbdc/iso20022-gateway/test/mocks"
)

func pain001Req() domain.Pain001Request {
	return domain.Pain001Request{
		MessageID:              "MSG-1",
		InitiatingParty:        "Acme",
		PaymentInfoID:          "PMT-1",
		RequestedExecutionDate: "2026-08-15",
		DebtorName:             "Acme",
		DebtorAccountIBAN:      "DE89370400440532013000",
		DebtorAgentBIC:         "DEUTDEFF",
		Transactions: []domain.CreditTransfer{
			{EndToEndID: "E1", Amount: "10.00", Currency: "EUR", CreditorName: "Beta", CreditorAgentBIC: "NWBKGB2L", CreditorAccountIBAN: "GB29NWBK60161331926819"},
		},
	}
}

func TestGeneratePain001_ProducesValidAndAudits(t *testing.T) {
	repo := &mocks.MockMessageRepository{}
	g := service.NewGateway(repo, metrics.New(), zap.NewNop())

	out, err := g.GeneratePain001(context.Background(), pain001Req())
	require.NoError(t, err)

	// The output must itself validate.
	res, err := iso20022.ValidateXML(out)
	require.NoError(t, err)
	assert.True(t, res.Valid, "errors: %v", res.Errors)

	// An audit record was written.
	require.Len(t, repo.Saved, 1)
	assert.Equal(t, domain.MsgPain001, repo.Saved[0].MessageType)
	assert.Equal(t, domain.DirectionOutbound, repo.Saved[0].Direction)
	assert.Equal(t, "10", repo.Saved[0].ControlSum)
}

func TestGeneratePacs008_ProducesValid(t *testing.T) {
	g := service.NewGateway(nil, metrics.New(), zap.NewNop())
	req := domain.Pacs008Request{
		MessageID:           "FI-1",
		InstructingAgentBIC: "DEUTDEFF",
		InstructedAgentBIC:  "NWBKGB2L",
		DebtorName:          "Acme",
		DebtorAccountIBAN:   "DE89370400440532013000",
		DebtorAgentBIC:      "DEUTDEFF",
		Transactions: []domain.CreditTransfer{
			{EndToEndID: "E1", Amount: "500.00", Currency: "EUR", CreditorName: "Beta", CreditorAgentBIC: "NWBKGB2L", CreditorAccountIBAN: "GB29NWBK60161331926819"},
		},
	}
	out, err := g.GeneratePacs008(context.Background(), req)
	require.NoError(t, err)
	res, err := iso20022.ValidateXML(out)
	require.NoError(t, err)
	assert.True(t, res.Valid, "errors: %v", res.Errors)
}

func TestValidate_RejectsBadMessage(t *testing.T) {
	g := service.NewGateway(nil, metrics.New(), zap.NewNop())
	req := pain001Req()
	req.Transactions[0].CreditorAgentBIC = "BAD" // invalid BIC
	out, err := iso20022.BuildPain001(req)
	require.NoError(t, err)

	res, err := g.Validate(context.Background(), out)
	require.NoError(t, err)
	assert.False(t, res.Valid)
	assert.NotEmpty(t, res.Errors)
}
