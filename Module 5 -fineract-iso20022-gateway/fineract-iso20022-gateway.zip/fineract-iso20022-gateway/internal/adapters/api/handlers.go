package api

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"encoding/json"
	"io"
	"net/http"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/internal/service"
)

// Handler exposes the ISO 20022 gateway over HTTP.
type Handler struct {
	svc      *service.Gateway
	maxBytes int64
}

// NewHandler builds an HTTP handler around the gateway service.
func NewHandler(svc *service.Gateway, maxBytes int64) *Handler {
	if maxBytes <= 0 {
		maxBytes = 1 << 20
	}
	return &Handler{svc: svc, maxBytes: maxBytes}
}

func (h *Handler) GeneratePain001(w http.ResponseWriter, r *http.Request) {
	var req domain.Pain001Request
	if !decodeJSON(w, r, h.maxBytes, &req) {
		return
	}
	out, err := h.svc.GeneratePain001(r.Context(), req)
	respondXML(w, out, err)
}

func (h *Handler) GeneratePacs008(w http.ResponseWriter, r *http.Request) {
	var req domain.Pacs008Request
	if !decodeJSON(w, r, h.maxBytes, &req) {
		return
	}
	out, err := h.svc.GeneratePacs008(r.Context(), req)
	respondXML(w, out, err)
}

func (h *Handler) ParsePain001(w http.ResponseWriter, r *http.Request) {
	body, ok := readBody(w, r, h.maxBytes)
	if !ok {
		return
	}
	doc, err := h.svc.ParsePain001(r.Context(), body)
	respondJSON(w, http.StatusOK, doc, err)
}

func (h *Handler) ParsePacs008(w http.ResponseWriter, r *http.Request) {
	body, ok := readBody(w, r, h.maxBytes)
	if !ok {
		return
	}
	doc, err := h.svc.ParsePacs008(r.Context(), body)
	respondJSON(w, http.StatusOK, doc, err)
}

func (h *Handler) Validate(w http.ResponseWriter, r *http.Request) {
	body, ok := readBody(w, r, h.maxBytes)
	if !ok {
		return
	}
	res, err := h.svc.Validate(r.Context(), body)
	if err != nil {
		writeError(w, err)
		return
	}
	// A well-formed but rule-invalid message returns 422 with the error list.
	status := http.StatusOK
	if !res.Valid {
		status = http.StatusUnprocessableEntity
	}
	writeJSON(w, status, res)
}

func (h *Handler) Liveness(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, h.svc.Liveness())
}

func (h *Handler) Readiness(w http.ResponseWriter, r *http.Request) {
	rep := h.svc.Readiness(r.Context())
	status := http.StatusOK
	if rep.Status != "ok" {
		status = http.StatusServiceUnavailable
	}
	writeJSON(w, status, rep)
}

// ---- helpers ----

func readBody(w http.ResponseWriter, r *http.Request, max int64) ([]byte, bool) {
	r.Body = http.MaxBytesReader(w, r.Body, max)
	body, err := io.ReadAll(r.Body)
	if err != nil {
		writeError(w, domain.NewValidationError("request body too large or unreadable", err))
		return nil, false
	}
	if len(body) == 0 {
		writeError(w, domain.NewValidationError("empty request body", nil))
		return nil, false
	}
	return body, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, max int64, dst any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, max)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		writeError(w, domain.NewValidationError("invalid JSON body", err))
		return false
	}
	return true
}

func respondXML(w http.ResponseWriter, out []byte, err error) {
	if err != nil {
		writeError(w, err)
		return
	}
	w.Header().Set("Content-Type", "application/xml")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(out)
}

func respondJSON(w http.ResponseWriter, status int, payload any, err error) {
	if err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, status, payload)
}

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if payload != nil {
		_ = json.NewEncoder(w).Encode(payload)
	}
}

type errorBody struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, err error) {
	de := domain.AsDomainError(err)
	var body errorBody
	body.Error.Code = string(de.Code)
	body.Error.Message = de.Message
	writeJSON(w, httpStatus(de.Code), body)
}

func httpStatus(code domain.ErrorCode) int {
	switch code {
	case domain.CodeValidation:
		return http.StatusBadRequest
	case domain.CodeNotFound:
		return http.StatusNotFound
	case domain.CodeConflict:
		return http.StatusConflict
	case domain.CodeUnauthorized:
		return http.StatusUnauthorized
	default:
		return http.StatusInternalServerError
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_handlers_Logfile.log at runtime.
var _ = func() bool { flog.For("5_handlers").Info("source file initialized"); return true }()
