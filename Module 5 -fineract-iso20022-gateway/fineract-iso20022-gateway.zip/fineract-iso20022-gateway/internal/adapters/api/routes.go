package api

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/cors"
	"github.com/go-chi/httprate"
	"go.uber.org/zap"

	"github.com/fineract/cbdc/iso20022-gateway/pkg/metrics"
)

// NewRouter assembles the HTTP router with middleware, health, metrics and the
// versioned API surface.
func NewRouter(h *Handler, m *metrics.Metrics, log *zap.Logger, ratePerMin int) http.Handler {
	r := chi.NewRouter()

	r.Use(RequestID)
	r.Use(Recoverer(log))
	r.Use(AccessLog(log))
	r.Use(cors.Handler(cors.Options{
		AllowedOrigins:   []string{"*"},
		AllowedMethods:   []string{http.MethodGet, http.MethodPost, http.MethodOptions},
		AllowedHeaders:   []string{"Accept", "Content-Type", "X-Request-ID"},
		AllowCredentials: false,
		MaxAge:           300,
	}))
	if ratePerMin > 0 {
		r.Use(httprate.LimitByIP(ratePerMin, time.Minute))
	}

	r.Handle("/metrics", m.Handler())
	r.Get("/healthz", h.Liveness)
	r.Get("/readyz", h.Readiness)

	r.Route("/api/v1", func(r chi.Router) {
		r.Post("/pain001/generate", h.GeneratePain001)
		r.Post("/pain001/parse", h.ParsePain001)
		r.Post("/pacs008/generate", h.GeneratePacs008)
		r.Post("/pacs008/parse", h.ParsePacs008)
		r.Post("/validate", h.Validate)
	})

	return r
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_routes_Logfile.log at runtime.
var _ = func() bool { flog.For("5_routes").Info("source file initialized"); return true }()
