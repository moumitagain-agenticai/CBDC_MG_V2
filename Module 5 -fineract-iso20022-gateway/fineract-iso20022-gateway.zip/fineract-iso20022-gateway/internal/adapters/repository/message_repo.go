package repository

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"context"
	"database/sql"
	"errors"

	_ "github.com/lib/pq" // postgres driver (side-effect import)

	"github.com/fineract/cbdc/iso20022-gateway/internal/config"
	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/internal/ports"
)

// Repository is a PostgreSQL-backed message audit store.
type Repository struct {
	db *sql.DB
}

var _ ports.MessageRepository = (*Repository)(nil)

// OpenDB opens and configures a *sql.DB from database configuration.
func OpenDB(cfg config.DatabaseConfig) (*sql.DB, error) {
	db, err := sql.Open("postgres", cfg.DSN)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(cfg.MaxOpenConns)
	db.SetMaxIdleConns(cfg.MaxIdleConns)
	db.SetConnMaxLifetime(cfg.ConnMaxLifetime)
	return db, nil
}

// New builds a Repository over an existing *sql.DB.
func New(db *sql.DB) *Repository { return &Repository{db: db} }

func (r *Repository) Save(ctx context.Context, rec *domain.MessageRecord) error {
	const q = `
INSERT INTO iso20022_messages
  (id, message_id, message_type, direction, num_txs, control_sum, currency, valid, created_at)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`
	_, err := r.db.ExecContext(ctx, q,
		rec.ID, rec.MessageID, rec.MessageType, rec.Direction, rec.NumTxs,
		rec.ControlSum, rec.Currency, rec.Valid, rec.CreatedAt,
	)
	if err != nil {
		return domain.NewInternalError("persist message record", err)
	}
	return nil
}

func (r *Repository) GetByID(ctx context.Context, id string) (*domain.MessageRecord, error) {
	const q = `
SELECT id, message_id, message_type, direction, num_txs, control_sum, currency, valid, created_at
  FROM iso20022_messages WHERE id = $1`
	row := r.db.QueryRowContext(ctx, q, id)
	var m domain.MessageRecord
	err := row.Scan(&m.ID, &m.MessageID, &m.MessageType, &m.Direction, &m.NumTxs,
		&m.ControlSum, &m.Currency, &m.Valid, &m.CreatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, domain.NewNotFoundError("message record not found", err)
	}
	if err != nil {
		return nil, domain.NewInternalError("scan message record", err)
	}
	return &m, nil
}

func (r *Repository) Ping(ctx context.Context) error {
	if err := r.db.PingContext(ctx); err != nil {
		return domain.NewInternalError("database ping failed", err)
	}
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_message_repo_Logfile.log at runtime.
var _ = func() bool { flog.For("5_message_repo").Info("source file initialized"); return true }()
