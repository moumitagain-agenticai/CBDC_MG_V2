package iso20022

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"encoding/xml"
	"time"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/pkg/utils"
)

// NSPacs008 is the ISO 20022 namespace for pacs.008.001.08.
const NSPacs008 = "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08"

// ---- pacs.008.001.08 XML model (credit-transfer subset) ----

type Pacs008Document struct {
	XMLName           xml.Name             `xml:"urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08 Document"`
	FIToFICstmrCdtTrf FIToFICreditTransfer `xml:"FIToFICstmrCdtTrf"`
}

type FIToFICreditTransfer struct {
	GrpHdr      Pacs008GroupHeader `xml:"GrpHdr"`
	CdtTrfTxInf []Pacs008Tx        `xml:"CdtTrfTxInf"`
}

type Pacs008GroupHeader struct {
	MsgID             string         `xml:"MsgId"`
	CreDtTm           string         `xml:"CreDtTm"`
	NbOfTxs           int            `xml:"NbOfTxs"`
	TtlIntrBkSttlmAmt CcyAmount      `xml:"TtlIntrBkSttlmAmt"`
	SttlmInf          SettlementInfo `xml:"SttlmInf"`
	InstgAgt          Agent          `xml:"InstgAgt"`
	InstdAgt          Agent          `xml:"InstdAgt"`
}

type CcyAmount struct {
	Ccy   string `xml:"Ccy,attr"`
	Value string `xml:",chardata"`
}

type SettlementInfo struct {
	SttlmMtd string `xml:"SttlmMtd"`
}

type Pacs008Tx struct {
	PmtID          Pacs008PaymentID `xml:"PmtId"`
	IntrBkSttlmAmt CcyAmount        `xml:"IntrBkSttlmAmt"`
	ChrgBr         string           `xml:"ChrgBr"`
	Dbtr           PartyName        `xml:"Dbtr"`
	DbtrAcct       Account          `xml:"DbtrAcct"`
	DbtrAgt        Agent            `xml:"DbtrAgt"`
	CdtrAgt        Agent            `xml:"CdtrAgt"`
	Cdtr           PartyName        `xml:"Cdtr"`
	CdtrAcct       Account          `xml:"CdtrAcct"`
	RmtInf         *Remittance      `xml:"RmtInf,omitempty"`
}

type Pacs008PaymentID struct {
	InstrID    string `xml:"InstrId"`
	EndToEndID string `xml:"EndToEndId"`
	TxID       string `xml:"TxId"`
}

// BuildPacs008 renders a pacs.008.001.08 XML document from canonical input.
func BuildPacs008(req domain.Pacs008Request) ([]byte, error) {
	creDtTm := time.Now().UTC().Format("2006-01-02T15:04:05")
	if req.CreationDateTime != "" {
		if t, err := time.Parse(time.RFC3339, req.CreationDateTime); err == nil {
			creDtTm = t.UTC().Format("2006-01-02T15:04:05")
		}
	}
	sttlmMtd := req.SettlementMethod
	if sttlmMtd == "" {
		sttlmMtd = "CLRG"
	}

	amts := make([]string, 0, len(req.Transactions))
	txs := make([]Pacs008Tx, 0, len(req.Transactions))
	var ccy string
	for _, t := range req.Transactions {
		amts = append(amts, t.Amount)
		if ccy == "" {
			ccy = t.Currency
		}
		var rmt *Remittance
		if t.RemittanceInfo != "" {
			rmt = &Remittance{Ustrd: t.RemittanceInfo}
		}
		txs = append(txs, Pacs008Tx{
			PmtID: Pacs008PaymentID{
				InstrID:    t.InstructionID,
				EndToEndID: t.EndToEndID,
				TxID:       t.TransactionID,
			},
			IntrBkSttlmAmt: CcyAmount{Ccy: t.Currency, Value: t.Amount},
			ChrgBr:         "SLEV",
			Dbtr:           PartyName{Nm: req.DebtorName},
			DbtrAcct:       Account{ID: AccountID{IBAN: req.DebtorAccountIBAN}},
			DbtrAgt:        Agent{FinInstnID: FinancialInstitution{BICFI: req.DebtorAgentBIC}},
			CdtrAgt:        Agent{FinInstnID: FinancialInstitution{BICFI: t.CreditorAgentBIC}},
			Cdtr:           PartyName{Nm: t.CreditorName},
			CdtrAcct:       Account{ID: AccountID{IBAN: t.CreditorAccountIBAN}},
			RmtInf:         rmt,
		})
	}
	total, _ := utils.SumAmounts(amts)

	doc := Pacs008Document{
		FIToFICstmrCdtTrf: FIToFICreditTransfer{
			GrpHdr: Pacs008GroupHeader{
				MsgID:             req.MessageID,
				CreDtTm:           creDtTm,
				NbOfTxs:           len(req.Transactions),
				TtlIntrBkSttlmAmt: CcyAmount{Ccy: ccy, Value: total},
				SttlmInf:          SettlementInfo{SttlmMtd: sttlmMtd},
				InstgAgt:          Agent{FinInstnID: FinancialInstitution{BICFI: req.InstructingAgentBIC}},
				InstdAgt:          Agent{FinInstnID: FinancialInstitution{BICFI: req.InstructedAgentBIC}},
			},
			CdtTrfTxInf: txs,
		},
	}

	out, err := xml.MarshalIndent(doc, "", "  ")
	if err != nil {
		return nil, domain.NewInternalError("marshal pacs.008", err)
	}
	return append([]byte(xml.Header), out...), nil
}

// ParsePacs008 unmarshals a pacs.008 XML document.
func ParsePacs008(data []byte) (*Pacs008Document, error) {
	var doc Pacs008Document
	if err := xml.Unmarshal(data, &doc); err != nil {
		return nil, domain.NewValidationError("invalid pacs.008 XML", err)
	}
	return &doc, nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_pacs008_Logfile.log at runtime.
var _ = func() bool { flog.For("5_pacs008").Info("source file initialized"); return true }()
