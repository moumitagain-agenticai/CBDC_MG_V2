package iso20022

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"encoding/xml"
	"time"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/pkg/utils"
)

// NSPain001 is the ISO 20022 namespace for pain.001.001.09.
const NSPain001 = "urn:iso:std:iso:20022:tech:xsd:pain.001.001.09"

// ---- pain.001.001.09 XML model (credit-transfer subset) ----

type Pain001Document struct {
	XMLName          xml.Name            `xml:"urn:iso:std:iso:20022:tech:xsd:pain.001.001.09 Document"`
	CstmrCdtTrfInitn CustomerCreditInitn `xml:"CstmrCdtTrfInitn"`
}

type CustomerCreditInitn struct {
	GrpHdr Pain001GroupHeader `xml:"GrpHdr"`
	PmtInf PaymentInstruction `xml:"PmtInf"`
}

type Pain001GroupHeader struct {
	MsgID    string    `xml:"MsgId"`
	CreDtTm  string    `xml:"CreDtTm"`
	NbOfTxs  int       `xml:"NbOfTxs"`
	CtrlSum  string    `xml:"CtrlSum"`
	InitgPty PartyName `xml:"InitgPty"`
}

type PaymentInstruction struct {
	PmtInfID    string             `xml:"PmtInfId"`
	PmtMtd      string             `xml:"PmtMtd"`
	NbOfTxs     int                `xml:"NbOfTxs"`
	CtrlSum     string             `xml:"CtrlSum"`
	ReqdExctnDt ExecutionDate      `xml:"ReqdExctnDt"`
	Dbtr        PartyName          `xml:"Dbtr"`
	DbtrAcct    Account            `xml:"DbtrAcct"`
	DbtrAgt     Agent              `xml:"DbtrAgt"`
	CdtTrfTxInf []CreditTransferTx `xml:"CdtTrfTxInf"`
}

type ExecutionDate struct {
	Dt string `xml:"Dt"`
}

type PartyName struct {
	Nm string `xml:"Nm"`
}

type Account struct {
	ID AccountID `xml:"Id"`
}

type AccountID struct {
	IBAN string `xml:"IBAN"`
}

type Agent struct {
	FinInstnID FinancialInstitution `xml:"FinInstnId"`
}

type FinancialInstitution struct {
	BICFI string `xml:"BICFI"`
}

type CreditTransferTx struct {
	PmtID    PaymentID   `xml:"PmtId"`
	Amt      Amount      `xml:"Amt"`
	CdtrAgt  Agent       `xml:"CdtrAgt"`
	Cdtr     PartyName   `xml:"Cdtr"`
	CdtrAcct Account     `xml:"CdtrAcct"`
	RmtInf   *Remittance `xml:"RmtInf,omitempty"`
}

type PaymentID struct {
	EndToEndID string `xml:"EndToEndId"`
}

type Amount struct {
	InstdAmt InstructedAmount `xml:"InstdAmt"`
}

type InstructedAmount struct {
	Ccy   string `xml:"Ccy,attr"`
	Value string `xml:",chardata"`
}

type Remittance struct {
	Ustrd string `xml:"Ustrd"`
}

// BuildPain001 renders a pain.001.001.09 XML document from canonical input.
// NbOfTxs and CtrlSum are derived from the transactions.
func BuildPain001(req domain.Pain001Request) ([]byte, error) {
	creDtTm := time.Now().UTC().Format("2006-01-02T15:04:05")
	if req.CreationDateTime != "" {
		if t, err := time.Parse(time.RFC3339, req.CreationDateTime); err == nil {
			creDtTm = t.UTC().Format("2006-01-02T15:04:05")
		}
	}

	amts := make([]string, 0, len(req.Transactions))
	txs := make([]CreditTransferTx, 0, len(req.Transactions))
	for _, t := range req.Transactions {
		amts = append(amts, t.Amount)
		var rmt *Remittance
		if t.RemittanceInfo != "" {
			rmt = &Remittance{Ustrd: t.RemittanceInfo}
		}
		txs = append(txs, CreditTransferTx{
			PmtID:    PaymentID{EndToEndID: t.EndToEndID},
			Amt:      Amount{InstdAmt: InstructedAmount{Ccy: t.Currency, Value: t.Amount}},
			CdtrAgt:  Agent{FinInstnID: FinancialInstitution{BICFI: t.CreditorAgentBIC}},
			Cdtr:     PartyName{Nm: t.CreditorName},
			CdtrAcct: Account{ID: AccountID{IBAN: t.CreditorAccountIBAN}},
			RmtInf:   rmt,
		})
	}
	ctrlSum, _ := utils.SumAmounts(amts)

	doc := Pain001Document{
		CstmrCdtTrfInitn: CustomerCreditInitn{
			GrpHdr: Pain001GroupHeader{
				MsgID:    req.MessageID,
				CreDtTm:  creDtTm,
				NbOfTxs:  len(req.Transactions),
				CtrlSum:  ctrlSum,
				InitgPty: PartyName{Nm: req.InitiatingParty},
			},
			PmtInf: PaymentInstruction{
				PmtInfID:    req.PaymentInfoID,
				PmtMtd:      "TRF",
				NbOfTxs:     len(req.Transactions),
				CtrlSum:     ctrlSum,
				ReqdExctnDt: ExecutionDate{Dt: req.RequestedExecutionDate},
				Dbtr:        PartyName{Nm: req.DebtorName},
				DbtrAcct:    Account{ID: AccountID{IBAN: req.DebtorAccountIBAN}},
				DbtrAgt:     Agent{FinInstnID: FinancialInstitution{BICFI: req.DebtorAgentBIC}},
				CdtTrfTxInf: txs,
			},
		},
	}

	out, err := xml.MarshalIndent(doc, "", "  ")
	if err != nil {
		return nil, domain.NewInternalError("marshal pain.001", err)
	}
	return append([]byte(xml.Header), out...), nil
}

// ParsePain001 unmarshals a pain.001 XML document.
func ParsePain001(data []byte) (*Pain001Document, error) {
	var doc Pain001Document
	if err := xml.Unmarshal(data, &doc); err != nil {
		return nil, domain.NewValidationError("invalid pain.001 XML", err)
	}
	return &doc, nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_pain001_Logfile.log at runtime.
var _ = func() bool { flog.For("5_pain001").Info("source file initialized"); return true }()
