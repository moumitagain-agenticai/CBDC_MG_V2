package iso20022_test

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/internal/iso20022"
)

// Canonical, checksum-valid test data.
const (
	ibanDE = "DE89370400440532013000"
	ibanGB = "GB29NWBK60161331926819"
	bicDE  = "DEUTDEFF"
	bicGB  = "NWBKGB2L"
)

func validPain001() domain.Pain001Request {
	return domain.Pain001Request{
		MessageID:              "MSG-0001",
		InitiatingParty:        "Acme Corp",
		PaymentInfoID:          "PMT-0001",
		RequestedExecutionDate: "2026-08-15",
		DebtorName:             "Acme Corp",
		DebtorAccountIBAN:      ibanDE,
		DebtorAgentBIC:         bicDE,
		Transactions: []domain.CreditTransfer{
			{EndToEndID: "E2E-1", Amount: "100.50", Currency: "EUR", CreditorName: "Beta Ltd", CreditorAgentBIC: bicGB, CreditorAccountIBAN: ibanGB, RemittanceInfo: "Invoice 42"},
			{EndToEndID: "E2E-2", Amount: "250.00", Currency: "EUR", CreditorName: "Gamma Ltd", CreditorAgentBIC: bicGB, CreditorAccountIBAN: ibanGB},
		},
	}
}

func TestPain001_RoundTripAndValidate(t *testing.T) {
	xmlBytes, err := iso20022.BuildPain001(validPain001())
	require.NoError(t, err)

	s := string(xmlBytes)
	assert.Contains(t, s, iso20022.NSPain001)
	assert.Contains(t, s, "<CtrlSum>350.5</CtrlSum>")
	assert.Contains(t, s, "<NbOfTxs>2</NbOfTxs>")
	assert.Contains(t, s, `Ccy="EUR"`)

	doc, err := iso20022.ParsePain001(xmlBytes)
	require.NoError(t, err)
	assert.Equal(t, "MSG-0001", doc.CstmrCdtTrfInitn.GrpHdr.MsgID)
	assert.Len(t, doc.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf, 2)

	res, err := iso20022.ValidateXML(xmlBytes)
	require.NoError(t, err)
	assert.True(t, res.Valid, "expected valid, got errors: %v", res.Errors)
	assert.Equal(t, string(domain.MsgPain001), res.MessageType)
}

func TestPain001_InvalidIBANAndCurrency(t *testing.T) {
	req := validPain001()
	req.DebtorAccountIBAN = "DE00INVALID"
	req.Transactions[0].Currency = "EURO" // 4 chars, invalid

	xmlBytes, err := iso20022.BuildPain001(req)
	require.NoError(t, err)

	res, err := iso20022.ValidateXML(xmlBytes)
	require.NoError(t, err)
	assert.False(t, res.Valid)
	joined := strings.Join(res.Errors, " | ")
	assert.Contains(t, joined, "IBAN is invalid")
	assert.Contains(t, joined, "Ccy is not a valid ISO 4217 code")
}

func validPacs008() domain.Pacs008Request {
	return domain.Pacs008Request{
		MessageID:           "FI-MSG-1",
		InstructingAgentBIC: bicDE,
		InstructedAgentBIC:  bicGB,
		DebtorName:          "Acme Corp",
		DebtorAccountIBAN:   ibanDE,
		DebtorAgentBIC:      bicDE,
		Transactions: []domain.CreditTransfer{
			{EndToEndID: "E2E-1", InstructionID: "INSTR-1", TransactionID: "TX-1", Amount: "1000.00", Currency: "EUR", CreditorName: "Beta Ltd", CreditorAgentBIC: bicGB, CreditorAccountIBAN: ibanGB},
		},
	}
}

func TestPacs008_RoundTripAndValidate(t *testing.T) {
	xmlBytes, err := iso20022.BuildPacs008(validPacs008())
	require.NoError(t, err)

	s := string(xmlBytes)
	assert.Contains(t, s, iso20022.NSPacs008)
	assert.Contains(t, s, "<SttlmMtd>CLRG</SttlmMtd>")
	assert.Contains(t, s, "<ChrgBr>SLEV</ChrgBr>")

	doc, err := iso20022.ParsePacs008(xmlBytes)
	require.NoError(t, err)
	assert.Equal(t, "FI-MSG-1", doc.FIToFICstmrCdtTrf.GrpHdr.MsgID)

	res, err := iso20022.ValidateXML(xmlBytes)
	require.NoError(t, err)
	assert.True(t, res.Valid, "expected valid, got errors: %v", res.Errors)
	assert.Equal(t, string(domain.MsgPacs008), res.MessageType)
}

func TestValidate_UnknownNamespace(t *testing.T) {
	_, err := iso20022.ValidateXML([]byte(`<Document xmlns="urn:example:unknown"><X/></Document>`))
	require.Error(t, err)
}

func TestValidate_NotWellFormed(t *testing.T) {
	_, err := iso20022.ValidateXML([]byte(`<Document><oops`))
	require.Error(t, err)
}
