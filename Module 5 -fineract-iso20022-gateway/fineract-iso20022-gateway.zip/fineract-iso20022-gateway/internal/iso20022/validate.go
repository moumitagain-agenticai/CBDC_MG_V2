package iso20022

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"encoding/xml"
	"fmt"
	"math/big"
	"strings"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/pkg/utils"
)

// ValidationResult is the outcome of validating an ISO 20022 message.
type ValidationResult struct {
	Valid       bool     `json:"valid"`
	MessageType string   `json:"message_type"`
	Errors      []string `json:"errors"`
}

// ValidateXML detects the message type from the document namespace and runs the
// corresponding rule set. Unknown namespaces are reported as an error.
func ValidateXML(data []byte) (ValidationResult, error) {
	var probe struct {
		XMLName xml.Name
	}
	if err := xml.Unmarshal(data, &probe); err != nil {
		return ValidationResult{}, domain.NewValidationError("not well-formed XML", err)
	}

	switch probe.XMLName.Space {
	case NSPain001:
		doc, err := ParsePain001(data)
		if err != nil {
			return ValidationResult{}, err
		}
		errs := validatePain001(doc)
		return ValidationResult{Valid: len(errs) == 0, MessageType: string(domain.MsgPain001), Errors: errs}, nil
	case NSPacs008:
		doc, err := ParsePacs008(data)
		if err != nil {
			return ValidationResult{}, err
		}
		errs := validatePacs008(doc)
		return ValidationResult{Valid: len(errs) == 0, MessageType: string(domain.MsgPacs008), Errors: errs}, nil
	default:
		return ValidationResult{}, domain.NewValidationError("unsupported ISO 20022 namespace: "+probe.XMLName.Space, nil)
	}
}

func validatePain001(doc *Pain001Document) []string {
	var e []string
	g := doc.CstmrCdtTrfInitn.GrpHdr
	p := doc.CstmrCdtTrfInitn.PmtInf

	if !utils.NonEmptyMax(g.MsgID, 35) {
		e = append(e, "GrpHdr/MsgId is required (max 35 chars)")
	}
	if strings.TrimSpace(g.InitgPty.Nm) == "" {
		e = append(e, "GrpHdr/InitgPty/Nm is required")
	}
	if strings.TrimSpace(p.PmtInfID) == "" {
		e = append(e, "PmtInf/PmtInfId is required")
	}
	if p.PmtMtd != "TRF" {
		e = append(e, "PmtInf/PmtMtd must be TRF")
	}
	if !utils.IsISODate(p.ReqdExctnDt.Dt) {
		e = append(e, "PmtInf/ReqdExctnDt/Dt must be YYYY-MM-DD")
	}
	if strings.TrimSpace(p.Dbtr.Nm) == "" {
		e = append(e, "PmtInf/Dbtr/Nm is required")
	}
	if !utils.IsValidIBAN(p.DbtrAcct.ID.IBAN) {
		e = append(e, "PmtInf/DbtrAcct/Id/IBAN is invalid")
	}
	if !utils.IsValidBIC(p.DbtrAgt.FinInstnID.BICFI) {
		e = append(e, "PmtInf/DbtrAgt/FinInstnId/BICFI is invalid")
	}

	n := len(p.CdtTrfTxInf)
	if n == 0 {
		e = append(e, "at least one CdtTrfTxInf is required")
	}
	if g.NbOfTxs != n {
		e = append(e, fmt.Sprintf("GrpHdr/NbOfTxs (%d) does not match transaction count (%d)", g.NbOfTxs, n))
	}
	if p.NbOfTxs != n {
		e = append(e, fmt.Sprintf("PmtInf/NbOfTxs (%d) does not match transaction count (%d)", p.NbOfTxs, n))
	}

	amts := make([]string, 0, n)
	for i, t := range p.CdtTrfTxInf {
		where := fmt.Sprintf("CdtTrfTxInf[%d]", i)
		if !utils.NonEmptyMax(t.PmtID.EndToEndID, 35) {
			e = append(e, where+"/PmtId/EndToEndId is required (max 35 chars)")
		}
		if !utils.IsValidCurrency(t.Amt.InstdAmt.Ccy) {
			e = append(e, where+"/Amt/InstdAmt@Ccy is not a valid ISO 4217 code")
		}
		if !utils.IsPositiveAmount(t.Amt.InstdAmt.Value) {
			e = append(e, where+"/Amt/InstdAmt must be a positive decimal")
		}
		if !utils.IsValidBIC(t.CdtrAgt.FinInstnID.BICFI) {
			e = append(e, where+"/CdtrAgt/FinInstnId/BICFI is invalid")
		}
		if strings.TrimSpace(t.Cdtr.Nm) == "" {
			e = append(e, where+"/Cdtr/Nm is required")
		}
		if !utils.IsValidIBAN(t.CdtrAcct.ID.IBAN) {
			e = append(e, where+"/CdtrAcct/Id/IBAN is invalid")
		}
		amts = append(amts, t.Amt.InstdAmt.Value)
	}

	if !amountsEqual(g.CtrlSum, amts) {
		e = append(e, "GrpHdr/CtrlSum does not equal the sum of instructed amounts")
	}
	if !amountsEqual(p.CtrlSum, amts) {
		e = append(e, "PmtInf/CtrlSum does not equal the sum of instructed amounts")
	}
	return e
}

func validatePacs008(doc *Pacs008Document) []string {
	var e []string
	g := doc.FIToFICstmrCdtTrf.GrpHdr
	txinf := doc.FIToFICstmrCdtTrf.CdtTrfTxInf

	if !utils.NonEmptyMax(g.MsgID, 35) {
		e = append(e, "GrpHdr/MsgId is required (max 35 chars)")
	}
	if !validSettlementMethod(g.SttlmInf.SttlmMtd) {
		e = append(e, "GrpHdr/SttlmInf/SttlmMtd must be one of CLRG|INDA|INGA|COVE")
	}
	if !utils.IsValidBIC(g.InstgAgt.FinInstnID.BICFI) {
		e = append(e, "GrpHdr/InstgAgt/FinInstnId/BICFI is invalid")
	}
	if !utils.IsValidBIC(g.InstdAgt.FinInstnID.BICFI) {
		e = append(e, "GrpHdr/InstdAgt/FinInstnId/BICFI is invalid")
	}
	if !utils.IsValidCurrency(g.TtlIntrBkSttlmAmt.Ccy) {
		e = append(e, "GrpHdr/TtlIntrBkSttlmAmt@Ccy is not a valid ISO 4217 code")
	}

	n := len(txinf)
	if n == 0 {
		e = append(e, "at least one CdtTrfTxInf is required")
	}
	if g.NbOfTxs != n {
		e = append(e, fmt.Sprintf("GrpHdr/NbOfTxs (%d) does not match transaction count (%d)", g.NbOfTxs, n))
	}

	amts := make([]string, 0, n)
	for i, t := range txinf {
		where := fmt.Sprintf("CdtTrfTxInf[%d]", i)
		if strings.TrimSpace(t.PmtID.EndToEndID) == "" {
			e = append(e, where+"/PmtId/EndToEndId is required")
		}
		if !utils.IsValidCurrency(t.IntrBkSttlmAmt.Ccy) {
			e = append(e, where+"/IntrBkSttlmAmt@Ccy is not a valid ISO 4217 code")
		}
		if !utils.IsPositiveAmount(t.IntrBkSttlmAmt.Value) {
			e = append(e, where+"/IntrBkSttlmAmt must be a positive decimal")
		}
		if !validChargeBearer(t.ChrgBr) {
			e = append(e, where+"/ChrgBr must be one of DEBT|CRED|SHAR|SLEV")
		}
		if strings.TrimSpace(t.Dbtr.Nm) == "" {
			e = append(e, where+"/Dbtr/Nm is required")
		}
		if strings.TrimSpace(t.Cdtr.Nm) == "" {
			e = append(e, where+"/Cdtr/Nm is required")
		}
		if !utils.IsValidBIC(t.DbtrAgt.FinInstnID.BICFI) {
			e = append(e, where+"/DbtrAgt/FinInstnId/BICFI is invalid")
		}
		if !utils.IsValidBIC(t.CdtrAgt.FinInstnID.BICFI) {
			e = append(e, where+"/CdtrAgt/FinInstnId/BICFI is invalid")
		}
		if !utils.IsValidIBAN(t.DbtrAcct.ID.IBAN) {
			e = append(e, where+"/DbtrAcct/Id/IBAN is invalid")
		}
		if !utils.IsValidIBAN(t.CdtrAcct.ID.IBAN) {
			e = append(e, where+"/CdtrAcct/Id/IBAN is invalid")
		}
		amts = append(amts, t.IntrBkSttlmAmt.Value)
	}

	if !amountsEqual(g.TtlIntrBkSttlmAmt.Value, amts) {
		e = append(e, "GrpHdr/TtlIntrBkSttlmAmt does not equal the sum of settlement amounts")
	}
	return e
}

func validSettlementMethod(m string) bool {
	switch m {
	case "CLRG", "INDA", "INGA", "COVE":
		return true
	}
	return false
}

func validChargeBearer(c string) bool {
	switch c {
	case "DEBT", "CRED", "SHAR", "SLEV":
		return true
	}
	return false
}

// amountsEqual reports whether want equals the exact sum of the given amounts.
func amountsEqual(want string, amounts []string) bool {
	w, ok := new(big.Rat).SetString(strings.TrimSpace(want))
	if !ok {
		return false
	}
	sum := new(big.Rat)
	for _, a := range amounts {
		r, ok := new(big.Rat).SetString(strings.TrimSpace(a))
		if !ok {
			return false
		}
		sum.Add(sum, r)
	}
	return w.Cmp(sum) == 0
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_validate_Logfile.log at runtime.
var _ = func() bool { flog.For("5_validate").Info("source file initialized"); return true }()
