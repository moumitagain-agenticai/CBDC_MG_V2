# EXPLANATION — fineract-iso20022-gateway (plain language)

This document explains the module in simple terms, for reviewers who are not Go
engineers.

## What is this module for?

Banks and payment systems around the world speak a common "language" for money
messages called **ISO 20022**. Each message is an XML document with a strict
shape. This module is the platform's **translator and inspector** for two of
those messages:

- **pain.001** — a customer telling their bank "please make these payments."
- **pacs.008** — one bank telling another bank "here is a payment to settle."

It does three jobs:

1. **Generate** — take simple JSON and produce a correct ISO 20022 XML message.
2. **Parse** — take an ISO 20022 XML message and read it back into structured data.
3. **Validate** — check that a message follows the rules and report exactly what
   is wrong if it does not.

Unlike Modules 2–4, this module does **not** call any bank — it only builds,
reads and checks messages. Other modules use it and then send the messages on.

## How generation works (and why it is safe)

When you ask for a message, the service builds the XML and then **validates its
own output before returning it**. If for any reason the result would be invalid,
you get a clear error instead of a broken message. So anything this gateway
hands back is guaranteed to be well-formed and rule-valid.

It also does the arithmetic for you: it counts the transactions (`NbOfTxs`) and
adds up the amounts (`CtrlSum` / total settlement amount) exactly, using precise
decimal math — never floating point, which can introduce rounding errors in money.

## What "validation" checks

Real ISO 20022 messages must satisfy many rules. This gateway checks the ones
that matter in practice:

- the message is in the right ISO 20022 "namespace" (the right message type);
- every required field is present, and IDs are not too long;
- account numbers are valid **IBANs** (including the mod-97 checksum that catches
  typos), bank codes are valid **BICs**, currencies look like ISO codes, and
  amounts are positive with at most five decimal places;
- the totals match: the stated number of transactions and the control sum equal
  what is actually in the message;
- coded fields use allowed values (payment method, settlement method, who pays
  the charges).

If everything passes, validation says **valid**. If not, it returns a plain list
like "CdtTrfTxInf[0]/CdtrAcct/Id/IBAN is invalid" so the problem is easy to fix.

### A note on XSD

The official ISO 20022 rules also come as XSD schema files. Validating against
XSD in Go needs a C library (libxml2), which does not build everywhere, so this
module uses **pure-Go rule checks** instead — which cover the same practical
ground and always build. If a deployment needs strict XSD validation too, it can
be added in front of these checks without changing how callers use the service.

## The safety and quality features, in one line each

- **Self-validating output**: generated messages are checked before they leave.
- **Exact money math**: sums and totals use precise decimals, never floats.
- **Format checks**: IBAN (with checksum), BIC, currency and amount are verified.
- **Clear errors**: every failure is a readable message with a stable code.
- **Optional audit trail**: each processed message can be recorded in Postgres.
- **Graceful shutdown**: on stop, in-flight requests finish before exit.
- **Metrics + logs**: everything is observable in Prometheus and JSON logs.

## Relationship to the other modules

The connectors (Modules 2–4) move CBDC by calling banks. This gateway produces
and checks the **standard messages** that accompany those movements across
borders. It is built to the same conventions (same project layout, config,
logging, metrics, migrations) so the whole platform looks and behaves the same.

## What was verified

`go build ./...`, `go vet ./...`, unit tests (round-trip generate/parse plus
validation, for both message types) and integration tests all pass. The running
server generates a valid pain.001, validates it as `valid`, serves `/healthz`
and `/metrics`, and shuts down cleanly on a signal.
