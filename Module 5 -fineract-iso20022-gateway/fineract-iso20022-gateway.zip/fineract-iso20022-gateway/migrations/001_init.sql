-- fineract-iso20022-gateway: message audit trail.
-- Apply with: psql "$DATABASE_DSN" -f migrations/001_init.sql

CREATE TABLE IF NOT EXISTS iso20022_messages (
    id           UUID PRIMARY KEY,
    message_id   TEXT        NOT NULL DEFAULT '',
    message_type TEXT        NOT NULL,
    direction    TEXT        NOT NULL,
    num_txs      INTEGER     NOT NULL DEFAULT 0,
    control_sum  TEXT        NOT NULL DEFAULT '',
    currency     TEXT        NOT NULL DEFAULT '',
    valid        BOOLEAN     NOT NULL DEFAULT false,
    created_at   TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_iso20022_messages_message_id ON iso20022_messages (message_id);
CREATE INDEX IF NOT EXISTS idx_iso20022_messages_type ON iso20022_messages (message_type);
CREATE INDEX IF NOT EXISTS idx_iso20022_messages_created_at ON iso20022_messages (created_at);
