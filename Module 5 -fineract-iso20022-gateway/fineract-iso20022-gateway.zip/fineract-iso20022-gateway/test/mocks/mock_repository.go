package mocks

import (
	"context"

	"github.com/fineract/cbdc/iso20022-gateway/internal/domain"
	"github.com/fineract/cbdc/iso20022-gateway/internal/ports"
)

// MockMessageRepository is an in-memory test double for ports.MessageRepository.
type MockMessageRepository struct {
	Saved []*domain.MessageRecord
}

var _ ports.MessageRepository = (*MockMessageRepository)(nil)

func (m *MockMessageRepository) Save(_ context.Context, rec *domain.MessageRecord) error {
	m.Saved = append(m.Saved, rec)
	return nil
}

func (m *MockMessageRepository) GetByID(_ context.Context, id string) (*domain.MessageRecord, error) {
	for _, r := range m.Saved {
		if r.ID == id {
			return r, nil
		}
	}
	return nil, domain.NewNotFoundError("not found", nil)
}

func (m *MockMessageRepository) Ping(_ context.Context) error { return nil }
