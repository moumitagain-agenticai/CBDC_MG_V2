//go:build integration

package integration

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/cbdc/iso20022-gateway/internal/adapters/api"
	"github.com/fineract/cbdc/iso20022-gateway/internal/service"
	"github.com/fineract/cbdc/iso20022-gateway/pkg/metrics"
)

func testServer() *httptest.Server {
	svc := service.NewGateway(nil, metrics.New(), zap.NewNop())
	h := api.NewHandler(svc, 1<<20)
	return httptest.NewServer(api.NewRouter(h, metrics.New(), zap.NewNop(), 0))
}

const painJSON = `{
  "message_id": "MSG-1",
  "initiating_party": "Acme",
  "payment_info_id": "PMT-1",
  "requested_execution_date": "2026-08-15",
  "debtor_name": "Acme",
  "debtor_account_iban": "DE89370400440532013000",
  "debtor_agent_bic": "DEUTDEFF",
  "transactions": [
    {"end_to_end_id":"E1","amount":"100.00","currency":"EUR","creditor_name":"Beta","creditor_agent_bic":"NWBKGB2L","creditor_account_iban":"GB29NWBK60161331926819"}
  ]
}`

func TestGenerateThenValidate(t *testing.T) {
	srv := testServer()
	defer srv.Close()

	// Generate pain.001 -> XML
	resp, err := http.Post(srv.URL+"/api/v1/pain001/generate", "application/json", bytes.NewReader([]byte(painJSON)))
	require.NoError(t, err)
	defer resp.Body.Close()
	require.Equal(t, http.StatusOK, resp.StatusCode)
	assert.Equal(t, "application/xml", resp.Header.Get("Content-Type"))
	xmlOut, _ := io.ReadAll(resp.Body)
	assert.Contains(t, string(xmlOut), "pain.001.001.09")

	// Validate the generated XML -> valid
	vresp, err := http.Post(srv.URL+"/api/v1/validate", "application/xml", bytes.NewReader(xmlOut))
	require.NoError(t, err)
	defer vresp.Body.Close()
	require.Equal(t, http.StatusOK, vresp.StatusCode)
	var vr struct {
		Valid  bool     `json:"valid"`
		Errors []string `json:"errors"`
	}
	require.NoError(t, json.NewDecoder(vresp.Body).Decode(&vr))
	assert.True(t, vr.Valid)
}

func TestGenerate_BadRequest(t *testing.T) {
	srv := testServer()
	defer srv.Close()

	// Missing required fields -> generated message fails validation -> 400
	resp, err := http.Post(srv.URL+"/api/v1/pain001/generate", "application/json", bytes.NewReader([]byte(`{"message_id":"X"}`)))
	require.NoError(t, err)
	defer resp.Body.Close()
	assert.Equal(t, http.StatusBadRequest, resp.StatusCode)
}

func TestValidate_InvalidReturns422(t *testing.T) {
	srv := testServer()
	defer srv.Close()

	bad := `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.09"><CstmrCdtTrfInitn>
<GrpHdr><MsgId>M</MsgId><CreDtTm>2026-01-01T00:00:00</CreDtTm><NbOfTxs>1</NbOfTxs><CtrlSum>5</CtrlSum><InitgPty><Nm>A</Nm></InitgPty></GrpHdr>
<PmtInf><PmtInfId>P</PmtInfId><PmtMtd>TRF</PmtMtd><NbOfTxs>1</NbOfTxs><CtrlSum>5</CtrlSum><ReqdExctnDt><Dt>2026-01-01</Dt></ReqdExctnDt>
<Dbtr><Nm>A</Nm></Dbtr><DbtrAcct><Id><IBAN>BAD</IBAN></Id></DbtrAcct><DbtrAgt><FinInstnId><BICFI>BAD</BICFI></FinInstnId></DbtrAgt>
<CdtTrfTxInf><PmtId><EndToEndId>E</EndToEndId></PmtId><Amt><InstdAmt Ccy="EUR">5</InstdAmt></Amt>
<CdtrAgt><FinInstnId><BICFI>BAD</BICFI></FinInstnId></CdtrAgt><Cdtr><Nm>B</Nm></Cdtr>
<CdtrAcct><Id><IBAN>BAD</IBAN></Id></CdtrAcct></CdtTrfTxInf></PmtInf></CstmrCdtTrfInitn></Document>`

	resp, err := http.Post(srv.URL+"/api/v1/validate", "application/xml", bytes.NewReader([]byte(bad)))
	require.NoError(t, err)
	defer resp.Body.Close()
	assert.Equal(t, http.StatusUnprocessableEntity, resp.StatusCode)
}
