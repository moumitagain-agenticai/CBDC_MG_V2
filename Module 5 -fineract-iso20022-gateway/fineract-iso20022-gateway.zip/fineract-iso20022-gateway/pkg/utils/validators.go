package utils

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"math/big"
	"regexp"
	"strings"
	"time"
)

var (
	bicRe      = regexp.MustCompile(`^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$`)
	currencyRe = regexp.MustCompile(`^[A-Z]{3}$`)
	ibanRe     = regexp.MustCompile(`^[A-Z]{2}[0-9]{2}[A-Z0-9]{1,30}$`)
)

// IsValidBIC reports whether s is a syntactically valid ISO 9362 BIC (8 or 11).
func IsValidBIC(s string) bool {
	return bicRe.MatchString(strings.ToUpper(strings.TrimSpace(s)))
}

// IsValidCurrency reports whether s is a syntactically valid ISO 4217 code.
func IsValidCurrency(s string) bool {
	return currencyRe.MatchString(strings.TrimSpace(s))
}

// IsValidIBAN reports whether s is a valid IBAN: correct shape and a passing
// ISO 7064 mod-97 checksum.
func IsValidIBAN(s string) bool {
	s = strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(s), " ", ""))
	if len(s) < 15 || len(s) > 34 || !ibanRe.MatchString(s) {
		return false
	}
	// Move the first four chars to the end, then convert letters to numbers.
	rearranged := s[4:] + s[:4]
	var b strings.Builder
	for _, r := range rearranged {
		switch {
		case r >= '0' && r <= '9':
			b.WriteRune(r)
		case r >= 'A' && r <= 'Z':
			// A=10 ... Z=35
			n := int(r-'A') + 10
			b.WriteString(itoa(n))
		default:
			return false
		}
	}
	mod := new(big.Int)
	mod.SetString(b.String(), 10)
	return new(big.Int).Mod(mod, big.NewInt(97)).Int64() == 1
}

func itoa(n int) string {
	if n < 10 {
		return string(rune('0' + n))
	}
	return string(rune('0'+n/10)) + string(rune('0'+n%10))
}

// IsPositiveAmount reports whether s is a well-formed positive decimal amount
// with at most 5 fractional digits (ISO 20022 constraint for most amounts).
func IsPositiveAmount(s string) bool {
	s = strings.TrimSpace(s)
	if s == "" {
		return false
	}
	r, ok := new(big.Rat).SetString(s)
	if !ok || r.Sign() <= 0 {
		return false
	}
	if dot := strings.IndexByte(s, '.'); dot >= 0 && len(s)-dot-1 > 5 {
		return false
	}
	return true
}

// SumAmounts adds decimal amount strings exactly and returns a canonical
// decimal string with up to 5 fractional digits (trailing zeros trimmed).
func SumAmounts(amounts []string) (string, bool) {
	total := new(big.Rat)
	for _, a := range amounts {
		r, ok := new(big.Rat).SetString(strings.TrimSpace(a))
		if !ok {
			return "", false
		}
		total.Add(total, r)
	}
	return strings.TrimRight(strings.TrimRight(total.FloatString(5), "0"), "."), true
}

// IsISODate reports whether s is a valid YYYY-MM-DD date.
func IsISODate(s string) bool {
	_, err := time.Parse("2006-01-02", strings.TrimSpace(s))
	return err == nil
}

// NonEmptyMax reports whether s is non-empty and at most max runes.
func NonEmptyMax(s string, max int) bool {
	s = strings.TrimSpace(s)
	return s != "" && len([]rune(s)) <= max
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_validators_Logfile.log at runtime.
var _ = func() bool { flog.For("5_validators").Info("source file initialized"); return true }()
