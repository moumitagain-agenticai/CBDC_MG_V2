package metrics

import "github.com/fineract/cbdc/iso20022-gateway/pkg/flog"
import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// Metrics holds the gateway's Prometheus collectors.
type Metrics struct {
	MessagesTotal  *prometheus.CounterVec
	MessageErrors  *prometheus.CounterVec
	MessageLatency *prometheus.HistogramVec
	registry       *prometheus.Registry
}

// New registers metrics on a private registry.
func New() *Metrics {
	reg := prometheus.NewRegistry()
	f := promauto.With(reg)
	return &Metrics{
		registry: reg,
		MessagesTotal: f.NewCounterVec(prometheus.CounterOpts{
			Name: "iso20022_messages_total",
			Help: "Total ISO 20022 messages processed, by type and operation.",
		}, []string{"type", "operation"}),
		MessageErrors: f.NewCounterVec(prometheus.CounterOpts{
			Name: "iso20022_message_errors_total",
			Help: "Total ISO 20022 processing errors, by operation and error code.",
		}, []string{"operation", "code"}),
		MessageLatency: f.NewHistogramVec(prometheus.HistogramOpts{
			Name:    "iso20022_message_duration_seconds",
			Help:    "Latency of ISO 20022 operations in seconds, by operation.",
			Buckets: prometheus.DefBuckets,
		}, []string{"operation"}),
	}
}

// Handler returns the /metrics HTTP handler for this registry.
func (m *Metrics) Handler() http.Handler {
	return promhttp.HandlerFor(m.registry, promhttp.HandlerOpts{})
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/5_metrics_Logfile.log at runtime.
var _ = func() bool { flog.For("5_metrics").Info("source file initialized"); return true }()
