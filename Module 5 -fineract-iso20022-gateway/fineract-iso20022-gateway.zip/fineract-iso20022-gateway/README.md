# fineract-iso20022-gateway

Module 5 of the E1 Cross-Border CBDC platform. It is the **ISO 20022 messaging
gateway**: it **generates**, **parses** and **validates** the payment messages
the platform exchanges with banks and market infrastructures —
**pain.001.001.09** (CustomerCreditTransferInitiation) and **pacs.008.001.08**
(FIToFICustomerCreditTransfer).

Unlike the CBDC connectors (Modules 2–4), this module has no upstream bank
client; it is a pure message engine plus a thin HTTP API and an optional audit
trail. It builds and runs stand-alone, and slots into the monorepo without code
changes.

## Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/v1/pain001/generate` | JSON → pain.001 XML |
| POST | `/api/v1/pain001/parse` | pain.001 XML → JSON |
| POST | `/api/v1/pacs008/generate` | JSON → pacs.008 XML |
| POST | `/api/v1/pacs008/parse` | pacs.008 XML → JSON |
| POST | `/api/v1/validate` | Validate any supported message (type auto-detected) |
| GET | `/healthz` / `/readyz` | Liveness / readiness |
| GET | `/metrics` | Prometheus metrics |

`generate` always returns a message that **passes validation** — the service
validates its own output before responding, so callers never receive a
malformed message. `validate` returns `200` for a valid message and `422` with
a list of rule violations for a well-formed but invalid one.

## Architecture

Hexagonal (ports & adapters):

```
cmd/server            entrypoint: config load, DI wiring, graceful shutdown
internal/domain       canonical request/record types + typed error taxonomy
internal/iso20022     the message engine: pain.001 / pacs.008 build, parse,
                      validate (XML models + rule sets)
internal/ports        interfaces (MessageRepository)
internal/service      orchestration: generate → self-validate → audit → metrics
internal/adapters/
  api                 chi router, handlers, middleware (request-id, recover, logs)
  repository          PostgreSQL message audit trail (parameterized SQL)
internal/config       YAML + env config, validated fail-fast on startup
pkg/logger            zap structured logging
pkg/metrics           Prometheus metrics on a private registry
pkg/utils             ISO format validators (BIC, IBAN mod-97, currency, amount)
```

## Schema validation

Validation is **pure Go** — structural and business-rule checks rather than XSD:

- correct ISO 20022 namespace and document root;
- all mandatory elements present, string length limits (e.g. `MsgId` ≤ 35);
- **BIC** (ISO 9362), **IBAN** (ISO 13616 with the ISO 7064 mod-97 checksum),
  **currency** (ISO 4217 shape) and **amount** (positive decimal, ≤ 5 fraction
  digits) formats;
- cross-field consistency: `NbOfTxs` equals the transaction count and
  `CtrlSum` / `TtlIntrBkSttlmAmt` equals the exact sum of the amounts
  (computed with `big.Rat`, never floating point);
- allowed code sets: `PmtMtd=TRF`, settlement method `CLRG|INDA|INGA|COVE`,
  charge bearer `DEBT|CRED|SHAR|SLEV`.

This approach always builds (no cgo/libxml2 dependency). If strict XSD
validation against the official ISO 20022 schemas is required, it can be added
as an optional layer (e.g. libxml2 via cgo) in front of the rule engine; the
HTTP contract does not change.

## Quick start

```bash
cp .env.example .env
make run          # or: go run ./cmd/server -config=configs/config.yaml

curl -s -X POST localhost:8080/api/v1/pain001/generate \
  -H 'Content-Type: application/json' \
  -d '{"message_id":"MSG-1","initiating_party":"Acme","payment_info_id":"PMT-1",
       "requested_execution_date":"2026-08-15","debtor_name":"Acme",
       "debtor_account_iban":"DE89370400440532013000","debtor_agent_bic":"DEUTDEFF",
       "transactions":[{"end_to_end_id":"E1","amount":"100.00","currency":"EUR",
         "creditor_name":"Beta","creditor_agent_bic":"NWBKGB2L",
         "creditor_account_iban":"GB29NWBK60161331926819"}]}'
```

## Configuration

All values come from `configs/config.yaml` and/or environment variables
(env wins). Key variables:

| Env | Meaning |
|-----|---------|
| `SERVER_PORT` | HTTP port (default 8080) |
| `DATABASE_DSN` | Postgres DSN; setting it enables the message audit trail |
| `LOG_LEVEL` | `debug` \| `info` \| `warn` \| `error` |

The server **fails fast** on startup if configuration is invalid.

## Database migrations

Persistence is optional. When `DATABASE_DSN` is set, the gateway **runs pending
migrations automatically on startup** and records them in a `schema_migrations`
table. Migrations are defined in Go
(`internal/adapters/repository/migration.go`) with versioned up/down SQL.

```bash
go run ./cmd/server -rollback 1   # roll back the last migration and exit
```

`migrations/001_init.sql` is also provided as a standalone reference.

## Building `go.sum`

The repository ships a clean `go.mod` without a `go.sum`; run `go mod tidy`
(or `make deps`) once with network access to generate it. `make build`, `make
test` and the Docker build all do this on first run.

## Production features

Self-validating generation, exact-decimal money math (`big.Rat`), request-id
correlation, structured logs, Prometheus metrics, request body size caps, a
stable error-code → HTTP-status mapping, graceful shutdown, and automatic
migrations.

## Per-source-file logging (Logrus)

In addition to the primary structured logger (zap, used for console/DI logging),
this module ships a **Logrus** per-source-file logger in `pkg/flog`. Every source
file writes its own log file under `logs/`, named `5_<file>.log`
(module number + source file name), e.g. `5_main.log`,
`5_config.log`. Each file registers itself with the logger, and a
Logrus hook routes entries to the matching file (JSON formatted). The `logs/`
directory is created on startup and is git-ignored. `go.sum` for the added
`github.com/sirupsen/logrus` dependency is generated on first `go mod tidy`.
