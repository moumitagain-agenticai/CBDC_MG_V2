#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo ">> go mod tidy"
go mod tidy

echo ">> go build"
CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o bin/iso20022-gateway ./cmd/server

echo ">> built bin/iso20022-gateway"
