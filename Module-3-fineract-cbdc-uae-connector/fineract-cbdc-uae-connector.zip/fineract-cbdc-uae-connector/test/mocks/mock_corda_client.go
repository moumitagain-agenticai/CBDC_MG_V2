package mocks

import (
	"context"

	"github.com/fineract/cbdc/uae-connector/internal/ports"
)

// MockCordaClient is a configurable test double for ports.CordaClient. Any func
// left nil returns a canned success.
type MockCordaClient struct {
	SubmitFunc func(ctx context.Context, req ports.CordaSettlementRequest) (*ports.CordaSettlementResponse, error)
	StatusFunc func(ctx context.Context, cordaTxID string) (*ports.CordaFlowStatus, error)
	HealthFunc func(ctx context.Context) error
}

var _ ports.CordaClient = (*MockCordaClient)(nil)

func (m *MockCordaClient) SubmitSettlement(ctx context.Context, req ports.CordaSettlementRequest) (*ports.CordaSettlementResponse, error) {
	if m.SubmitFunc != nil {
		return m.SubmitFunc(ctx, req)
	}
	return &ports.CordaSettlementResponse{CordaTxID: "corda-tx-abc", Status: "COMPLETED"}, nil
}

func (m *MockCordaClient) GetFlowStatus(ctx context.Context, cordaTxID string) (*ports.CordaFlowStatus, error) {
	if m.StatusFunc != nil {
		return m.StatusFunc(ctx, cordaTxID)
	}
	return &ports.CordaFlowStatus{CordaTxID: cordaTxID, Status: "COMPLETED"}, nil
}

func (m *MockCordaClient) HealthCheck(ctx context.Context) error {
	if m.HealthFunc != nil {
		return m.HealthFunc(ctx)
	}
	return nil
}
