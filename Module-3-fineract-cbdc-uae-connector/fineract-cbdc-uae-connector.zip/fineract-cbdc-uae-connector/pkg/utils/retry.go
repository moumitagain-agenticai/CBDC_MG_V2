package utils

import "github.com/fineract/cbdc/uae-connector/pkg/flog"
import (
	"math/big"
	"strings"
)

// IsPositiveAmount reports whether s is a well-formed positive decimal amount.
// Money is handled as a string / big.Rat to avoid float rounding errors.
func IsPositiveAmount(s string) bool {
	s = strings.TrimSpace(s)
	if s == "" {
		return false
	}
	r, ok := new(big.Rat).SetString(s)
	if !ok {
		return false
	}
	return r.Sign() > 0
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/3_retry_Logfile.log at runtime.
var _ = func() bool { flog.For("3_retry").Info("source file initialized"); return true }()
