package service

import "github.com/fineract/cbdc/uae-connector/pkg/flog"
import (
	"context"

	"github.com/fineract/cbdc/uae-connector/internal/domain"
	"github.com/fineract/cbdc/uae-connector/internal/ports"
)

// GetTransaction returns a persisted transaction by its local id. When
// persistence is disabled the local record is unavailable.
func (c *Connector) GetTransaction(ctx context.Context, id string) (*domain.Transaction, error) {
	if id == "" {
		return nil, domain.NewValidationError("transaction id is required", nil)
	}
	if c.repo == nil {
		return nil, domain.NewNotFoundError("transaction persistence is disabled", nil)
	}
	return c.repo.GetByID(ctx, id)
}

// GetUpstreamStatus queries the partner bank for the live status of a
// previously submitted transaction.
func (c *Connector) GetUpstreamStatus(ctx context.Context, upstreamTxID string) (*ports.StatusResponse, error) {
	if upstreamTxID == "" {
		return nil, domain.NewValidationError("upstream transaction id is required", nil)
	}
	return c.client.GetTransactionStatus(ctx, upstreamTxID)
}

// GetCordaFlowStatus queries the Corda bridge for the status of a settlement
// flow. It returns a clear error when Corda settlement is disabled.
func (c *Connector) GetCordaFlowStatus(ctx context.Context, cordaTxID string) (*ports.CordaFlowStatus, error) {
	if cordaTxID == "" {
		return nil, domain.NewValidationError("corda transaction id is required", nil)
	}
	if c.corda == nil {
		return nil, domain.NewNotFoundError("corda settlement is disabled", nil)
	}
	return c.corda.GetFlowStatus(ctx, cordaTxID)
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/3_transaction_Logfile.log at runtime.
var _ = func() bool { flog.For("3_transaction").Info("source file initialized"); return true }()
