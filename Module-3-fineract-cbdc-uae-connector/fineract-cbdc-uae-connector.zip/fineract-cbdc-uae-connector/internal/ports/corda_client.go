package ports

import "github.com/fineract/cbdc/uae-connector/pkg/flog"
import "context"

// CordaClient is the outbound port for anchoring/settling Digital Dirham
// operations on the partner bank's R3 Corda network. In production the partner
// bank exposes its Corda node through a REST bridge (HTTP-RPC / Braid / a
// bank-provided facade); this port abstracts that bridge.
type CordaClient interface {
	// SubmitSettlement starts a Corda settlement flow for a completed operation
	// and returns the resulting Corda transaction id (a SecureHash).
	SubmitSettlement(ctx context.Context, req CordaSettlementRequest) (*CordaSettlementResponse, error)
	// GetFlowStatus returns the status of a previously submitted Corda flow.
	GetFlowStatus(ctx context.Context, cordaTxID string) (*CordaFlowStatus, error)
	// HealthCheck verifies the Corda bridge/node is reachable.
	HealthCheck(ctx context.Context) error
}

// CordaSettlementRequest is the payload sent to the Corda settlement flow.
type CordaSettlementRequest struct {
	ReferenceID       string `json:"reference_id"`
	Operation         string `json:"operation"`
	Amount            string `json:"amount"`
	Currency          string `json:"currency"`
	SourceWallet      string `json:"source_wallet,omitempty"`
	DestinationWallet string `json:"destination_wallet,omitempty"`
}

// CordaSettlementResponse carries the Corda transaction id of the settlement.
type CordaSettlementResponse struct {
	CordaTxID string `json:"corda_tx_id"`
	Status    string `json:"status"`
}

// CordaFlowStatus is the live status of a Corda settlement flow.
type CordaFlowStatus struct {
	CordaTxID string `json:"corda_tx_id"`
	Status    string `json:"status"` // IN_PROGRESS | COMPLETED | FAILED
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/3_corda_client_Logfile.log at runtime.
var _ = func() bool { flog.For("3_corda_client").Info("source file initialized"); return true }()
