package client

import "github.com/fineract/cbdc/uae-connector/pkg/flog"
import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/hashicorp/go-retryablehttp"
	"github.com/sony/gobreaker"

	"github.com/fineract/cbdc/uae-connector/internal/config"
	"github.com/fineract/cbdc/uae-connector/internal/domain"
	"github.com/fineract/cbdc/uae-connector/internal/ports"
)

// CordaClient talks to the partner bank's R3 Corda REST bridge to settle Digital
// Dirham operations on the DLT. It reuses the same resilience patterns as the
// partner-bank client: retries with backoff and a circuit breaker.
type CordaClient struct {
	baseURL string
	apiKey  string
	http    *retryablehttp.Client
	breaker *gobreaker.CircuitBreaker
}

var _ ports.CordaClient = (*CordaClient)(nil)

// NewCorda builds a CordaClient from configuration.
func NewCorda(cfg config.CordaConfig) *CordaClient {
	rc := retryablehttp.NewClient()
	rc.RetryMax = cfg.MaxRetries
	rc.HTTPClient.Timeout = cfg.Timeout
	rc.Logger = nil

	cb := gobreaker.NewCircuitBreaker(gobreaker.Settings{
		Name:        cfg.BreakerName,
		MaxRequests: 5,
		Interval:    60 * time.Second,
		Timeout:     30 * time.Second,
		ReadyToTrip: func(c gobreaker.Counts) bool { return c.ConsecutiveFailures >= 5 },
	})

	return &CordaClient{
		baseURL: strings.TrimRight(cfg.BridgeURL, "/"),
		apiKey:  cfg.APIKey,
		http:    rc,
		breaker: cb,
	}
}

func (c *CordaClient) SubmitSettlement(ctx context.Context, req ports.CordaSettlementRequest) (*ports.CordaSettlementResponse, error) {
	var out ports.CordaSettlementResponse
	if err := c.do(ctx, http.MethodPost, "/flows/settlement", req, &out); err != nil {
		return nil, err
	}
	return &out, nil
}

func (c *CordaClient) GetFlowStatus(ctx context.Context, cordaTxID string) (*ports.CordaFlowStatus, error) {
	var out ports.CordaFlowStatus
	path := "/flows/" + url.PathEscape(cordaTxID)
	if err := c.do(ctx, http.MethodGet, path, nil, &out); err != nil {
		return nil, err
	}
	return &out, nil
}

func (c *CordaClient) HealthCheck(ctx context.Context) error {
	return c.do(ctx, http.MethodGet, "/node/health", nil, nil)
}

func (c *CordaClient) do(ctx context.Context, method, path string, body, out any) error {
	var payload []byte
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return domain.NewInternalError("marshal corda request", err)
		}
		payload = b
	}

	_, err := c.breaker.Execute(func() (any, error) {
		return nil, c.roundtrip(ctx, method, path, payload, out)
	})
	if err == gobreaker.ErrOpenState || err == gobreaker.ErrTooManyRequests {
		return domain.NewCircuitOpenError("corda bridge circuit open", err)
	}
	return err
}

func (c *CordaClient) roundtrip(ctx context.Context, method, path string, payload []byte, out any) error {
	var reader io.Reader
	if payload != nil {
		reader = bytes.NewReader(payload)
	}
	req, err := retryablehttp.NewRequestWithContext(ctx, method, c.baseURL+path, reader)
	if err != nil {
		return domain.NewInternalError("build corda request", err)
	}
	req.Header.Set("Accept", "application/json")
	if payload != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if c.apiKey != "" {
		req.Header.Set("X-API-Key", c.apiKey)
	}

	resp, err := c.http.Do(req)
	if err != nil {
		if ctx.Err() == context.DeadlineExceeded {
			return domain.NewTimeoutError("corda bridge timeout", err)
		}
		return domain.NewUpstreamError("corda bridge request failed", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode >= 400 {
		return mapHTTPError(resp.StatusCode, respBody)
	}
	if out != nil && len(respBody) > 0 {
		if err := json.Unmarshal(respBody, out); err != nil {
			return domain.NewUpstreamError("decode corda response", err)
		}
	}
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/3_corda_client_Logfile.log at runtime.
var _ = func() bool { flog.For("3_corda_client").Info("source file initialized"); return true }()
