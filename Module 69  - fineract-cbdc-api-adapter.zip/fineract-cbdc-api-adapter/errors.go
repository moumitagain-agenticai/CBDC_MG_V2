package apiadapter

import (
	"errors"
	"fmt"
)

// Code classifies an adapter error so callers can react without parsing text.
type Code string

// Error codes.
const (
	CodeValidation  Code = "validation"  // malformed request
	CodeNotFound    Code = "not_found"   // account/txn/hold not found
	CodeConflict    Code = "conflict"    // invalid state transition
	CodeUnsupported Code = "unsupported" // no Fineract mapping for the operation
	CodeUpstream    Code = "upstream"    // Fineract returned an error
	CodeUnavailable Code = "unavailable" // Fineract unreachable
	CodeInternal    Code = "internal"    // unexpected internal failure
)

// Error is the classified error returned by adapter operations.
type Error struct {
	Code    Code
	Message string
	Err     error
}

func (e *Error) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

func (e *Error) Unwrap() error { return e.Err }

func newErr(c Code, msg string, err error) *Error { return &Error{Code: c, Message: msg, Err: err} }

// Constructors.
func NewValidationError(m string, e error) *Error  { return newErr(CodeValidation, m, e) }
func NewNotFoundError(m string, e error) *Error    { return newErr(CodeNotFound, m, e) }
func NewConflictError(m string, e error) *Error    { return newErr(CodeConflict, m, e) }
func NewUnsupportedError(m string, e error) *Error { return newErr(CodeUnsupported, m, e) }
func NewUpstreamError(m string, e error) *Error    { return newErr(CodeUpstream, m, e) }
func NewUnavailableError(m string, e error) *Error { return newErr(CodeUnavailable, m, e) }
func NewInternalError(m string, e error) *Error    { return newErr(CodeInternal, m, e) }

// CodeOf returns the Code of err, CodeInternal if it is a non-adapter error, or
// "" if err is nil.
func CodeOf(err error) Code {
	if err == nil {
		return ""
	}
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return CodeInternal
}
