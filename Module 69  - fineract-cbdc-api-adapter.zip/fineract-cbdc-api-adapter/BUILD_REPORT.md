# BUILD REPORT — fineract-cbdc-api-adapter (Module 69)

Toolchain: Go 1.22 (module declares `go 1.21`). Module path:
`github.com/fineract/cbdc/api-adapter`.

| Check | Command | Result |
|-------|---------|--------|
| Formatting | `gofmt -l .` | clean |
| Dependencies | `go mod tidy` | clean (`github.com/google/uuid`) |
| Build | `go build ./...` | pass (exit 0) |
| Vet | `go vet ./...` | pass (exit 0) |
| Unit tests | `go test ./...` | pass |
| Example | `go run ./examples` | runs hold → settle → reverse |

Requirement coverage (from the finalised module list, Category D):
- `/settle` and `/reverse` do not exist in Fineract → mapped to `releaseAmount`
  and `undo`; mapping is documented in code (`mapping.Table`, `Adapter.Mapping()`)
  and in the README.
- Reversal is a NEW compensating transaction, never a mutation — enforced by the
  adapter and pinned by `TestReverseIsNewTransactionNotMutation` (ledger grows by
  one, original id preserved, reversal id distinct) and `TestDoubleReverseRejected`.

Tests: hold→settle happy path; reversal-is-new-transaction invariant; double
reverse rejected; settle of unknown hold → upstream; validation (empty account,
zero amount, empty original txn); mapping documented (settle→releaseAmount,
reverse→undo, hold→holdAmount).

Notes: real stdlib HTTP Fineract client plus an in-memory mock that preserves
transaction immutability. Minimal dependency surface (`google/uuid`). Nothing
pushed to any remote.
