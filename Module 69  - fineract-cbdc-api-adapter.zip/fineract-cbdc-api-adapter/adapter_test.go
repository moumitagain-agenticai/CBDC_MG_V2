package apiadapter_test

import (
	"context"
	"testing"

	adapter "github.com/fineract/cbdc/api-adapter"
	"github.com/fineract/cbdc/api-adapter/mapping"
	"github.com/fineract/cbdc/api-adapter/metrics"
	"github.com/fineract/cbdc/api-adapter/test/mock"
	"github.com/fineract/cbdc/api-adapter/types"
)

func newAdapter() (*adapter.Adapter, *mock.Fineract) {
	f := mock.New()
	return adapter.New(f, adapter.WithMetrics(metrics.NewInMemory())), f
}

func inr(m int64) types.Amount { return types.NewAmount(m, types.INR) }

func TestHoldThenSettle(t *testing.T) {
	a, _ := newAdapter()
	ctx := context.Background()
	hold, err := a.Hold(ctx, adapter.HoldRequest{Account: "acc-1", Amount: inr(50000), Reference: "r1"})
	if err != nil {
		t.Fatalf("hold: %v", err)
	}
	if hold.HoldTxnID == "" || hold.Status != types.StatusHeld {
		t.Fatalf("unexpected hold result: %+v", hold)
	}
	settle, err := a.Settle(ctx, adapter.SettleRequest{Account: "acc-1", HoldTxnID: hold.HoldTxnID, Reference: "r2"})
	if err != nil {
		t.Fatalf("settle: %v", err)
	}
	if settle.SettleTxnID == "" || settle.HoldTxnID != hold.HoldTxnID || settle.Status != types.StatusCompleted {
		t.Fatalf("unexpected settle result: %+v", settle)
	}
}

// The core invariant: a reversal is a NEW transaction, never a mutation of the
// original. The original must still exist, and the ledger must have GROWN.
func TestReverseIsNewTransactionNotMutation(t *testing.T) {
	a, f := newAdapter()
	ctx := context.Background()
	hold, _ := a.Hold(ctx, adapter.HoldRequest{Account: "acc-1", Amount: inr(50000)})
	settle, _ := a.Settle(ctx, adapter.SettleRequest{Account: "acc-1", HoldTxnID: hold.HoldTxnID})

	before := f.TxnCount()
	rev, err := a.Reverse(ctx, adapter.ReverseRequest{Account: "acc-1", OriginalTxnID: settle.SettleTxnID})
	if err != nil {
		t.Fatalf("reverse: %v", err)
	}
	// original id preserved and returned unchanged
	if rev.OriginalTxnID != settle.SettleTxnID {
		t.Fatalf("original id changed: %s != %s", rev.OriginalTxnID, settle.SettleTxnID)
	}
	// a NEW, distinct reversal transaction was created
	if rev.ReversalTxnID == "" || rev.ReversalTxnID == settle.SettleTxnID {
		t.Fatalf("expected a new reversal txn id distinct from original, got %s", rev.ReversalTxnID)
	}
	if rev.Status != types.StatusReversed {
		t.Fatalf("expected REVERSED status, got %s", rev.Status)
	}
	// the ledger grew (append), and the original still exists (immutable)
	if f.TxnCount() != before+1 {
		t.Fatalf("expected ledger to grow by 1, was %d now %d", before, f.TxnCount())
	}
	if !f.Exists(settle.SettleTxnID) {
		t.Fatal("original transaction must still exist after reversal")
	}
}

func TestDoubleReverseRejected(t *testing.T) {
	a, _ := newAdapter()
	ctx := context.Background()
	hold, _ := a.Hold(ctx, adapter.HoldRequest{Account: "acc-1", Amount: inr(50000)})
	settle, _ := a.Settle(ctx, adapter.SettleRequest{Account: "acc-1", HoldTxnID: hold.HoldTxnID})
	if _, err := a.Reverse(ctx, adapter.ReverseRequest{Account: "acc-1", OriginalTxnID: settle.SettleTxnID}); err != nil {
		t.Fatalf("first reverse: %v", err)
	}
	_, err := a.Reverse(ctx, adapter.ReverseRequest{Account: "acc-1", OriginalTxnID: settle.SettleTxnID})
	if adapter.CodeOf(err) != adapter.CodeUpstream {
		t.Fatalf("want upstream error on double reverse, got %v", err)
	}
}

func TestSettleUnknownHold(t *testing.T) {
	a, _ := newAdapter()
	_, err := a.Settle(context.Background(), adapter.SettleRequest{Account: "acc-1", HoldTxnID: "nope"})
	if adapter.CodeOf(err) != adapter.CodeUpstream {
		t.Fatalf("want upstream error, got %v", err)
	}
}

func TestValidation(t *testing.T) {
	a, _ := newAdapter()
	ctx := context.Background()
	if _, err := a.Hold(ctx, adapter.HoldRequest{Account: "", Amount: inr(1)}); adapter.CodeOf(err) != adapter.CodeValidation {
		t.Fatalf("want validation for empty account, got %v", err)
	}
	if _, err := a.Hold(ctx, adapter.HoldRequest{Account: "a", Amount: inr(0)}); adapter.CodeOf(err) != adapter.CodeValidation {
		t.Fatalf("want validation for zero amount, got %v", err)
	}
	if _, err := a.Reverse(ctx, adapter.ReverseRequest{Account: "a", OriginalTxnID: ""}); adapter.CodeOf(err) != adapter.CodeValidation {
		t.Fatalf("want validation for empty original txn, got %v", err)
	}
}

func TestMappingDocumented(t *testing.T) {
	a, _ := newAdapter()
	got := map[mapping.Intent]string{}
	for _, e := range a.Mapping() {
		got[e.Intent] = e.FineractCommand
	}
	if got[mapping.IntentSettle] != "releaseAmount" {
		t.Fatalf("settle must map to releaseAmount, got %q", got[mapping.IntentSettle])
	}
	if got[mapping.IntentReverse] != "undo" {
		t.Fatalf("reverse must map to undo, got %q", got[mapping.IntentReverse])
	}
	if cmd, ok := mapping.CommandFor(mapping.IntentHold); !ok || cmd != "holdAmount" {
		t.Fatalf("hold must map to holdAmount, got %q ok=%v", cmd, ok)
	}
}
