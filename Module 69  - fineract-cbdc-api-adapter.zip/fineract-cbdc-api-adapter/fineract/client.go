// Package fineract defines the port to Apache Fineract that the adapter depends
// on, expressed in terms of Fineract's REAL commands (holdAmount, releaseAmount,
// undo). A stdlib HTTP implementation is provided here; an in-memory mock lives
// in test/mock.
package fineract

import (
	"context"

	"github.com/fineract/cbdc/api-adapter/types"
)

// HoldAmountRequest blocks funds on an account.
type HoldAmountRequest struct {
	Account   types.AccountID
	Amount    types.Amount
	Reference string
}

// ReleaseAmountRequest releases a prior hold (settlement).
type ReleaseAmountRequest struct {
	Account   types.AccountID
	HoldTxnID types.TxnID
	Reference string
}

// UndoRequest reverses a prior transaction. In Fineract this posts a NEW
// compensating transaction; it does not delete or mutate the original.
type UndoRequest struct {
	Account   types.AccountID
	TxnID     types.TxnID
	Reference string
}

// Txn is a Fineract transaction reference returned by a command.
type Txn struct {
	ID     types.TxnID
	Status string
}

// Client is the Fineract command port. Every method returns a Txn describing the
// resulting Fineract transaction.
type Client interface {
	// HoldAmount blocks funds and returns the hold transaction.
	HoldAmount(ctx context.Context, req HoldAmountRequest) (Txn, error)
	// ReleaseAmount releases a hold (settles) and returns the settlement txn.
	ReleaseAmount(ctx context.Context, req ReleaseAmountRequest) (Txn, error)
	// Undo posts a NEW compensating transaction for TxnID and returns it. The
	// original transaction is never mutated.
	Undo(ctx context.Context, req UndoRequest) (Txn, error)
	// Ping reports whether Fineract is reachable.
	Ping(ctx context.Context) error
}
