package fineract

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/fineract/cbdc/api-adapter/types"
)

// HTTPClient talks to a real Apache Fineract instance over its REST API. It maps
// each adapter intent to the correct Fineract savings-account transaction
// command. It is constructed with a base URL and applies a per-call timeout.
type HTTPClient struct {
	base    string
	http    *http.Client
	authHdr string // e.g. "Basic ..." or "Bearer ..."
}

// Option customises an HTTPClient.
type Option func(*HTTPClient)

// WithAuthHeader sets the Authorization header value sent on every request.
func WithAuthHeader(v string) Option { return func(c *HTTPClient) { c.authHdr = v } }

// WithHTTPClient overrides the underlying *http.Client.
func WithHTTPClient(h *http.Client) Option {
	return func(c *HTTPClient) {
		if h != nil {
			c.http = h
		}
	}
}

// NewHTTP builds an HTTPClient for the Fineract instance at baseURL.
func NewHTTP(baseURL string, opts ...Option) *HTTPClient {
	c := &HTTPClient{
		base: strings.TrimRight(baseURL, "/"),
		http: &http.Client{Timeout: 30 * time.Second},
	}
	for _, o := range opts {
		o(c)
	}
	return c
}

var _ Client = (*HTTPClient)(nil)

// txnResponse is the subset of a Fineract command response we consume.
type txnResponse struct {
	ResourceID    int64  `json:"resourceId"`
	TransactionID string `json:"transactionId"`
	Status        string `json:"status"`
}

func (c *HTTPClient) do(ctx context.Context, path string, body any) (Txn, error) {
	buf, err := json.Marshal(body)
	if err != nil {
		return Txn{}, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.base+path, bytes.NewReader(buf))
	if err != nil {
		return Txn{}, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	if c.authHdr != "" {
		req.Header.Set("Authorization", c.authHdr)
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return Txn{}, err
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return Txn{}, fmt.Errorf("fineract returned %d: %s", resp.StatusCode, strings.TrimSpace(string(data)))
	}
	var tr txnResponse
	_ = json.Unmarshal(data, &tr)
	id := tr.TransactionID
	if id == "" && tr.ResourceID != 0 {
		id = fmt.Sprintf("%d", tr.ResourceID)
	}
	return Txn{ID: types.TxnID(id), Status: tr.Status}, nil
}

// HoldAmount -> POST /savingsaccounts/{account}/transactions?command=holdAmount
func (c *HTTPClient) HoldAmount(ctx context.Context, req HoldAmountRequest) (Txn, error) {
	path := fmt.Sprintf("/savingsaccounts/%s/transactions?command=holdAmount", url.PathEscape(string(req.Account)))
	return c.do(ctx, path, map[string]any{
		"transactionAmount": req.Amount.Minor,
		"currencyCode":      string(req.Amount.Currency),
		"reference":         req.Reference,
	})
}

// ReleaseAmount -> POST /savingsaccounts/{account}/transactions/{holdTxn}?command=releaseAmount
func (c *HTTPClient) ReleaseAmount(ctx context.Context, req ReleaseAmountRequest) (Txn, error) {
	path := fmt.Sprintf("/savingsaccounts/%s/transactions/%s?command=releaseAmount",
		url.PathEscape(string(req.Account)), url.PathEscape(string(req.HoldTxnID)))
	return c.do(ctx, path, map[string]any{"reference": req.Reference})
}

// Undo -> POST /savingsaccounts/{account}/transactions/{txn}?command=undo
// Fineract records a NEW reversing transaction; the original stays immutable.
func (c *HTTPClient) Undo(ctx context.Context, req UndoRequest) (Txn, error) {
	path := fmt.Sprintf("/savingsaccounts/%s/transactions/%s?command=undo",
		url.PathEscape(string(req.Account)), url.PathEscape(string(req.TxnID)))
	return c.do(ctx, path, map[string]any{"reference": req.Reference})
}

// Ping -> GET /actuator/health (best-effort reachability check).
func (c *HTTPClient) Ping(ctx context.Context) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.base+"/actuator/health", nil)
	if err != nil {
		return err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 500 {
		return fmt.Errorf("fineract health returned %d", resp.StatusCode)
	}
	return nil
}
