module github.com/fineract/cbdc/api-adapter

go 1.21

require github.com/google/uuid v1.6.0
