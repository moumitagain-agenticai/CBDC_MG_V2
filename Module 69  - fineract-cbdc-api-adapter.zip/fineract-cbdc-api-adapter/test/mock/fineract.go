// Package mock provides an in-memory implementation of fineract.Client backed by
// a simple ledger. It honours the key invariant of the real system: an Undo
// never mutates or deletes the original transaction — it appends a NEW
// compensating transaction. It is for tests, examples, and local development.
package mock

import (
	"context"
	"sync"

	"github.com/fineract/cbdc/api-adapter/fineract"
	"github.com/fineract/cbdc/api-adapter/types"
	"github.com/google/uuid"
)

// txnRecord is one immutable ledger entry.
type txnRecord struct {
	ID       types.TxnID
	Account  types.AccountID
	Kind     string // hold | release | undo
	Amount   types.Amount
	Ref      types.TxnID // for release/undo: the transaction being acted on
	Reversed bool
}

// Fineract is an in-memory mock Fineract.
type Fineract struct {
	mu   sync.Mutex
	txns map[types.TxnID]*txnRecord
}

// New returns a ready mock.
func New() *Fineract { return &Fineract{txns: make(map[types.TxnID]*txnRecord)} }

var _ fineract.Client = (*Fineract)(nil)

func (f *Fineract) newID() types.TxnID { return types.TxnID(uuid.NewString()) }

// HoldAmount records a hold and returns its transaction.
func (f *Fineract) HoldAmount(_ context.Context, req fineract.HoldAmountRequest) (fineract.Txn, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	id := f.newID()
	f.txns[id] = &txnRecord{ID: id, Account: req.Account, Kind: "hold", Amount: req.Amount}
	return fineract.Txn{ID: id, Status: "held"}, nil
}

// ReleaseAmount releases a hold and returns the settlement transaction.
func (f *Fineract) ReleaseAmount(_ context.Context, req fineract.ReleaseAmountRequest) (fineract.Txn, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	hold, ok := f.txns[req.HoldTxnID]
	if !ok || hold.Kind != "hold" {
		return fineract.Txn{}, &notFound{what: "hold transaction"}
	}
	id := f.newID()
	f.txns[id] = &txnRecord{ID: id, Account: req.Account, Kind: "release", Amount: hold.Amount, Ref: req.HoldTxnID}
	return fineract.Txn{ID: id, Status: "released"}, nil
}

// Undo appends a NEW compensating transaction. The original is left untouched
// apart from a flag marking that a reversal exists (its amount/id are immutable).
func (f *Fineract) Undo(_ context.Context, req fineract.UndoRequest) (fineract.Txn, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	orig, ok := f.txns[req.TxnID]
	if !ok {
		return fineract.Txn{}, &notFound{what: "transaction"}
	}
	if orig.Reversed {
		return fineract.Txn{}, &conflict{msg: "transaction already reversed"}
	}
	orig.Reversed = true // marks that a reversal exists; original data is unchanged
	id := f.newID()
	f.txns[id] = &txnRecord{ID: id, Account: req.Account, Kind: "undo", Amount: orig.Amount, Ref: req.TxnID}
	return fineract.Txn{ID: id, Status: "reversed"}, nil
}

// Ping is always healthy for the mock.
func (f *Fineract) Ping(_ context.Context) error { return nil }

// TxnCount returns the number of ledger entries (useful for tests to prove that
// a reversal ADDED a transaction rather than removing one).
func (f *Fineract) TxnCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.txns)
}

// Exists reports whether a transaction id is present (originals never disappear).
func (f *Fineract) Exists(id types.TxnID) bool {
	f.mu.Lock()
	defer f.mu.Unlock()
	_, ok := f.txns[id]
	return ok
}

type notFound struct{ what string }

func (e *notFound) Error() string { return e.what + " not found" }

type conflict struct{ msg string }

func (e *conflict) Error() string { return e.msg }
