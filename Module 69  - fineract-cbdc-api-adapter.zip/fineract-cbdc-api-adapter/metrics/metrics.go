// Package metrics defines a small recorder interface for adapter operations,
// with a no-op default and a thread-safe in-memory implementation for tests.
package metrics

import (
	"sync"
	"time"
)

// Recorder records the outcome and latency of an operation.
type Recorder interface {
	RecordOp(operation, status string, dur time.Duration)
}

// Noop discards everything.
type Noop struct{}

// RecordOp does nothing.
func (Noop) RecordOp(string, string, time.Duration) {}

// OpStat aggregates one operation/status pair.
type OpStat struct {
	Count      int64
	TotalNanos int64
}

// InMemory is a thread-safe aggregating recorder.
type InMemory struct {
	mu    sync.Mutex
	stats map[string]OpStat
}

// NewInMemory returns a ready recorder.
func NewInMemory() *InMemory { return &InMemory{stats: make(map[string]OpStat)} }

// RecordOp aggregates under "operation/status".
func (m *InMemory) RecordOp(operation, status string, dur time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	k := operation + "/" + status
	s := m.stats[k]
	s.Count++
	s.TotalNanos += dur.Nanoseconds()
	m.stats[k] = s
}

// Snapshot copies the current stats.
func (m *InMemory) Snapshot() map[string]OpStat {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make(map[string]OpStat, len(m.stats))
	for k, v := range m.stats {
		out[k] = v
	}
	return out
}
