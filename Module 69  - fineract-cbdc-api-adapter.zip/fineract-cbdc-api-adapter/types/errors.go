package types

import "errors"

var (
	errInvalidCurrency = errors.New("invalid currency")
	errNegativeAmount  = errors.New("amount must not be negative")
)
