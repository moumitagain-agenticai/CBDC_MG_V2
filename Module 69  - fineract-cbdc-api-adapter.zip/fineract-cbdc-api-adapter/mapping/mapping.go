// Package mapping documents how the CBDC platform's money-path intents translate
// to real Apache Fineract commands. It exists because the platform's original
// /settle and /reverse endpoints do not exist in Fineract: settlement maps to
// Fineract's releaseAmount, and reversal maps to Fineract's undo (posted as a
// NEW compensating transaction, never a mutation of the original).
package mapping

// Intent is a platform money-path intent.
type Intent string

// The platform intents the adapter fronts.
const (
	IntentHold    Intent = "hold"    // reserve/block funds
	IntentSettle  Intent = "settle"  // settle a held amount
	IntentReverse Intent = "reverse" // reverse a prior transaction
)

// Entry documents one intent-to-Fineract mapping.
type Entry struct {
	Intent          Intent
	FineractCommand string
	Note            string
}

// Table is the authoritative mapping used by the adapter and surfaced for docs.
var Table = []Entry{
	{
		Intent:          IntentHold,
		FineractCommand: "holdAmount",
		Note:            "Blocks funds on a savings account (POST .../transactions?command=holdAmount).",
	},
	{
		Intent:          IntentSettle,
		FineractCommand: "releaseAmount",
		Note:            "Releases a prior hold to settle it (POST .../transactions/{holdTxnId}?command=releaseAmount). The platform's /settle does NOT exist in Fineract.",
	},
	{
		Intent:          IntentReverse,
		FineractCommand: "undo",
		Note:            "Posts a NEW compensating transaction that offsets the original; the original is immutable. You cannot un-burn e₹. The platform's /reverse does NOT exist in Fineract.",
	},
}

// CommandFor returns the Fineract command for an intent, and whether one exists.
func CommandFor(i Intent) (string, bool) {
	for _, e := range Table {
		if e.Intent == i {
			return e.FineractCommand, true
		}
	}
	return "", false
}
