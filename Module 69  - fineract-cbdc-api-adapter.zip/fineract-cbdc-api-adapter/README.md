# fineract-cbdc-api-adapter  (Module 69 — P0 rework)

The **API adapter** that every money-path write routes through. It is an
anti-corruption layer between the CBDC platform's money-path **intents** and
Apache Fineract's **real commands**.

Module path: `github.com/fineract/cbdc/api-adapter` · Go 1.21+.

## Why this rework exists

The platform originally assumed Fineract had `/settle` and `/reverse` endpoints.
**They do not exist.** This module maps the platform's intents to the commands
Fineract actually exposes, and documents the mapping:

| Platform intent | Fineract command | Note |
|-----------------|------------------|------|
| `hold`   | `holdAmount`     | Block funds on a savings account. |
| `settle` | `releaseAmount`  | Release a prior hold to settle it. **`/settle` does not exist in Fineract.** |
| `reverse`| `undo`           | Post a **NEW compensating transaction**; the original is immutable. **`/reverse` does not exist in Fineract.** |

The mapping is available in code via `Adapter.Mapping()` and the `mapping` package.

## The reversal rule (critical)

> **You cannot un-burn e₹. A reversal is a NEW transaction, not a mutation.**

`Reverse` maps to Fineract's `undo`, which **appends** a compensating
transaction. The original transaction is never deleted or changed. The result
carries **both** ids:

```go
type ReverseResult struct {
    OriginalTxnID types.TxnID // unchanged
    ReversalTxnID types.TxnID // the NEW compensating transaction
    Status        types.Status
    CreatedAt     time.Time
}
```

A test (`TestReverseIsNewTransactionNotMutation`) pins this: after a reverse the
ledger has **grown by one**, the original id **still exists**, and the reversal
id is **distinct**.

## Interface

```go
a := apiadapter.New(fineractClient)          // fineractClient is a fineract.Client
a.Hold(ctx, HoldRequest)     (HoldResult, error)     // -> holdAmount
a.Settle(ctx, SettleRequest) (SettleResult, error)   // -> releaseAmount
a.Reverse(ctx, ReverseRequest) (ReverseResult, error)// -> undo (new txn)
a.HealthCheck(ctx) error
a.Mapping() []mapping.Entry
```

The `fineract.Client` port has a real **stdlib HTTP implementation**
(`fineract.NewHTTP(baseURL, ...)`) that builds the correct Fineract
savings-account command requests, and an in-memory **mock** (`test/mock`) used by
the tests and example.

## Position on the money path

```
caller ─▶ idempotency-gateway (N2) ─▶ api-adapter (69) ─▶ Fineract
```

Idempotency belongs in **N2**, which sits in front of this adapter; async events
emitted around a write are delivered by the **outbox-relay (N1)**.

## Build, test, run

```bash
go build ./...      # all packages
go vet ./...        # clean
go test ./...       # unit tests
go run ./examples   # hold -> settle -> reverse against the mock
```

## Error model

`apiadapter.CodeOf(err)` returns one of: `validation`, `not_found`, `conflict`,
`unsupported`, `upstream` (Fineract returned an error), `unavailable` (Fineract
unreachable), `internal`.

## Dependencies

Minimal: only `github.com/google/uuid`. The HTTP Fineract client uses the
standard library. Metrics are behind a small interface (no-op default; in-memory
implementation for tests).
