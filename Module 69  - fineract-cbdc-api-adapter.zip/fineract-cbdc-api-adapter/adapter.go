// Package apiadapter is Module 69 of the E1 CBDC platform: the API adapter that
// every money-path write routes through. It is an anti-corruption layer between
// the platform's money-path intents (hold, settle, reverse) and Apache
// Fineract's real commands (holdAmount, releaseAmount, undo).
//
// It exists because the platform's original /settle and /reverse endpoints do
// not exist in Fineract. Settlement is mapped to releaseAmount; reversal is
// mapped to undo and is always modelled as a NEW compensating transaction — the
// original transaction is immutable. You cannot un-burn e₹: a reversal is a new
// transaction, not a mutation.
package apiadapter

import (
	"context"
	"time"

	"github.com/fineract/cbdc/api-adapter/fineract"
	"github.com/fineract/cbdc/api-adapter/mapping"
	"github.com/fineract/cbdc/api-adapter/metrics"
	"github.com/fineract/cbdc/api-adapter/types"
)

// Adapter fronts the money path and translates intents to Fineract commands.
type Adapter struct {
	client  fineract.Client
	metrics metrics.Recorder
}

// Option customises an Adapter.
type Option func(*Adapter)

// WithMetrics attaches a metrics recorder.
func WithMetrics(r metrics.Recorder) Option {
	return func(a *Adapter) {
		if r != nil {
			a.metrics = r
		}
	}
}

// New builds an Adapter over the given Fineract client.
func New(client fineract.Client, opts ...Option) *Adapter {
	a := &Adapter{client: client, metrics: metrics.Noop{}}
	for _, o := range opts {
		o(a)
	}
	return a
}

// Mapping returns the documented intent-to-Fineract command table.
func (a *Adapter) Mapping() []mapping.Entry { return mapping.Table }

func (a *Adapter) record(intent mapping.Intent, start time.Time, err error) {
	status := "ok"
	if err != nil {
		status = string(CodeOf(err))
	}
	a.metrics.RecordOp(string(intent), status, time.Since(start))
}

// classifyUpstream turns a Fineract client error into a classified adapter
// error. A nil error returns nil.
func classifyUpstream(err error) error {
	if err == nil {
		return nil
	}
	return NewUpstreamError("fineract command failed", err)
}

// HoldRequest reserves (blocks) funds on an account.
type HoldRequest struct {
	Account   types.AccountID `json:"account"`
	Amount    types.Amount    `json:"amount"`
	Reference string          `json:"reference"`
}

// Validate checks the request.
func (r HoldRequest) Validate() error {
	if r.Account == "" {
		return NewValidationError("account is required", nil)
	}
	if err := r.Amount.Validate(); err != nil {
		return NewValidationError("amount: "+err.Error(), err)
	}
	if !r.Amount.IsPositive() {
		return NewValidationError("amount must be positive", nil)
	}
	return nil
}

// HoldResult is the outcome of a hold.
type HoldResult struct {
	HoldTxnID types.TxnID  `json:"hold_txn_id"`
	Status    types.Status `json:"status"`
	CreatedAt time.Time    `json:"created_at"`
}

// Hold blocks funds. Intent "hold" -> Fineract "holdAmount".
func (a *Adapter) Hold(ctx context.Context, req HoldRequest) (HoldResult, error) {
	start := time.Now()
	var err error
	defer func() { a.record(mapping.IntentHold, start, err) }()
	if err = req.Validate(); err != nil {
		return HoldResult{}, err
	}
	txn, cerr := a.client.HoldAmount(ctx, fineract.HoldAmountRequest{
		Account: req.Account, Amount: req.Amount, Reference: req.Reference,
	})
	if cerr != nil {
		err = classifyUpstream(cerr)
		return HoldResult{}, err
	}
	return HoldResult{HoldTxnID: txn.ID, Status: types.StatusHeld, CreatedAt: time.Now().UTC()}, nil
}

// SettleRequest settles a previously held amount.
//
// NOTE: the platform's original "/settle" endpoint does not exist in Fineract.
// This maps to Fineract's releaseAmount against the hold transaction.
type SettleRequest struct {
	Account   types.AccountID `json:"account"`
	HoldTxnID types.TxnID     `json:"hold_txn_id"`
	Reference string          `json:"reference"`
}

// Validate checks the request.
func (r SettleRequest) Validate() error {
	if r.Account == "" {
		return NewValidationError("account is required", nil)
	}
	if r.HoldTxnID == "" {
		return NewValidationError("hold_txn_id is required", nil)
	}
	return nil
}

// SettleResult is the outcome of a settlement.
type SettleResult struct {
	SettleTxnID types.TxnID  `json:"settle_txn_id"`
	HoldTxnID   types.TxnID  `json:"hold_txn_id"`
	Status      types.Status `json:"status"`
	CreatedAt   time.Time    `json:"created_at"`
}

// Settle releases a hold. Intent "settle" -> Fineract "releaseAmount".
func (a *Adapter) Settle(ctx context.Context, req SettleRequest) (SettleResult, error) {
	start := time.Now()
	var err error
	defer func() { a.record(mapping.IntentSettle, start, err) }()
	if err = req.Validate(); err != nil {
		return SettleResult{}, err
	}
	txn, cerr := a.client.ReleaseAmount(ctx, fineract.ReleaseAmountRequest{
		Account: req.Account, HoldTxnID: req.HoldTxnID, Reference: req.Reference,
	})
	if cerr != nil {
		err = classifyUpstream(cerr)
		return SettleResult{}, err
	}
	return SettleResult{
		SettleTxnID: txn.ID, HoldTxnID: req.HoldTxnID,
		Status: types.StatusCompleted, CreatedAt: time.Now().UTC(),
	}, nil
}

// ReverseRequest reverses a prior transaction.
//
// NOTE: the platform's original "/reverse" endpoint does not exist in Fineract.
// This maps to Fineract's undo, which posts a NEW compensating transaction. The
// original transaction is never mutated.
type ReverseRequest struct {
	Account       types.AccountID `json:"account"`
	OriginalTxnID types.TxnID     `json:"original_txn_id"`
	Reference     string          `json:"reference"`
}

// Validate checks the request.
func (r ReverseRequest) Validate() error {
	if r.Account == "" {
		return NewValidationError("account is required", nil)
	}
	if r.OriginalTxnID == "" {
		return NewValidationError("original_txn_id is required", nil)
	}
	return nil
}

// ReverseResult carries BOTH the original transaction id (unchanged) and the id
// of the NEW compensating transaction created by the reversal.
type ReverseResult struct {
	OriginalTxnID types.TxnID  `json:"original_txn_id"`
	ReversalTxnID types.TxnID  `json:"reversal_txn_id"`
	Status        types.Status `json:"status"`
	CreatedAt     time.Time    `json:"created_at"`
}

// Reverse reverses a transaction. Intent "reverse" -> Fineract "undo". The
// result is a NEW transaction; the original is immutable.
func (a *Adapter) Reverse(ctx context.Context, req ReverseRequest) (ReverseResult, error) {
	start := time.Now()
	var err error
	defer func() { a.record(mapping.IntentReverse, start, err) }()
	if err = req.Validate(); err != nil {
		return ReverseResult{}, err
	}
	txn, cerr := a.client.Undo(ctx, fineract.UndoRequest{
		Account: req.Account, TxnID: req.OriginalTxnID, Reference: req.Reference,
	})
	if cerr != nil {
		err = classifyUpstream(cerr)
		return ReverseResult{}, err
	}
	return ReverseResult{
		OriginalTxnID: req.OriginalTxnID, // unchanged
		ReversalTxnID: txn.ID,            // new compensating transaction
		Status:        types.StatusReversed,
		CreatedAt:     time.Now().UTC(),
	}, nil
}

// HealthCheck reports whether the adapter's Fineract backend is reachable.
func (a *Adapter) HealthCheck(ctx context.Context) error {
	if err := a.client.Ping(ctx); err != nil {
		return NewUnavailableError("fineract unreachable", err)
	}
	return nil
}
