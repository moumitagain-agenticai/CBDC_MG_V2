// Command example demonstrates Module 69, the API adapter, end to end against an
// in-memory mock Fineract: hold -> settle -> reverse, showing that a reversal is
// a NEW compensating transaction and the original is preserved.
//
//	go run ./examples
package main

import (
	"context"
	"fmt"
	"log"

	adapter "github.com/fineract/cbdc/api-adapter"
	"github.com/fineract/cbdc/api-adapter/metrics"
	"github.com/fineract/cbdc/api-adapter/test/mock"
	"github.com/fineract/cbdc/api-adapter/types"
)

func main() {
	f := mock.New()
	a := adapter.New(f, adapter.WithMetrics(metrics.NewInMemory()))
	ctx := context.Background()

	fmt.Println("intent -> Fineract command mapping:")
	for _, e := range a.Mapping() {
		fmt.Printf("  %-8s -> %-14s %s\n", e.Intent, e.FineractCommand, e.Note)
	}
	fmt.Println()

	hold, err := a.Hold(ctx, adapter.HoldRequest{Account: "acc-1", Amount: types.NewAmount(50000, types.INR), Reference: "hold"})
	if err != nil {
		log.Fatalf("hold: %v", err)
	}
	fmt.Printf("hold     -> holdAmount     hold_txn=%s\n", hold.HoldTxnID)

	settle, err := a.Settle(ctx, adapter.SettleRequest{Account: "acc-1", HoldTxnID: hold.HoldTxnID, Reference: "settle"})
	if err != nil {
		log.Fatalf("settle: %v", err)
	}
	fmt.Printf("settle   -> releaseAmount  settle_txn=%s\n", settle.SettleTxnID)

	rev, err := a.Reverse(ctx, adapter.ReverseRequest{Account: "acc-1", OriginalTxnID: settle.SettleTxnID, Reference: "reverse"})
	if err != nil {
		log.Fatalf("reverse: %v", err)
	}
	fmt.Printf("reverse  -> undo           original=%s  NEW reversal_txn=%s  status=%s\n",
		rev.OriginalTxnID, rev.ReversalTxnID, rev.Status)

	fmt.Printf("\noriginal transaction still present: %v (reversal appended, not mutated)\n", f.Exists(settle.SettleTxnID))
}
