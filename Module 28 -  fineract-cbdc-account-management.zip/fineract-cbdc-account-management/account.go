// Package account is Module 28 of the E1 CBDC platform: account management.
//
// This rework EXPOSES REST APIs over the account domain (see the rest package):
// account lifecycle (create, freeze, close), balance reads, and balance
// movements (credit/debit) are all reachable over HTTP. The domain and business
// rules live here; the transport lives in the rest subpackage; persistence is
// behind the store port.
package account

import (
	"strings"
	"time"

	"github.com/google/uuid"
)

// Type is the kind of account.
type Type string

// Account types.
const (
	TypeWallet     Type = "WALLET"     // an end-user CBDC wallet
	TypeSettlement Type = "SETTLEMENT" // an institutional settlement account
)

// Valid reports whether t is a known type.
func (t Type) Valid() bool { return t == TypeWallet || t == TypeSettlement }

// Status is the lifecycle state of an account.
type Status string

// Account statuses.
const (
	StatusActive Status = "ACTIVE"
	StatusFrozen Status = "FROZEN"
	StatusClosed Status = "CLOSED"
)

// Valid reports whether s is a known status.
func (s Status) Valid() bool {
	switch s {
	case StatusActive, StatusFrozen, StatusClosed:
		return true
	}
	return false
}

// Account is a CBDC account.
type Account struct {
	ID           string    `json:"id"`
	Holder       string    `json:"holder"`
	Type         Type      `json:"type"`
	Currency     string    `json:"currency"`
	Status       Status    `json:"status"`
	BalanceMinor int64     `json:"balance_minor"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

// CreateRequest is the input to Service.Create.
type CreateRequest struct {
	Holder              string `json:"holder"`
	Type                Type   `json:"type"`
	Currency            string `json:"currency"`
	OpeningBalanceMinor int64  `json:"opening_balance_minor"`
}

func newAccount(req CreateRequest) *Account {
	now := time.Now().UTC()
	return &Account{
		ID:           uuid.NewString(),
		Holder:       strings.TrimSpace(req.Holder),
		Type:         req.Type,
		Currency:     strings.TrimSpace(req.Currency),
		Status:       StatusActive,
		BalanceMinor: req.OpeningBalanceMinor,
		CreatedAt:    now,
		UpdatedAt:    now,
	}
}
