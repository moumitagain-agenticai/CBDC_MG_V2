package rest_test

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	account "github.com/fineract/cbdc/account-management"
	"github.com/fineract/cbdc/account-management/rest"
	"github.com/fineract/cbdc/account-management/store"
)

func newServer() *httptest.Server {
	svc := account.NewService(store.NewMemory())
	return httptest.NewServer(rest.NewHandler(svc))
}

func doJSON(t *testing.T, method, url, body string) (*http.Response, map[string]any) {
	t.Helper()
	var r *http.Request
	var err error
	if body == "" {
		r, err = http.NewRequestWithContext(context.Background(), method, url, nil)
	} else {
		r, err = http.NewRequestWithContext(context.Background(), method, url, bytes.NewBufferString(body))
	}
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	resp, err := http.DefaultClient.Do(r)
	if err != nil {
		t.Fatalf("do: %v", err)
	}
	var m map[string]any
	_ = json.NewDecoder(resp.Body).Decode(&m)
	resp.Body.Close()
	return resp, m
}

func TestRestCreateGetCreditDebit(t *testing.T) {
	srv := newServer()
	defer srv.Close()

	resp, m := doJSON(t, http.MethodPost, srv.URL+"/accounts",
		`{"holder":"alice","type":"WALLET","currency":"INR","opening_balance_minor":0}`)
	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("create status = %d", resp.StatusCode)
	}
	id, _ := m["id"].(string)
	if id == "" {
		t.Fatalf("no id in create response: %v", m)
	}

	// credit 1000
	if resp, _ := doJSON(t, http.MethodPost, srv.URL+"/accounts/"+id+"/credit", `{"amount_minor":1000}`); resp.StatusCode != http.StatusOK {
		t.Fatalf("credit status = %d", resp.StatusCode)
	}
	// balance == 1000
	_, bm := doJSON(t, http.MethodGet, srv.URL+"/accounts/"+id+"/balance", "")
	if int64(bm["balance_minor"].(float64)) != 1000 {
		t.Fatalf("want balance 1000, got %v", bm["balance_minor"])
	}
	// debit 1500 -> 422 insufficient
	if resp, _ := doJSON(t, http.MethodPost, srv.URL+"/accounts/"+id+"/debit", `{"amount_minor":1500}`); resp.StatusCode != http.StatusUnprocessableEntity {
		t.Fatalf("want 422 on insufficient funds, got %d", resp.StatusCode)
	}
}

func TestRestGetNotFound(t *testing.T) {
	srv := newServer()
	defer srv.Close()
	resp, m := doJSON(t, http.MethodGet, srv.URL+"/accounts/does-not-exist", "")
	if resp.StatusCode != http.StatusNotFound {
		t.Fatalf("want 404, got %d", resp.StatusCode)
	}
	errObj, _ := m["error"].(map[string]any)
	if errObj["code"] != "not_found" {
		t.Fatalf("want not_found code, got %v", m)
	}
}

func TestRestValidation(t *testing.T) {
	srv := newServer()
	defer srv.Close()
	resp, _ := doJSON(t, http.MethodPost, srv.URL+"/accounts", `{"type":"WALLET","currency":"INR"}`)
	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("want 400 for missing holder, got %d", resp.StatusCode)
	}
}

func TestRestListByHolder(t *testing.T) {
	srv := newServer()
	defer srv.Close()
	doJSON(t, http.MethodPost, srv.URL+"/accounts", `{"holder":"alice","type":"WALLET","currency":"INR"}`)
	doJSON(t, http.MethodPost, srv.URL+"/accounts", `{"holder":"bob","type":"WALLET","currency":"INR"}`)
	_, m := doJSON(t, http.MethodGet, srv.URL+"/accounts?holder=alice", "")
	accs, _ := m["accounts"].([]any)
	if len(accs) != 1 {
		t.Fatalf("want 1 account for alice, got %d", len(accs))
	}
}

func TestRestStatusChange(t *testing.T) {
	srv := newServer()
	defer srv.Close()
	_, m := doJSON(t, http.MethodPost, srv.URL+"/accounts", `{"holder":"alice","type":"WALLET","currency":"INR"}`)
	id := m["id"].(string)
	resp, body := doJSON(t, http.MethodPost, srv.URL+"/accounts/"+id+"/status", `{"status":"FROZEN"}`)
	if resp.StatusCode != http.StatusOK || body["status"] != "FROZEN" {
		t.Fatalf("status change failed: %d %v", resp.StatusCode, body)
	}
	_ = strings.TrimSpace("")
}
