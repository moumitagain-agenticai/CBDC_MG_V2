// Package rest exposes the account service over a REST/HTTP API — the transport
// this module's rework adds. It uses only the standard library and routes
// manually (no 1.22 ServeMux method patterns) so it builds under Go 1.21.
//
// Routes:
//
//	POST /accounts                 create an account
//	GET  /accounts?holder=NAME     list accounts (optionally by holder)
//	GET  /accounts/{id}            fetch an account
//	GET  /accounts/{id}/balance    fetch balance only
//	POST /accounts/{id}/status     change status  {"status":"FROZEN"}
//	POST /accounts/{id}/credit     add funds      {"amount_minor":1000}
//	POST /accounts/{id}/debit      remove funds   {"amount_minor":1000}
package rest

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"

	account "github.com/fineract/cbdc/account-management"
)

// Handler is an http.Handler serving the account REST API.
type Handler struct {
	svc *account.Service
}

// NewHandler builds a REST handler over an account service.
func NewHandler(svc *account.Service) *Handler { return &Handler{svc: svc} }

// ServeHTTP routes a request. It implements http.Handler.
func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	path := strings.Trim(r.URL.Path, "/")
	parts := strings.Split(path, "/")
	// parts[0] must be "accounts"
	if len(parts) == 0 || parts[0] != "accounts" {
		writeErr(w, account.ErrNotFound("unknown route"))
		return
	}
	ctx := r.Context()
	switch len(parts) {
	case 1: // /accounts
		switch r.Method {
		case http.MethodPost:
			h.create(ctx, w, r)
		case http.MethodGet:
			h.list(ctx, w, r)
		default:
			methodNotAllowed(w)
		}
	case 2: // /accounts/{id}
		id := parts[1]
		if r.Method == http.MethodGet {
			h.get(ctx, w, id)
		} else {
			methodNotAllowed(w)
		}
	case 3: // /accounts/{id}/{action}
		id, action := parts[1], parts[2]
		switch {
		case r.Method == http.MethodGet && action == "balance":
			h.balance(ctx, w, id)
		case r.Method == http.MethodPost && action == "status":
			h.status(ctx, w, r, id)
		case r.Method == http.MethodPost && action == "credit":
			h.move(ctx, w, r, id, true)
		case r.Method == http.MethodPost && action == "debit":
			h.move(ctx, w, r, id, false)
		default:
			writeErr(w, account.ErrNotFound("unknown route"))
		}
	default:
		writeErr(w, account.ErrNotFound("unknown route"))
	}
}

func (h *Handler) create(ctx context.Context, w http.ResponseWriter, r *http.Request) {
	var req account.CreateRequest
	if err := decode(r, &req); err != nil {
		writeErr(w, err)
		return
	}
	acc, err := h.svc.Create(ctx, req)
	if err != nil {
		writeErr(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, acc)
}

func (h *Handler) list(ctx context.Context, w http.ResponseWriter, r *http.Request) {
	accs, err := h.svc.List(ctx, r.URL.Query().Get("holder"))
	if err != nil {
		writeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"accounts": accs})
}

func (h *Handler) get(ctx context.Context, w http.ResponseWriter, id string) {
	acc, err := h.svc.Get(ctx, id)
	if err != nil {
		writeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, acc)
}

func (h *Handler) balance(ctx context.Context, w http.ResponseWriter, id string) {
	acc, err := h.svc.Get(ctx, id)
	if err != nil {
		writeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"id": acc.ID, "balance_minor": acc.BalanceMinor, "currency": acc.Currency,
	})
}

func (h *Handler) status(ctx context.Context, w http.ResponseWriter, r *http.Request, id string) {
	var body struct {
		Status account.Status `json:"status"`
	}
	if err := decode(r, &body); err != nil {
		writeErr(w, err)
		return
	}
	acc, err := h.svc.SetStatus(ctx, id, body.Status)
	if err != nil {
		writeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, acc)
}

func (h *Handler) move(ctx context.Context, w http.ResponseWriter, r *http.Request, id string, credit bool) {
	var body struct {
		AmountMinor int64 `json:"amount_minor"`
	}
	if err := decode(r, &body); err != nil {
		writeErr(w, err)
		return
	}
	var (
		acc *account.Account
		err error
	)
	if credit {
		acc, err = h.svc.Credit(ctx, id, body.AmountMinor)
	} else {
		acc, err = h.svc.Debit(ctx, id, body.AmountMinor)
	}
	if err != nil {
		writeErr(w, err)
		return
	}
	writeJSON(w, http.StatusOK, acc)
}

func decode(r *http.Request, v any) error {
	if r.Body == nil {
		return account.ErrValidation("request body is required")
	}
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(v); err != nil {
		return account.ErrValidation("invalid JSON body: " + err.Error())
	}
	return nil
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, err error) {
	writeJSON(w, account.HTTPStatus(err), map[string]any{
		"error": map[string]any{"code": string(account.CodeOf(err)), "message": err.Error()},
	})
}

func methodNotAllowed(w http.ResponseWriter) {
	writeJSON(w, http.StatusMethodNotAllowed, map[string]any{
		"error": map[string]any{"code": "method_not_allowed", "message": "method not allowed"},
	})
}
