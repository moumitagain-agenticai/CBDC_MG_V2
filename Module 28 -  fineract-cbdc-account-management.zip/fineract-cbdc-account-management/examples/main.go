// Command example starts the account REST API on an in-memory store and drives
// it with a few HTTP calls: create -> credit -> balance -> freeze.
//
//	go run ./examples
package main

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"

	account "github.com/fineract/cbdc/account-management"
	"github.com/fineract/cbdc/account-management/rest"
	"github.com/fineract/cbdc/account-management/store"
)

func call(method, url, body string) string {
	var r *http.Request
	if body == "" {
		r, _ = http.NewRequest(method, url, nil)
	} else {
		r, _ = http.NewRequest(method, url, bytes.NewBufferString(body))
	}
	resp, err := http.DefaultClient.Do(r)
	if err != nil {
		panic(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return fmt.Sprintf("%d %s", resp.StatusCode, string(b))
}

func main() {
	svc := account.NewService(store.NewMemory())
	srv := httptest.NewServer(rest.NewHandler(svc))
	defer srv.Close()

	fmt.Println("POST /accounts        ->", call("POST", srv.URL+"/accounts",
		`{"holder":"alice","type":"WALLET","currency":"INR","opening_balance_minor":0}`))

	// grab the id from a list call for the demo
	list := call("GET", srv.URL+"/accounts?holder=alice", "")
	fmt.Println("GET  /accounts?holder ->", list)

	// create a fresh one and act on it by re-reading id via service for simplicity
	acc, _ := svc.Create(context.Background(), account.CreateRequest{Holder: "bob", Type: account.TypeWallet, Currency: "INR"})
	fmt.Println("POST /credit          ->", call("POST", srv.URL+"/accounts/"+acc.ID+"/credit", `{"amount_minor":25000}`))
	fmt.Println("GET  /balance         ->", call("GET", srv.URL+"/accounts/"+acc.ID+"/balance", ""))
	fmt.Println("POST /status FROZEN   ->", call("POST", srv.URL+"/accounts/"+acc.ID+"/status", `{"status":"FROZEN"}`))
	fmt.Println("POST /debit (frozen)  ->", call("POST", srv.URL+"/accounts/"+acc.ID+"/debit", `{"amount_minor":100}`))
}
