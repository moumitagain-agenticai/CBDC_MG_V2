# BUILD REPORT — fineract-cbdc-account-management (Module 28)

Toolchain: Go 1.22 (module declares `go 1.21`). Module path:
`github.com/fineract/cbdc/account-management`.

| Check | Command | Result |
|-------|---------|--------|
| Formatting | `gofmt -l .` | clean |
| Dependencies | `go mod tidy` | clean (`google/uuid`, `lib/pq`) |
| Build | `go build ./...` | pass (exit 0) |
| Vet | `go vet ./...` | pass (exit 0) |
| Unit + REST tests | `go test ./...` | pass (account, rest, store) |
| Example | `go run ./examples` | starts the REST API and drives create/credit/balance/freeze/debit |

Requirement coverage (finalised list, #28 — REWORK expose REST APIs): the account
domain and rules are exposed over a REST/HTTP API (`rest.Handler`) covering
create, list, get, balance, status change, credit, and debit, with proper HTTP
status mapping. Persistence is behind a `Store` port with in-memory and
PostgreSQL implementations.

Tests: service-level create/get, credit then debit to a 600 balance, insufficient
funds → unprocessable, frozen account blocks movement, closing a non-zero balance
→ unprocessable, create validation. REST-level (httptest): create returns 201 with
an id, credit + balance read back 1000, debit beyond balance → 422, get unknown →
404 with a `not_found` code, missing holder → 400, list filtered by holder,
status change to FROZEN. A DB-gated Postgres CRUD test runs when `DATABASE_DSN`
is set.

Design note: the `Store` interface is defined in the `account` package (where the
service consumes it) and implemented in the `store` subpackage, so the dependency
graph is acyclic. The REST layer routes manually over the standard library (no Go
1.22 ServeMux method patterns), so it builds under the declared `go 1.21`.
Nothing pushed to any remote.
