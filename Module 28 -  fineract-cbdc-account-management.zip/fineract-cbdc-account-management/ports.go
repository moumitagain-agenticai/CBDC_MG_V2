package account

import "context"

// Store is the account persistence port. It is defined in the domain package
// (where the service consumes it) and implemented by the store subpackage, which
// keeps the dependency graph acyclic: store depends on account, not vice versa.
type Store interface {
	// Create stores a new account, rejecting a duplicate id.
	Create(ctx context.Context, a *Account) error
	// Get returns an account by id.
	Get(ctx context.Context, id string) (*Account, error)
	// Update persists a mutated account.
	Update(ctx context.Context, a *Account) error
	// ListByHolder returns accounts for a holder (all if holder is empty).
	ListByHolder(ctx context.Context, holder string) ([]Account, error)
	// Ping checks backend health.
	Ping(ctx context.Context) error
}
