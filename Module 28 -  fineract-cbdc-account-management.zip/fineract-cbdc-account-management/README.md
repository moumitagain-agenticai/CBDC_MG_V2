# fineract-cbdc-account-management  (Module 28 — P0 rework)

Account management for the CBDC platform. This rework **exposes REST APIs** over
the account domain, so account lifecycle, balances, and balance movements are
reachable over HTTP by the orchestrator (14), settlement (16), accounting (19),
and reversal-orchestrator (23).

Module path: `github.com/fineract/cbdc/account-management` · Go 1.21+.

## REST API

| Method & path | Purpose | Body |
|---------------|---------|------|
| `POST /accounts` | open an account | `{"holder","type","currency","opening_balance_minor"}` |
| `GET /accounts?holder=NAME` | list accounts (optionally by holder) | — |
| `GET /accounts/{id}` | fetch an account | — |
| `GET /accounts/{id}/balance` | fetch balance only | — |
| `POST /accounts/{id}/status` | change status | `{"status":"FROZEN"}` |
| `POST /accounts/{id}/credit` | add funds | `{"amount_minor":1000}` |
| `POST /accounts/{id}/debit` | remove funds | `{"amount_minor":1000}` |

`type` is `WALLET` or `SETTLEMENT`; `status` is `ACTIVE`, `FROZEN`, or `CLOSED`.
Errors return `{"error":{"code","message"}}` with a matching HTTP status:
`400` validation, `404` not found, `409` conflict, `422` unprocessable
(insufficient funds / not ACTIVE / closing a non-zero balance), `500` internal.

```bash
curl -XPOST localhost:8080/accounts \
  -d '{"holder":"alice","type":"WALLET","currency":"INR","opening_balance_minor":0}'
curl -XPOST localhost:8080/accounts/<id>/credit -d '{"amount_minor":25000}'
curl      localhost:8080/accounts/<id>/balance
```

## Business rules

Credit and debit require an **ACTIVE** account; debit requires a **sufficient
balance**; an account can only be **CLOSED** when its balance is zero. Balances
are integer minor units, so there is no floating-point drift.

## Layout

| Path | Responsibility |
|------|----------------|
| `account.go` | `Account`, `Type`, `Status`, `CreateRequest`. |
| `service.go` | `Service` — the business rules (create, get, list, status, credit, debit). |
| `ports.go` | The `Store` port (defined here, where the service consumes it). |
| `errors.go` | Classified errors + `CodeOf` + `HTTPStatus`. |
| `rest/` | `Handler` — the REST/HTTP transport (standard library only). |
| `store/` | `Store` implementations: in-memory and PostgreSQL + `Migrate`. |
| `migrations/001_init.sql` | The `accounts` table. |

The `Store` interface lives in the `account` package and the concrete stores live
in `store/`, so the dependency graph is acyclic (`store` and `rest` depend on
`account`, not the reverse).

## Build, test, run

```bash
go build ./...
go vet ./...
go test ./...                       # unit + REST (httptest) tests
DATABASE_DSN=postgres://... go test ./store/...   # DB-gated Postgres test
go run ./examples                   # starts the API and drives it
```

## Dependencies

`github.com/google/uuid` (ids) and `github.com/lib/pq` (PostgreSQL driver). The
REST layer uses only the standard library.
