package account

import (
	"context"
	"time"
)

// Service holds the account business rules over a Store.
type Service struct {
	store Store
}

// NewService builds a service over a store.
func NewService(s Store) *Service { return &Service{store: s} }

// Create opens a new ACTIVE account.
func (svc *Service) Create(ctx context.Context, req CreateRequest) (*Account, error) {
	if req.Holder == "" {
		return nil, ErrValidation("holder is required")
	}
	if !req.Type.Valid() {
		return nil, ErrValidation("type must be WALLET or SETTLEMENT")
	}
	if len(req.Currency) != 3 {
		return nil, ErrValidation("currency must be a 3-letter code")
	}
	if req.OpeningBalanceMinor < 0 {
		return nil, ErrValidation("opening balance must not be negative")
	}
	acc := newAccount(req)
	if err := svc.store.Create(ctx, acc); err != nil {
		return nil, err
	}
	return acc, nil
}

// Get returns an account by id.
func (svc *Service) Get(ctx context.Context, id string) (*Account, error) {
	return svc.store.Get(ctx, id)
}

// List returns accounts for a holder (all accounts if holder is empty).
func (svc *Service) List(ctx context.Context, holder string) ([]Account, error) {
	return svc.store.ListByHolder(ctx, holder)
}

// SetStatus changes an account's status. Closing requires a zero balance.
func (svc *Service) SetStatus(ctx context.Context, id string, status Status) (*Account, error) {
	if !status.Valid() {
		return nil, ErrValidation("invalid status")
	}
	acc, err := svc.store.Get(ctx, id)
	if err != nil {
		return nil, err
	}
	if status == StatusClosed && acc.BalanceMinor != 0 {
		return nil, ErrUnprocessable("cannot close an account with a non-zero balance")
	}
	acc.Status = status
	acc.UpdatedAt = time.Now().UTC()
	if err := svc.store.Update(ctx, acc); err != nil {
		return nil, err
	}
	return acc, nil
}

// Credit adds funds to an ACTIVE account.
func (svc *Service) Credit(ctx context.Context, id string, amountMinor int64) (*Account, error) {
	if amountMinor <= 0 {
		return nil, ErrValidation("amount must be positive")
	}
	acc, err := svc.store.Get(ctx, id)
	if err != nil {
		return nil, err
	}
	if acc.Status != StatusActive {
		return nil, ErrUnprocessable("account is not ACTIVE")
	}
	acc.BalanceMinor += amountMinor
	acc.UpdatedAt = time.Now().UTC()
	if err := svc.store.Update(ctx, acc); err != nil {
		return nil, err
	}
	return acc, nil
}

// Debit removes funds from an ACTIVE account with a sufficient balance.
func (svc *Service) Debit(ctx context.Context, id string, amountMinor int64) (*Account, error) {
	if amountMinor <= 0 {
		return nil, ErrValidation("amount must be positive")
	}
	acc, err := svc.store.Get(ctx, id)
	if err != nil {
		return nil, err
	}
	if acc.Status != StatusActive {
		return nil, ErrUnprocessable("account is not ACTIVE")
	}
	if acc.BalanceMinor < amountMinor {
		return nil, ErrUnprocessable("insufficient funds")
	}
	acc.BalanceMinor -= amountMinor
	acc.UpdatedAt = time.Now().UTC()
	if err := svc.store.Update(ctx, acc); err != nil {
		return nil, err
	}
	return acc, nil
}
