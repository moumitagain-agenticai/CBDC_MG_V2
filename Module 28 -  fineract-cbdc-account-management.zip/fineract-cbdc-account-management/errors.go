package account

import (
	"errors"
	"fmt"
	"net/http"
)

// Code classifies an account error.
type Code string

// Error codes.
const (
	CodeValidation    Code = "validation"    // malformed input
	CodeNotFound      Code = "not_found"     // account not found
	CodeConflict      Code = "conflict"      // duplicate id
	CodeUnprocessable Code = "unprocessable" // valid input but not allowed (funds/state)
	CodeInternal      Code = "internal"      // store or unexpected failure
)

// Error is the classified error type.
type Error struct {
	Code    Code
	Message string
	Err     error
}

func (e *Error) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

func (e *Error) Unwrap() error { return e.Err }

// ErrValidation builds a validation error.
func ErrValidation(m string) *Error { return &Error{Code: CodeValidation, Message: m} }

// ErrNotFound builds a not-found error.
func ErrNotFound(m string) *Error { return &Error{Code: CodeNotFound, Message: m} }

// ErrConflict builds a conflict error.
func ErrConflict(m string) *Error { return &Error{Code: CodeConflict, Message: m} }

// ErrUnprocessable builds an unprocessable error (e.g. insufficient funds).
func ErrUnprocessable(m string) *Error { return &Error{Code: CodeUnprocessable, Message: m} }

// ErrInternal wraps an internal error.
func ErrInternal(m string, err error) *Error { return &Error{Code: CodeInternal, Message: m, Err: err} }

// CodeOf returns the classification of err.
func CodeOf(err error) Code {
	if err == nil {
		return ""
	}
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return CodeInternal
}

// HTTPStatus maps an error to an HTTP status code, for the REST layer.
func HTTPStatus(err error) int {
	switch CodeOf(err) {
	case "":
		return http.StatusOK
	case CodeValidation:
		return http.StatusBadRequest
	case CodeNotFound:
		return http.StatusNotFound
	case CodeConflict:
		return http.StatusConflict
	case CodeUnprocessable:
		return http.StatusUnprocessableEntity
	default:
		return http.StatusInternalServerError
	}
}
