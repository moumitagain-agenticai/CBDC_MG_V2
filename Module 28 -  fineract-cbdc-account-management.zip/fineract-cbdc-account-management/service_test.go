package account_test

import (
	"context"
	"testing"

	account "github.com/fineract/cbdc/account-management"
	"github.com/fineract/cbdc/account-management/store"
)

func newSvc() *account.Service { return account.NewService(store.NewMemory()) }

func TestCreateAndGet(t *testing.T) {
	svc := newSvc()
	ctx := context.Background()
	acc, err := svc.Create(ctx, account.CreateRequest{Holder: "alice", Type: account.TypeWallet, Currency: "INR"})
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if acc.Status != account.StatusActive || acc.ID == "" {
		t.Fatalf("unexpected account: %+v", acc)
	}
	got, err := svc.Get(ctx, acc.ID)
	if err != nil || got.ID != acc.ID {
		t.Fatalf("get: %+v err=%v", got, err)
	}
}

func TestCreditDebit(t *testing.T) {
	svc := newSvc()
	ctx := context.Background()
	acc, _ := svc.Create(ctx, account.CreateRequest{Holder: "alice", Type: account.TypeWallet, Currency: "INR"})
	if _, err := svc.Credit(ctx, acc.ID, 1000); err != nil {
		t.Fatalf("credit: %v", err)
	}
	after, err := svc.Debit(ctx, acc.ID, 400)
	if err != nil {
		t.Fatalf("debit: %v", err)
	}
	if after.BalanceMinor != 600 {
		t.Fatalf("want balance 600, got %d", after.BalanceMinor)
	}
}

func TestInsufficientFunds(t *testing.T) {
	svc := newSvc()
	ctx := context.Background()
	acc, _ := svc.Create(ctx, account.CreateRequest{Holder: "alice", Type: account.TypeWallet, Currency: "INR"})
	if _, err := svc.Debit(ctx, acc.ID, 100); account.CodeOf(err) != account.CodeUnprocessable {
		t.Fatalf("want unprocessable on insufficient funds, got %v", err)
	}
}

func TestFrozenBlocksMovement(t *testing.T) {
	svc := newSvc()
	ctx := context.Background()
	acc, _ := svc.Create(ctx, account.CreateRequest{Holder: "alice", Type: account.TypeWallet, Currency: "INR", OpeningBalanceMinor: 1000})
	if _, err := svc.SetStatus(ctx, acc.ID, account.StatusFrozen); err != nil {
		t.Fatalf("freeze: %v", err)
	}
	if _, err := svc.Debit(ctx, acc.ID, 100); account.CodeOf(err) != account.CodeUnprocessable {
		t.Fatalf("want unprocessable when frozen, got %v", err)
	}
}

func TestCloseRequiresZeroBalance(t *testing.T) {
	svc := newSvc()
	ctx := context.Background()
	acc, _ := svc.Create(ctx, account.CreateRequest{Holder: "alice", Type: account.TypeWallet, Currency: "INR", OpeningBalanceMinor: 500})
	if _, err := svc.SetStatus(ctx, acc.ID, account.StatusClosed); account.CodeOf(err) != account.CodeUnprocessable {
		t.Fatalf("want unprocessable closing non-zero balance, got %v", err)
	}
}

func TestCreateValidation(t *testing.T) {
	svc := newSvc()
	ctx := context.Background()
	if _, err := svc.Create(ctx, account.CreateRequest{Type: account.TypeWallet, Currency: "INR"}); account.CodeOf(err) != account.CodeValidation {
		t.Fatalf("want validation for missing holder, got %v", err)
	}
	if _, err := svc.Create(ctx, account.CreateRequest{Holder: "a", Type: "BAD", Currency: "INR"}); account.CodeOf(err) != account.CodeValidation {
		t.Fatalf("want validation for bad type, got %v", err)
	}
}
