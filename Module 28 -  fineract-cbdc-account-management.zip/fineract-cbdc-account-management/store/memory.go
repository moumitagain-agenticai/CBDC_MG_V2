// Package store provides concrete account.Store implementations: an in-memory
// store and a PostgreSQL store (using lib/pq). The Store interface itself is
// defined in the account package.
package store

import (
	"context"
	"sort"
	"sync"

	account "github.com/fineract/cbdc/account-management"
)

// Memory is an in-memory account.Store.
type Memory struct {
	mu   sync.Mutex
	data map[string]*account.Account
}

var _ account.Store = (*Memory)(nil)

// NewMemory returns a ready in-memory store.
func NewMemory() *Memory { return &Memory{data: make(map[string]*account.Account)} }

func clone(a *account.Account) *account.Account {
	cp := *a
	return &cp
}

// Create stores a new account, rejecting a duplicate id.
func (s *Memory) Create(_ context.Context, a *account.Account) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.data[a.ID]; ok {
		return account.ErrConflict("account already exists: " + a.ID)
	}
	s.data[a.ID] = clone(a)
	return nil
}

// Get returns an account by id.
func (s *Memory) Get(_ context.Context, id string) (*account.Account, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	a, ok := s.data[id]
	if !ok {
		return nil, account.ErrNotFound("account not found: " + id)
	}
	return clone(a), nil
}

// Update persists a mutated account.
func (s *Memory) Update(_ context.Context, a *account.Account) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.data[a.ID]; !ok {
		return account.ErrNotFound("account not found: " + a.ID)
	}
	s.data[a.ID] = clone(a)
	return nil
}

// ListByHolder returns accounts for a holder (all if holder is empty).
func (s *Memory) ListByHolder(_ context.Context, holder string) ([]account.Account, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []account.Account
	for _, a := range s.data {
		if holder == "" || a.Holder == holder {
			out = append(out, *clone(a))
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].CreatedAt.Before(out[j].CreatedAt) })
	return out, nil
}

// Ping is always healthy.
func (s *Memory) Ping(_ context.Context) error { return nil }
