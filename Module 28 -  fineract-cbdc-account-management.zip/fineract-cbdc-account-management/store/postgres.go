package store

import (
	"context"
	"database/sql"
	"errors"

	account "github.com/fineract/cbdc/account-management"
	_ "github.com/lib/pq"
)

// Postgres is a PostgreSQL-backed account.Store.
type Postgres struct{ db *sql.DB }

var _ account.Store = (*Postgres)(nil)

// NewPostgres wraps an existing *sql.DB.
func NewPostgres(db *sql.DB) *Postgres { return &Postgres{db: db} }

// Open opens a PostgreSQL database from a DSN.
func Open(dsn string) (*sql.DB, error) { return sql.Open("postgres", dsn) }

const schema = `
CREATE TABLE IF NOT EXISTS accounts (
    id            TEXT PRIMARY KEY,
    holder        TEXT NOT NULL,
    type          TEXT NOT NULL,
    currency      TEXT NOT NULL,
    status        TEXT NOT NULL,
    balance_minor BIGINT NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ NOT NULL,
    updated_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_accounts_holder ON accounts (holder);
`

// Migrate creates the accounts table if it does not exist.
func (s *Postgres) Migrate(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, schema)
	return err
}

// Create stores a new account, rejecting a duplicate id.
func (s *Postgres) Create(ctx context.Context, a *account.Account) error {
	_, err := s.db.ExecContext(ctx,
		`INSERT INTO accounts (id, holder, type, currency, status, balance_minor, created_at, updated_at)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
		a.ID, a.Holder, a.Type, a.Currency, a.Status, a.BalanceMinor, a.CreatedAt, a.UpdatedAt)
	if err != nil {
		return account.ErrConflict("insert account failed (possibly duplicate id): " + a.ID)
	}
	return nil
}

// Get returns an account by id.
func (s *Postgres) Get(ctx context.Context, id string) (*account.Account, error) {
	var a account.Account
	err := s.db.QueryRowContext(ctx,
		`SELECT id, holder, type, currency, status, balance_minor, created_at, updated_at
		 FROM accounts WHERE id=$1`, id).
		Scan(&a.ID, &a.Holder, &a.Type, &a.Currency, &a.Status, &a.BalanceMinor, &a.CreatedAt, &a.UpdatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, account.ErrNotFound("account not found: " + id)
	}
	if err != nil {
		return nil, account.ErrInternal("query account", err)
	}
	return &a, nil
}

// Update persists a mutated account.
func (s *Postgres) Update(ctx context.Context, a *account.Account) error {
	res, err := s.db.ExecContext(ctx,
		`UPDATE accounts SET holder=$2, type=$3, currency=$4, status=$5, balance_minor=$6, updated_at=$7 WHERE id=$1`,
		a.ID, a.Holder, a.Type, a.Currency, a.Status, a.BalanceMinor, a.UpdatedAt)
	if err != nil {
		return account.ErrInternal("update account", err)
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return account.ErrNotFound("account not found: " + a.ID)
	}
	return nil
}

// ListByHolder returns accounts for a holder (all if holder is empty).
func (s *Postgres) ListByHolder(ctx context.Context, holder string) ([]account.Account, error) {
	var (
		rows *sql.Rows
		err  error
	)
	if holder == "" {
		rows, err = s.db.QueryContext(ctx,
			`SELECT id, holder, type, currency, status, balance_minor, created_at, updated_at FROM accounts ORDER BY created_at`)
	} else {
		rows, err = s.db.QueryContext(ctx,
			`SELECT id, holder, type, currency, status, balance_minor, created_at, updated_at FROM accounts WHERE holder=$1 ORDER BY created_at`, holder)
	}
	if err != nil {
		return nil, account.ErrInternal("list accounts", err)
	}
	defer rows.Close()
	var out []account.Account
	for rows.Next() {
		var a account.Account
		if err := rows.Scan(&a.ID, &a.Holder, &a.Type, &a.Currency, &a.Status, &a.BalanceMinor, &a.CreatedAt, &a.UpdatedAt); err != nil {
			return nil, account.ErrInternal("scan account", err)
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

// Ping checks database health.
func (s *Postgres) Ping(ctx context.Context) error { return s.db.PingContext(ctx) }
