package store_test

import (
	"context"
	"os"
	"testing"

	account "github.com/fineract/cbdc/account-management"
	"github.com/fineract/cbdc/account-management/store"
)

func TestPostgresCRUD(t *testing.T) {
	dsn := os.Getenv("DATABASE_DSN")
	if dsn == "" {
		t.Skip("DATABASE_DSN not set")
	}
	db, err := store.Open(dsn)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer db.Close()
	pg := store.NewPostgres(db)
	ctx := context.Background()
	if err := pg.Migrate(ctx); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	svc := account.NewService(pg)
	acc, err := svc.Create(ctx, account.CreateRequest{Holder: "itest", Type: account.TypeWallet, Currency: "INR"})
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if _, err := svc.Credit(ctx, acc.ID, 500); err != nil {
		t.Fatalf("credit: %v", err)
	}
	got, _ := svc.Get(ctx, acc.ID)
	if got.BalanceMinor != 500 {
		t.Fatalf("want 500, got %d", got.BalanceMinor)
	}
}
