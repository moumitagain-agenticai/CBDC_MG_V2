-- fineract-cbdc-account-management: accounts table.
CREATE TABLE IF NOT EXISTS accounts (
    id            TEXT PRIMARY KEY,
    holder        TEXT NOT NULL,
    type          TEXT NOT NULL,
    currency      TEXT NOT NULL,
    status        TEXT NOT NULL,
    balance_minor BIGINT NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ NOT NULL,
    updated_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_accounts_holder ON accounts (holder);
