# fineract-openfinance-connector

Module 9 of the E1 Cross-Border CBDC platform. It is a **multi-scheme
open-banking connector** for **bank account linking**. Where Module 8 spoke only
to AlTareq (UAE), this connector links accounts across **two schemes behind one
API**:

- **AlTareq** — UAE Open Finance
- **PSD2** — EU open banking (Berlin Group-style)

The platform-level flow is identical for both — create a consent, complete
linking after authorization, then list accounts, read balances, unlink — while
each scheme's wire format, authorization/SCA redirect and currency (AED / EUR)
are handled by a dedicated provider adapter underneath.

## Security first

Linking produces an **access token** at the provider. That token stays **inside
the provider adapter**, cached per consent — never returned to callers, never
logged, never written to the database. Only a **masked IBAN** (last four
characters) is retained, e.g. `*******************3456`.

## One API, many schemes

Each request names its scheme; everything after that is routed automatically
(the scheme is remembered on the consent and on each linked account, so balance
and unlink don't need it again).

```
GET  /api/v1/schemes                          -> which schemes are enabled
POST /api/v1/consents {scheme, customer_ref}  -> consent_id + authorization_url
POST /api/v1/consents/{id}/link               -> linked accounts (masked IBANs)
GET  /api/v1/accounts?customer_ref=...          -> list linked accounts
GET  /api/v1/accounts/{linkage_id}/balance      -> balance
DELETE /api/v1/accounts/{linkage_id}             -> unlink (revoke consent)
```

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/v1/schemes` | List enabled schemes (`altareq`, `psd2`) |
| POST | `/api/v1/consents` | Create a consent under a scheme |
| GET | `/api/v1/consents/{consent_id}` | Consent status |
| POST | `/api/v1/consents/{consent_id}/link` | Complete linking |
| GET | `/api/v1/accounts?customer_ref=...` | List linked accounts (masked) |
| GET | `/api/v1/accounts/{linkage_id}/balance` | Account balance |
| DELETE | `/api/v1/accounts/{linkage_id}` | Unlink / revoke consent |
| GET | `/healthz` / `/readyz` | Liveness / readiness (readiness pings every enabled provider) |
| GET | `/metrics` | Prometheus metrics |

## How the schemes differ (and why you don't have to care)

| | AlTareq (UAE) | PSD2 (EU) |
|--|--|--|
| Consent field | `consent_id` | `consentId` |
| Authorize | `authorization_url` | `scaRedirect` (SCA) |
| Account id | `account_id` | `resourceId` |
| Balance shape | single object | `balances[]` array |
| Currency | AED | EUR |

Each provider adapter maps its own wire shapes onto one scheme-neutral port, so
the service, API and storage never branch on scheme.

## Architecture

Hexagonal (ports & adapters):

```
cmd/server            entrypoint: builds enabled providers, DI wiring, shutdown
internal/domain       scheme, consent, linked-account, balance types + validation
internal/ports        interfaces (OpenBankingProvider, LinkRepository)
internal/service      linking: provider registry + scheme routing
internal/adapters/
  api                 chi router, handlers (body size limits), middleware
  client              caller (shared retry + breaker + auth) +
                      altareq_provider + psd2_provider (per-consent token caches)
  repository          in-memory + PostgreSQL LinkRepository, migration runner
internal/config       per-provider YAML + env config, validated fail-fast
pkg/logger            zap structured logging (never logs tokens)
pkg/metrics           Prometheus metrics on a private registry
pkg/utils             IBAN (mod-97) validation, IBAN masking
```

The HTTP engine (retry-with-backoff, circuit breaker, apikey/oauth2/mtls auth) is
factored into one shared `caller`; each provider embeds it and only supplies its
own endpoints and DTO mapping.

## Enabling providers

A provider turns on when it is configured. At least one must be enabled or the
service refuses to start. Enable a provider by setting its `*_BASE_URL` (env) or
`enabled: true` (YAML), plus the credentials its auth mode needs.

| Env prefix | Scheme |
|-----------|--------|
| `ALTAREQ_*` | AlTareq (UAE) |
| `PSD2_*` | PSD2 (EU) |

Common keys per provider: `_BASE_URL`, `_AUTH_MODE` (`apikey`\|`oauth2`\|`mtls`),
`_API_KEY`, `_OAUTH_TOKEN_URL`/`_CLIENT_ID`/`_CLIENT_SECRET`, `_REDIRECT_URL`,
`_PERMISSIONS`.

## Storage: works out of the box

- **No database configured** → an **in-memory** store is used automatically (full
  flow works immediately; not durable across restarts).
- **`DATABASE_DSN` set** → **PostgreSQL**; migrations run on startup.

## Quick start

```bash
cp .env.example .env    # configure ALTAREQ_* and/or PSD2_*
make run

curl localhost:8080/api/v1/schemes
curl -X POST localhost:8080/api/v1/consents -H 'Content-Type: application/json' \
  -d '{"scheme":"psd2","customer_ref":"CUST-1"}'
```

## Database migrations

When `DATABASE_DSN` is set the connector **runs pending migrations on startup**
(tracked in `schema_migrations`). Migrations are defined in Go
(`internal/adapters/repository/migration.go`); `migrations/001_init.sql` is a
reference. Roll back with `go run ./cmd/server -rollback 1`.

## Building `go.sum`

The repository ships a clean `go.mod` without a `go.sum`; run `go mod tidy`
(or `make deps`) once with network access to generate it.

## Per-source-file logging (Logrus)

In addition to the primary structured logger (zap, used for console/DI logging),
this module ships a **Logrus** per-source-file logger in `pkg/flog`. Every source
file writes its own log file under `logs/`, named `9_<file>.log`
(module number + source file name), e.g. `9_main.log`,
`9_config.log`. Each file registers itself with the logger, and a
Logrus hook routes entries to the matching file (JSON formatted). The `logs/`
directory is created on startup and is git-ignored. `go.sum` for the added
`github.com/sirupsen/logrus` dependency is generated on first `go mod tidy`.
