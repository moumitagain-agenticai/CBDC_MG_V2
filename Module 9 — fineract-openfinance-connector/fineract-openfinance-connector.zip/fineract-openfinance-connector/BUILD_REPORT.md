# BUILD REPORT — fineract-openfinance-connector

## Summary

Multi-scheme open-banking connector for **account linking** across **AlTareq
(UAE Open Finance)** and **PSD2 (EU / Berlin Group)** behind one API. It follows
the same production convention as the other modules (hexagonal layout, resilient
upstream client with retry + circuit breaker, Go migration runner, Prometheus
metrics, graceful shutdown) and adds a scheme-provider registry with a shared
HTTP engine.

## Verification

| Check | Command | Result |
|-------|---------|--------|
| Build | `go build ./...` | PASS (exit 0) |
| Vet | `go vet ./...` | PASS (exit 0) |
| Unit tests | `go test ./...` | PASS (service routing/both schemes + utils) |
| Integration | `go test -tags integration ./test/integration/...` | PASS |
| Binary | `go build -o bin/openfinance-connector ./cmd/server` | PASS (~16 MB) |
| Formatting | `gofmt -l .` | clean (no files) |

## Runtime evidence

- **Integration test `TestFullFlow_BothSchemes`** stands up a fake AlTareq and a
  fake PSD2 server, registers both providers, and drives the full flow over real
  HTTP **for each scheme**: `/api/v1/schemes` lists both; consent creation returns
  a scheme-tagged consent with an authorization/SCA URL; linking returns accounts
  with a **masked IBAN** (AlTareq `…3456`, PSD2 `…3000`; raw digits absent); the
  balance reads (`500.00 AED` / `250.00 EUR`); after unlink, a balance read
  returns `409 Conflict`. An unknown scheme returns `400`.
- **Unit routing test** confirms a PSD2-linked account's balance is served by the
  PSD2 provider, not AlTareq — proving scheme routing by stored scheme.

## Security posture

- Provider access tokens are cached **inside each adapter**, keyed by consent;
  never returned to the service, logged, or persisted; discarded on unlink.
- Only masked IBANs are stored (`utils.MaskIBAN`, last four characters).
- Request bodies are size-limited and reject unknown fields.

## Design & resilience

- One shared `caller` provides retry-with-backoff (`go-retryablehttp`), circuit
  breaker (`gobreaker`) and app auth (apikey/oauth2/mtls); each provider embeds it.
- Scheme is remembered on the consent and each linked account, so balance/unlink
  route automatically.
- IBANs validated with the ISO 13616 mod-97 checksum; balances only for `ACTIVE`
  links.

## Notes

- The repository ships a clean `go.mod` with no `go.sum`; `go mod tidy` (or
  `make deps`) generates `go.sum` on first run with network access.
- At least one provider must be enabled; enabling is by setting a provider's
  `*_BASE_URL` (env) or `enabled: true` (YAML).
- Storage is always available: in-memory when no `DATABASE_DSN` (not durable),
  PostgreSQL when set.
- Nothing here is pushed to any Git remote; the module is self-contained.
