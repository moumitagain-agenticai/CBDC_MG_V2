# EXPLANATION — fineract-openfinance-connector (plain language)

This document explains the module in simple terms, for reviewers who are not Go
engineers.

## What is this module for?

Different regions have different "open banking" systems — national rules that let
a customer safely allow a service to see their bank account. The UAE has
**AlTareq**; the EU has **PSD2**. Module 8 handled just the UAE. **This module
handles both at once, through a single API.** Its job is **account linking**:
with the customer's permission, connect their bank account (in the UAE *or* the
EU) so the platform can see the account and its balance.

## One front door, two systems behind it

From the outside, linking always looks the same:

1. **Create a consent** — tell the connector "this customer wants to link an
   account", and say which system (`altareq` or `psd2`). You get back a link the
   customer must visit to approve.
2. **The customer approves** on their bank's screens.
3. **Finish linking** — the bank hands back a code; the connector exchanges it and
   saves the account(s), with the IBAN masked.
4. **Use it** — list the accounts, read a balance, or unlink.

Behind that single front door, the connector talks to whichever system the
consent belongs to. The two systems use different field names, different
approval-redirect styles, and different currencies (AED vs EUR) — the connector
translates all of that so the caller never has to know the difference. Once an
account is linked, the connector remembers which system it came from, so reading
a balance or unlinking "just works" without repeating the system name.

## The most important design choice: protect the access token

When linking succeeds, the bank's system gives us an **access token** — a key that
can read the account. Each system's part of the connector keeps that token
**locked inside itself**, remembered per consent. It is **never** returned to the
caller, **never** logged, and **never** stored in the database. When a balance is
needed, that inner part uses the token itself; the rest of the system never sees
it. On unlink, the token is thrown away.

We also **mask the IBAN**: only the last four characters are ever kept or shown
(for example `*******************3456`). The tests confirm the raw IBAN never
appears on a linked account.

## Built without repeating ourselves

All the "talk to a bank system safely" machinery — timeouts, automatic retries,
and a circuit breaker that backs off when a system is down — is written **once**
and shared. Each system's adapter only adds its own addresses and its own
translation of fields. That keeps the two adapters small and consistent, and
makes adding a third system later straightforward.

## Works immediately, with or without a database

Linking has to remember consents and linked accounts, so the connector always
keeps that memory: **in memory** by default (works right away, wiped on restart),
or in **PostgreSQL** when a database is configured (survives restarts).

## The features, in one line each

- **Multi-scheme**: AlTareq (UAE) and PSD2 (EU) behind one API, chosen per request.
- **Automatic routing**: the scheme is remembered, so balance/unlink need it only once.
- **Token protection**: access tokens never leave the adapter, never logged, never stored.
- **IBAN masking**: only the last four characters are ever kept or shown.
- **Shared, resilient engine**: one retry + circuit-breaker + auth layer for all schemes.
- **Safe balance reads**: only for an active link (else a clear conflict).
- **Works out of the box**: in-memory storage by default, Postgres when configured.
- **Graceful shutdown**: in-flight requests finish before exit.

## What was verified

`go build ./...`, `go vet ./...`, unit tests (enabled-schemes listing and
sorting; unknown scheme and not-enabled scheme rejected; the full
create → link → balance → unlink flow for **both** AlTareq and PSD2, asserting the
scheme and masked IBAN and the post-unlink conflict; and a routing test proving a
PSD2-linked account's balance comes from the PSD2 provider, not AlTareq) and
integration tests (the full flow for **both** schemes over real HTTP against a
fake AlTareq and a fake PSD2 server, plus the schemes listing and an unknown
scheme returning 400) all pass.
