package main

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"context"
	"errors"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"
	"go.uber.org/zap"

	"github.com/fineract/openfinance-connector/internal/adapters/api"
	"github.com/fineract/openfinance-connector/internal/adapters/client"
	"github.com/fineract/openfinance-connector/internal/adapters/repository"
	"github.com/fineract/openfinance-connector/internal/config"
	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
	"github.com/fineract/openfinance-connector/internal/service"
	"github.com/fineract/openfinance-connector/pkg/logger"
	"github.com/fineract/openfinance-connector/pkg/metrics"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "fatal:", err)
		os.Exit(1)
	}
}

func run() error {
	configPath := flag.String("config", "configs/config.yaml", "path to YAML config file")
	rollback := flag.Int("rollback", 0, "roll back the last N database migrations and exit")
	flag.Parse()

	_ = godotenv.Load()

	cfg, err := config.Load(*configPath)
	if err != nil {
		return fmt.Errorf("load config: %w", err)
	}

	log, err := logger.New(cfg.Log.Level, cfg.Log.JSON)
	if err != nil {
		return fmt.Errorf("init logger: %w", err)
	}
	defer func() { _ = log.Sync() }()

	m := metrics.New()

	// Build the enabled scheme providers.
	var providers []ports.OpenBankingProvider
	cfgs := map[domain.Scheme]config.ProviderConfig{}
	if cfg.Providers.AlTareq.Enabled {
		p, err := client.NewAlTareq(cfg.Providers.AlTareq)
		if err != nil {
			return fmt.Errorf("init altareq provider: %w", err)
		}
		providers = append(providers, p)
		cfgs[domain.SchemeAlTareq] = cfg.Providers.AlTareq
	}
	if cfg.Providers.PSD2.Enabled {
		p, err := client.NewPSD2(cfg.Providers.PSD2)
		if err != nil {
			return fmt.Errorf("init psd2 provider: %w", err)
		}
		providers = append(providers, p)
		cfgs[domain.SchemePSD2] = cfg.Providers.PSD2
	}
	for _, p := range providers {
		log.Info("scheme provider enabled", zap.String("scheme", string(p.Scheme())))
	}

	// Select the repository: durable Postgres when configured, else in-memory.
	var repo ports.LinkRepository
	if cfg.Database.Enabled {
		db, err := repository.OpenDB(cfg.Database)
		if err != nil {
			return fmt.Errorf("open database: %w", err)
		}
		defer func() { _ = db.Close() }()

		if *rollback > 0 {
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			if err := repository.Rollback(ctx, db, log, *rollback); err != nil {
				return fmt.Errorf("rollback: %w", err)
			}
			log.Info("rollback complete", zap.Int("count", *rollback))
			return nil
		}

		mctx, mcancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer mcancel()
		if err := repository.Migrate(mctx, db, log); err != nil {
			return fmt.Errorf("run migrations: %w", err)
		}
		repo = repository.New(db)
		log.Info("durable storage enabled (postgres)")
	} else {
		if *rollback > 0 {
			return fmt.Errorf("-rollback requires a database (set DATABASE_DSN)")
		}
		repo = repository.NewMemory()
		log.Warn("using in-memory storage; linked accounts are not durable across restarts")
	}

	svc := service.NewLinking(providers, cfgs, repo, m, log)
	handler := api.NewHandler(svc, 1<<20)
	router := api.NewRouter(handler, m, log, cfg.Server.RateLimitPerMin)

	srv := &http.Server{
		Addr:         fmt.Sprintf(":%d", cfg.Server.Port),
		Handler:      router,
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
	}

	serverErr := make(chan error, 1)
	go func() {
		log.Info("server listening", zap.Int("port", cfg.Server.Port))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			serverErr <- err
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)

	select {
	case err := <-serverErr:
		return fmt.Errorf("server error: %w", err)
	case sig := <-stop:
		log.Info("shutdown signal received", zap.String("signal", sig.String()))
	}

	ctx, cancel := context.WithTimeout(context.Background(), cfg.Server.ShutdownTimeout)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		return fmt.Errorf("graceful shutdown failed: %w", err)
	}
	log.Info("server stopped cleanly")
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_main_Logfile.log at runtime.
var _ = func() bool { flog.For("9_main").Info("source file initialized"); return true }()
