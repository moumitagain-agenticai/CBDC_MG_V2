//go:build integration

package integration

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/openfinance-connector/internal/adapters/api"
	"github.com/fineract/openfinance-connector/internal/adapters/client"
	"github.com/fineract/openfinance-connector/internal/adapters/repository"
	"github.com/fineract/openfinance-connector/internal/config"
	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
	"github.com/fineract/openfinance-connector/internal/service"
	"github.com/fineract/openfinance-connector/pkg/metrics"
)

const (
	uaeIBAN = "AE070331234567890123456"
	euIBAN  = "DE89370400440532013000"
)

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}

func fakeAlTareq() *httptest.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/open-finance/v1/account-access-consents", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			w.WriteHeader(200)
			return
		}
		writeJSON(w, map[string]any{"consent_id": "AT-1", "status": "AWAITING_AUTHORIZATION", "authorization_url": "https://altareq.example/auth", "expires_in": 3600})
	})
	mux.HandleFunc("/open-finance/v1/account-access-consents/", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	mux.HandleFunc("/open-finance/v1/authorizations", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"access_token": "at-tok", "accounts": []map[string]any{{"account_id": "ACC-1", "iban": uaeIBAN, "name": "Current", "type": "Current", "currency": "AED"}}})
	})
	mux.HandleFunc("/open-finance/v1/accounts/ACC-1/balances", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") == "" {
			w.WriteHeader(401)
			return
		}
		writeJSON(w, map[string]any{"account_id": "ACC-1", "amount": "500.00", "currency": "AED", "type": "available"})
	})
	mux.HandleFunc("/open-finance/v1/health", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	return httptest.NewServer(mux)
}

func fakePSD2() *httptest.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/consents", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"consentId": "PS-1", "consentStatus": "received", "scaRedirect": "https://psd2.example/sca", "expires_in": 3600})
	})
	mux.HandleFunc("/v1/consents/PS-1/token", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"access_token": "ps-tok", "accounts": []map[string]any{{"resourceId": "RES-1", "iban": euIBAN, "name": "Girokonto", "cashAccountType": "CACC", "currency": "EUR"}}})
	})
	mux.HandleFunc("/v1/consents/PS-1", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	mux.HandleFunc("/v1/accounts/RES-1/balances", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") == "" {
			w.WriteHeader(401)
			return
		}
		writeJSON(w, map[string]any{"account": map[string]any{"resourceId": "RES-1"}, "balances": []map[string]any{{"balanceAmount": map[string]any{"amount": "250.00", "currency": "EUR"}, "balanceType": "interimAvailable"}}})
	})
	mux.HandleFunc("/v1/health", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	return httptest.NewServer(mux)
}

func pcfg(url string) config.ProviderConfig {
	return config.ProviderConfig{
		Enabled: true, BaseURL: url, AuthMode: "apikey", APIKey: "k", RedirectURL: "https://tpp.example/cb",
		DefaultPermissions: domain.DefaultPermissions, ConsentTTL: time.Hour,
		Timeout: 2 * time.Second, MaxRetries: 0, BreakerMaxReq: 3, BreakerName: "test",
	}
}

func testServer(t *testing.T, atURL, psURL string) *httptest.Server {
	t.Helper()
	at, err := client.NewAlTareq(pcfg(atURL))
	require.NoError(t, err)
	ps, err := client.NewPSD2(pcfg(psURL))
	require.NoError(t, err)
	cfgs := map[domain.Scheme]config.ProviderConfig{domain.SchemeAlTareq: pcfg(atURL), domain.SchemePSD2: pcfg(psURL)}
	svc := service.NewLinking([]ports.OpenBankingProvider{at, ps}, cfgs, repository.NewMemory(), metrics.New(), zap.NewNop())
	return httptest.NewServer(api.NewRouter(api.NewHandler(svc, 1<<20), metrics.New(), zap.NewNop(), 0))
}

func do(t *testing.T, method, url, body string) (int, map[string]any) {
	t.Helper()
	var r io.Reader
	if body != "" {
		r = bytes.NewReader([]byte(body))
	}
	req, _ := http.NewRequest(method, url, r)
	if body != "" {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := http.DefaultClient.Do(req)
	require.NoError(t, err)
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	var m map[string]any
	_ = json.Unmarshal(b, &m)
	return resp.StatusCode, m
}

func flow(t *testing.T, srvURL, scheme, consentID, wantSuffix, wantAmount string) {
	t.Helper()
	code, res := do(t, http.MethodPost, srvURL+"/api/v1/consents", `{"scheme":"`+scheme+`","customer_ref":"CUST-1"}`)
	require.Equal(t, http.StatusCreated, code)
	assert.Equal(t, consentID, res["consent_id"])
	assert.Equal(t, scheme, res["scheme"])

	code, res = do(t, http.MethodPost, srvURL+"/api/v1/consents/"+consentID+"/link", `{"authorization_code":"code"}`)
	require.Equal(t, http.StatusOK, code)
	accounts := res["linked_accounts"].([]any)
	require.Len(t, accounts, 1)
	first := accounts[0].(map[string]any)
	assert.Equal(t, scheme, first["scheme"])
	assert.True(t, strings.HasSuffix(first["masked_iban"].(string), wantSuffix))
	linkage := first["linkage_id"].(string)

	code, res = do(t, http.MethodGet, srvURL+"/api/v1/accounts/"+linkage+"/balance", "")
	require.Equal(t, http.StatusOK, code)
	assert.Equal(t, wantAmount, res["amount"])

	code, _ = do(t, http.MethodDelete, srvURL+"/api/v1/accounts/"+linkage, "")
	require.Equal(t, http.StatusOK, code)

	code, _ = do(t, http.MethodGet, srvURL+"/api/v1/accounts/"+linkage+"/balance", "")
	assert.Equal(t, http.StatusConflict, code)
}

func TestFullFlow_BothSchemes(t *testing.T) {
	at := fakeAlTareq()
	defer at.Close()
	ps := fakePSD2()
	defer ps.Close()
	srv := testServer(t, at.URL, ps.URL)
	defer srv.Close()

	// schemes endpoint lists both
	code, res := do(t, http.MethodGet, srv.URL+"/api/v1/schemes", "")
	require.Equal(t, http.StatusOK, code)
	assert.Len(t, res["schemes"].([]any), 2)

	flow(t, srv.URL, "altareq", "AT-1", "3456", "500.00")
	flow(t, srv.URL, "psd2", "PS-1", "3000", "250.00")
}

func TestCreateConsent_UnknownScheme(t *testing.T) {
	at := fakeAlTareq()
	defer at.Close()
	ps := fakePSD2()
	defer ps.Close()
	srv := testServer(t, at.URL, ps.URL)
	defer srv.Close()

	code, _ := do(t, http.MethodPost, srv.URL+"/api/v1/consents", `{"scheme":"swift","customer_ref":"C"}`)
	assert.Equal(t, http.StatusBadRequest, code)
}
