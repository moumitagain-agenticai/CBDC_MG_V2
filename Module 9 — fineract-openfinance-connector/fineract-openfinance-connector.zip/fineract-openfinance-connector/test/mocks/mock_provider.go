package mocks

import (
	"context"

	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
)

// MockProvider is a configurable test double for ports.OpenBankingProvider.
type MockProvider struct {
	SchemeVal    domain.Scheme
	ConsentResp  ports.ConsentResponse
	ConsentErr   error
	AccountsResp ports.AccountsResponse
	ExchangeErr  error
	BalanceResp  ports.BalanceResponse
	BalanceErr   error
	RevokeErr    error
	HealthErr    error

	Revoked []string
}

var _ ports.OpenBankingProvider = (*MockProvider)(nil)

func (m *MockProvider) Scheme() domain.Scheme { return m.SchemeVal }

func (m *MockProvider) CreateConsent(_ context.Context, _ ports.CreateConsentRequest) (ports.ConsentResponse, error) {
	return m.ConsentResp, m.ConsentErr
}
func (m *MockProvider) ExchangeAuthorization(_ context.Context, _ string, _ string) (ports.AccountsResponse, error) {
	return m.AccountsResp, m.ExchangeErr
}
func (m *MockProvider) GetBalance(_ context.Context, _ string, _ string) (ports.BalanceResponse, error) {
	return m.BalanceResp, m.BalanceErr
}
func (m *MockProvider) RevokeConsent(_ context.Context, consentID string) error {
	m.Revoked = append(m.Revoked, consentID)
	return m.RevokeErr
}
func (m *MockProvider) Health(_ context.Context) error { return m.HealthErr }
