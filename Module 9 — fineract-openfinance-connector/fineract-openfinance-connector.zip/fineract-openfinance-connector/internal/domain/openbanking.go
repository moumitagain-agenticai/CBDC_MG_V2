package domain

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"time"

	"github.com/fineract/openfinance-connector/pkg/utils"
)

// Scheme identifies an open-banking framework.
type Scheme string

const (
	SchemeAlTareq Scheme = "altareq" // UAE Open Finance
	SchemePSD2    Scheme = "psd2"    // EU PSD2 / Berlin Group
)

// KnownSchemes lists the schemes this connector understands.
var KnownSchemes = []Scheme{SchemeAlTareq, SchemePSD2}

// IsKnownScheme reports whether s is a recognised scheme.
func IsKnownScheme(s Scheme) bool {
	for _, k := range KnownSchemes {
		if s == k {
			return true
		}
	}
	return false
}

// DefaultCurrency returns the settlement currency typically used by a scheme.
func (s Scheme) DefaultCurrency() string {
	switch s {
	case SchemeAlTareq:
		return "AED"
	case SchemePSD2:
		return "EUR"
	default:
		return ""
	}
}

// DefaultPermissions is the minimal permission set for account linking.
var DefaultPermissions = []string{"ReadAccountsBasic", "ReadBalances"}

// ConsentStatus is the lifecycle of an account-access consent.
type ConsentStatus string

const (
	ConsentAwaitingAuthorization ConsentStatus = "AWAITING_AUTHORIZATION"
	ConsentAuthorized            ConsentStatus = "AUTHORIZED"
	ConsentRejected              ConsentStatus = "REJECTED"
	ConsentRevoked               ConsentStatus = "REVOKED"
)

// LinkStatus is the lifecycle of a linked account.
type LinkStatus string

const (
	LinkActive   LinkStatus = "ACTIVE"
	LinkUnlinked LinkStatus = "UNLINKED"
)

// Consent is an account-access consent under a given scheme.
type Consent struct {
	ConsentID        string        `json:"consent_id"`
	Scheme           Scheme        `json:"scheme"`
	CustomerRef      string        `json:"customer_ref"`
	Permissions      []string      `json:"permissions"`
	Status           ConsentStatus `json:"status"`
	AuthorizationURL string        `json:"authorization_url,omitempty"`
	CreatedAt        time.Time     `json:"created_at"`
	ExpiresAt        time.Time     `json:"expires_at,omitempty"`
}

// LinkedAccount is a customer bank account linked via a consent. Only a masked
// IBAN is retained.
type LinkedAccount struct {
	LinkageID   string     `json:"linkage_id"`
	ConsentID   string     `json:"consent_id"`
	Scheme      Scheme     `json:"scheme"`
	CustomerRef string     `json:"customer_ref"`
	AccountID   string     `json:"account_id"`
	AccountName string     `json:"account_name"`
	MaskedIBAN  string     `json:"masked_iban"`
	AccountType string     `json:"account_type"`
	Currency    string     `json:"currency"`
	Status      LinkStatus `json:"status"`
	LinkedAt    time.Time  `json:"linked_at"`
}

// Balance is a point-in-time balance for a linked account.
type Balance struct {
	LinkageID string    `json:"linkage_id"`
	Amount    string    `json:"amount"`
	Currency  string    `json:"currency"`
	Type      string    `json:"type,omitempty"`
	AsOf      time.Time `json:"as_of"`
}

// CreateConsentRequest starts an account-linking flow under a scheme.
type CreateConsentRequest struct {
	Scheme      Scheme   `json:"scheme"`
	CustomerRef string   `json:"customer_ref"`
	Permissions []string `json:"permissions,omitempty"`
}

// Validate checks the consent request.
func (r CreateConsentRequest) Validate() error {
	if r.CustomerRef == "" {
		return NewValidationError("customer_ref is required", nil)
	}
	if !IsKnownScheme(r.Scheme) {
		return NewValidationError("scheme must be one of: altareq, psd2", nil)
	}
	return nil
}

// CompleteLinkRequest finishes linking after the customer authorizes the consent.
type CompleteLinkRequest struct {
	ConsentID         string `json:"consent_id"`
	AuthorizationCode string `json:"authorization_code"`
}

// Validate checks the completion request.
func (r CompleteLinkRequest) Validate() error {
	if r.ConsentID == "" {
		return NewValidationError("consent_id is required", nil)
	}
	if r.AuthorizationCode == "" {
		return NewValidationError("authorization_code is required", nil)
	}
	return nil
}

// NewLinkedAccount builds a linked-account record from provider account data,
// masking the IBAN. It validates the IBAN and currency defensively.
func NewLinkedAccount(linkageID, consentID string, scheme Scheme, customerRef, accountID, name, iban, acctType, currency string, now time.Time) (*LinkedAccount, error) {
	if iban != "" && !utils.IsValidIBAN(iban) {
		return nil, NewUpstreamError("provider returned an invalid IBAN", nil)
	}
	if currency == "" {
		currency = scheme.DefaultCurrency()
	}
	if !utils.IsValidCurrency(currency) {
		return nil, NewUpstreamError("provider returned an invalid currency", nil)
	}
	return &LinkedAccount{
		LinkageID: linkageID, ConsentID: consentID, Scheme: scheme, CustomerRef: customerRef,
		AccountID: accountID, AccountName: name, MaskedIBAN: utils.MaskIBAN(iban),
		AccountType: acctType, Currency: currency, Status: LinkActive, LinkedAt: now,
	}, nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_openbanking_Logfile.log at runtime.
var _ = func() bool { flog.For("9_openbanking").Info("source file initialized"); return true }()
