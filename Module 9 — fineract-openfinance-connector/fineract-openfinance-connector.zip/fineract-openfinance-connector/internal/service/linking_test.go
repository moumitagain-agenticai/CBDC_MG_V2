package service_test

import (
	"context"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/openfinance-connector/internal/adapters/repository"
	"github.com/fineract/openfinance-connector/internal/config"
	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
	"github.com/fineract/openfinance-connector/internal/service"
	"github.com/fineract/openfinance-connector/pkg/metrics"
	"github.com/fineract/openfinance-connector/test/mocks"
)

const (
	uaeIBAN = "AE070331234567890123456"
	euIBAN  = "DE89370400440532013000"
)

func buildSvc(providers ...ports.OpenBankingProvider) (*service.Linking, *repository.MemoryRepository) {
	repo := repository.NewMemory()
	cfgs := map[domain.Scheme]config.ProviderConfig{
		domain.SchemeAlTareq: {ConsentTTL: time.Hour, DefaultPermissions: domain.DefaultPermissions},
		domain.SchemePSD2:    {ConsentTTL: time.Hour, DefaultPermissions: domain.DefaultPermissions},
	}
	return service.NewLinking(providers, cfgs, repo, metrics.New(), zap.NewNop()), repo
}

func TestEnabledSchemes(t *testing.T) {
	svc, _ := buildSvc(
		&mocks.MockProvider{SchemeVal: domain.SchemePSD2},
		&mocks.MockProvider{SchemeVal: domain.SchemeAlTareq},
	)
	got := svc.EnabledSchemes()
	require.Len(t, got, 2)
	assert.Equal(t, domain.SchemeAlTareq, got[0]) // sorted
	assert.Equal(t, domain.SchemePSD2, got[1])
}

func TestCreateConsent_UnknownScheme(t *testing.T) {
	svc, _ := buildSvc(&mocks.MockProvider{SchemeVal: domain.SchemeAlTareq})
	_, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{Scheme: "swift", CustomerRef: "C"})
	require.Error(t, err)
	assert.Equal(t, domain.CodeValidation, domain.AsDomainError(err).Code)
}

func TestCreateConsent_SchemeNotEnabled(t *testing.T) {
	// Only AlTareq registered; requesting PSD2 must fail.
	svc, _ := buildSvc(&mocks.MockProvider{SchemeVal: domain.SchemeAlTareq})
	_, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{Scheme: domain.SchemePSD2, CustomerRef: "C"})
	require.Error(t, err)
	assert.Equal(t, domain.CodeValidation, domain.AsDomainError(err).Code)
}

// runFlow exercises the full create->link->balance->unlink flow for a scheme.
func runFlow(t *testing.T, scheme domain.Scheme, iban, wantCurrency string) {
	t.Helper()
	prov := &mocks.MockProvider{
		SchemeVal:    scheme,
		ConsentResp:  ports.ConsentResponse{ConsentID: "CONSENT-1", AuthorizationURL: "https://auth.example/x"},
		AccountsResp: ports.AccountsResponse{Accounts: []ports.AccountDTO{{AccountID: "ACC-1", IBAN: iban, Name: "Main", Type: "Current", Currency: wantCurrency}}},
		BalanceResp:  ports.BalanceResponse{AccountID: "ACC-1", Amount: "1000.00", Currency: wantCurrency, Type: "available"},
	}
	svc, _ := buildSvc(prov)

	c, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{Scheme: scheme, CustomerRef: "CUST-1"})
	require.NoError(t, err)
	assert.Equal(t, scheme, c.Scheme)
	assert.NotEmpty(t, c.AuthorizationURL)

	accts, err := svc.CompleteLinking(context.Background(), domain.CompleteLinkRequest{ConsentID: "CONSENT-1", AuthorizationCode: "code"})
	require.NoError(t, err)
	require.Len(t, accts, 1)
	assert.Equal(t, scheme, accts[0].Scheme)
	assert.True(t, strings.HasSuffix(accts[0].MaskedIBAN, iban[len(iban)-4:]))
	assert.NotContains(t, accts[0].MaskedIBAN, iban[:len(iban)-4])
	linkage := accts[0].LinkageID

	bal, err := svc.GetBalance(context.Background(), linkage)
	require.NoError(t, err)
	assert.Equal(t, "1000.00", bal.Amount)
	assert.Equal(t, wantCurrency, bal.Currency)

	require.NoError(t, svc.Unlink(context.Background(), linkage))
	assert.Contains(t, prov.Revoked, "CONSENT-1")

	_, err = svc.GetBalance(context.Background(), linkage)
	require.Error(t, err)
	assert.Equal(t, domain.CodeConflict, domain.AsDomainError(err).Code)
}

func TestFullFlow_AlTareq(t *testing.T) { runFlow(t, domain.SchemeAlTareq, uaeIBAN, "AED") }
func TestFullFlow_PSD2(t *testing.T)    { runFlow(t, domain.SchemePSD2, euIBAN, "EUR") }

func TestRouting_BalanceUsesAccountScheme(t *testing.T) {
	// Two providers; a PSD2-linked account must route balance to the PSD2 provider.
	altareq := &mocks.MockProvider{SchemeVal: domain.SchemeAlTareq, BalanceResp: ports.BalanceResponse{Amount: "1", Currency: "AED"}}
	psd2 := &mocks.MockProvider{
		SchemeVal:    domain.SchemePSD2,
		ConsentResp:  ports.ConsentResponse{ConsentID: "C-PSD2"},
		AccountsResp: ports.AccountsResponse{Accounts: []ports.AccountDTO{{AccountID: "A", IBAN: euIBAN, Currency: "EUR"}}},
		BalanceResp:  ports.BalanceResponse{Amount: "42.00", Currency: "EUR"},
	}
	svc, _ := buildSvc(altareq, psd2)

	_, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{Scheme: domain.SchemePSD2, CustomerRef: "CUST-1"})
	require.NoError(t, err)
	accts, err := svc.CompleteLinking(context.Background(), domain.CompleteLinkRequest{ConsentID: "C-PSD2", AuthorizationCode: "x"})
	require.NoError(t, err)

	bal, err := svc.GetBalance(context.Background(), accts[0].LinkageID)
	require.NoError(t, err)
	assert.Equal(t, "42.00", bal.Amount) // came from the PSD2 provider, not AlTareq
}
