package service

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"context"
	"sort"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	"github.com/fineract/openfinance-connector/internal/config"
	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
	"github.com/fineract/openfinance-connector/pkg/metrics"
)

type providerEntry struct {
	provider    ports.OpenBankingProvider
	consentTTL  time.Duration
	permissions []string
}

// Linking orchestrates open-banking account linking across multiple schemes
// (AlTareq, PSD2). It selects a provider by scheme and stores only masked
// account data.
type Linking struct {
	providers map[domain.Scheme]providerEntry
	repo      ports.LinkRepository
	metrics   *metrics.Metrics
	log       *zap.Logger
}

// NewLinking wires the service from the enabled providers and their configs.
func NewLinking(providers []ports.OpenBankingProvider, cfgs map[domain.Scheme]config.ProviderConfig, repo ports.LinkRepository, m *metrics.Metrics, log *zap.Logger) *Linking {
	reg := make(map[domain.Scheme]providerEntry, len(providers))
	for _, p := range providers {
		cfg := cfgs[p.Scheme()]
		reg[p.Scheme()] = providerEntry{provider: p, consentTTL: cfg.ConsentTTL, permissions: cfg.DefaultPermissions}
	}
	return &Linking{providers: reg, repo: repo, metrics: m, log: log}
}

// EnabledSchemes returns the configured schemes, sorted.
func (l *Linking) EnabledSchemes() []domain.Scheme {
	out := make([]domain.Scheme, 0, len(l.providers))
	for s := range l.providers {
		out = append(out, s)
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out
}

func (l *Linking) entry(scheme domain.Scheme) (providerEntry, error) {
	e, ok := l.providers[scheme]
	if !ok {
		return providerEntry{}, domain.NewValidationError("scheme not enabled: "+string(scheme), nil)
	}
	return e, nil
}

// CreateConsent starts account linking under the requested scheme.
func (l *Linking) CreateConsent(ctx context.Context, req domain.CreateConsentRequest) (*domain.Consent, error) {
	defer l.observe("create_consent")()
	if err := req.Validate(); err != nil {
		return nil, l.fail("create_consent", err)
	}
	e, err := l.entry(req.Scheme)
	if err != nil {
		return nil, l.fail("create_consent", err)
	}
	perms := req.Permissions
	if len(perms) == 0 {
		perms = e.permissions
	}

	resp, err := e.provider.CreateConsent(ctx, ports.CreateConsentRequest{CustomerRef: req.CustomerRef, Permissions: perms})
	if err != nil {
		return nil, l.fail("create_consent", err)
	}

	now := time.Now().UTC()
	expires := now.Add(e.consentTTL)
	if resp.ExpiresInSeconds > 0 {
		expires = now.Add(time.Duration(resp.ExpiresInSeconds) * time.Second)
	}
	c := &domain.Consent{
		ConsentID: resp.ConsentID, Scheme: req.Scheme, CustomerRef: req.CustomerRef, Permissions: perms,
		Status: consentStatus(resp.Status), AuthorizationURL: resp.AuthorizationURL, CreatedAt: now, ExpiresAt: expires,
	}
	if err := l.repo.SaveConsent(ctx, c); err != nil {
		return nil, l.fail("create_consent", err)
	}
	l.metrics.OpsTotal.WithLabelValues("create_consent", string(req.Scheme)).Inc()
	return c, nil
}

// CompleteLinking exchanges the authorization code and links the accounts.
func (l *Linking) CompleteLinking(ctx context.Context, req domain.CompleteLinkRequest) ([]domain.LinkedAccount, error) {
	defer l.observe("complete_linking")()
	if err := req.Validate(); err != nil {
		return nil, l.fail("complete_linking", err)
	}
	consent, err := l.repo.GetConsent(ctx, req.ConsentID)
	if err != nil {
		return nil, l.fail("complete_linking", err)
	}
	e, err := l.entry(consent.Scheme)
	if err != nil {
		return nil, l.fail("complete_linking", err)
	}

	resp, err := e.provider.ExchangeAuthorization(ctx, req.ConsentID, req.AuthorizationCode)
	if err != nil {
		return nil, l.fail("complete_linking", err)
	}

	now := time.Now().UTC()
	linked := make([]domain.LinkedAccount, 0, len(resp.Accounts))
	for _, a := range resp.Accounts {
		acct, err := domain.NewLinkedAccount(uuid.NewString(), req.ConsentID, consent.Scheme, consent.CustomerRef, a.AccountID, a.Name, a.IBAN, a.Type, a.Currency, now)
		if err != nil {
			return nil, l.fail("complete_linking", err)
		}
		if err := l.repo.SaveLinkedAccount(ctx, acct); err != nil {
			return nil, l.fail("complete_linking", err)
		}
		linked = append(linked, *acct)
	}

	if err := l.repo.UpdateConsentStatus(ctx, req.ConsentID, domain.ConsentAuthorized); err != nil {
		l.log.Error("failed to mark consent authorized", zap.Error(err))
	}
	l.metrics.OpsTotal.WithLabelValues("complete_linking", string(consent.Scheme)).Inc()
	return linked, nil
}

// GetConsent returns a consent's current status.
func (l *Linking) GetConsent(ctx context.Context, consentID string) (*domain.Consent, error) {
	defer l.observe("get_consent")()
	c, err := l.repo.GetConsent(ctx, consentID)
	if err != nil {
		return nil, l.fail("get_consent", err)
	}
	return c, nil
}

// ListLinkedAccounts returns a customer's linked accounts (masked).
func (l *Linking) ListLinkedAccounts(ctx context.Context, customerRef string) ([]domain.LinkedAccount, error) {
	defer l.observe("list_accounts")()
	if customerRef == "" {
		return nil, l.fail("list_accounts", domain.NewValidationError("customer_ref is required", nil))
	}
	accts, err := l.repo.ListLinkedAccounts(ctx, customerRef)
	if err != nil {
		return nil, l.fail("list_accounts", err)
	}
	return accts, nil
}

// GetBalance reads a balance for a linked account.
func (l *Linking) GetBalance(ctx context.Context, linkageID string) (*domain.Balance, error) {
	defer l.observe("get_balance")()
	acct, err := l.repo.GetLinkedAccount(ctx, linkageID)
	if err != nil {
		return nil, l.fail("get_balance", err)
	}
	if acct.Status != domain.LinkActive {
		return nil, l.fail("get_balance", domain.NewConflictError("account is not active", nil))
	}
	e, err := l.entry(acct.Scheme)
	if err != nil {
		return nil, l.fail("get_balance", err)
	}

	resp, err := e.provider.GetBalance(ctx, acct.ConsentID, acct.AccountID)
	if err != nil {
		return nil, l.fail("get_balance", err)
	}
	currency := resp.Currency
	if currency == "" {
		currency = acct.Currency
	}
	l.metrics.OpsTotal.WithLabelValues("get_balance", string(acct.Scheme)).Inc()
	return &domain.Balance{LinkageID: linkageID, Amount: resp.Amount, Currency: currency, Type: resp.Type, AsOf: time.Now().UTC()}, nil
}

// Unlink revokes the consent and marks the account unlinked.
func (l *Linking) Unlink(ctx context.Context, linkageID string) error {
	defer l.observe("unlink")()
	acct, err := l.repo.GetLinkedAccount(ctx, linkageID)
	if err != nil {
		return l.fail("unlink", err)
	}
	e, err := l.entry(acct.Scheme)
	if err != nil {
		return l.fail("unlink", err)
	}
	if err := e.provider.RevokeConsent(ctx, acct.ConsentID); err != nil {
		return l.fail("unlink", err)
	}
	if err := l.repo.UpdateLinkedAccountStatus(ctx, linkageID, domain.LinkUnlinked); err != nil {
		return l.fail("unlink", err)
	}
	_ = l.repo.UpdateConsentStatus(ctx, acct.ConsentID, domain.ConsentRevoked)
	l.metrics.OpsTotal.WithLabelValues("unlink", string(acct.Scheme)).Inc()
	return nil
}

// ---- health ----

// HealthReport is the aggregated health of the connector.
type HealthReport struct {
	Status string            `json:"status"`
	Checks map[string]string `json:"checks"`
}

// Liveness reports process health with no I/O.
func (l *Linking) Liveness() HealthReport {
	return HealthReport{Status: "ok", Checks: map[string]string{"process": "ok"}}
}

// Readiness pings every provider and the repository.
func (l *Linking) Readiness(ctx context.Context) HealthReport {
	checks := map[string]string{}
	status := "ok"
	for scheme, e := range l.providers {
		if err := e.provider.Health(ctx); err != nil {
			checks[string(scheme)] = "error: " + err.Error()
			status = "degraded"
		} else {
			checks[string(scheme)] = "ok"
		}
	}
	if err := l.repo.Ping(ctx); err != nil {
		checks["repository"] = "error: " + err.Error()
		status = "degraded"
	} else {
		checks["repository"] = "ok"
	}
	return HealthReport{Status: status, Checks: checks}
}

// ---- helpers ----

func (l *Linking) observe(op string) func() {
	start := time.Now()
	return func() { l.metrics.OpDuration.WithLabelValues(op).Observe(time.Since(start).Seconds()) }
}

func (l *Linking) fail(op string, err error) error {
	de := domain.AsDomainError(err)
	l.metrics.OpErrorsTotal.WithLabelValues(op, string(de.Code)).Inc()
	l.log.Warn("open banking operation failed", zap.String("op", op), zap.String("code", string(de.Code)), zap.Error(err))
	return de
}

func consentStatus(s string) domain.ConsentStatus {
	switch domain.ConsentStatus(s) {
	case domain.ConsentAuthorized, domain.ConsentRejected, domain.ConsentRevoked:
		return domain.ConsentStatus(s)
	default:
		return domain.ConsentAwaitingAuthorization
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_linking_Logfile.log at runtime.
var _ = func() bool { flog.For("9_linking").Info("source file initialized"); return true }()
