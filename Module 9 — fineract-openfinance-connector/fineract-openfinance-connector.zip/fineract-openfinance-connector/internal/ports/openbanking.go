package ports

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"context"

	"github.com/fineract/openfinance-connector/internal/domain"
)

// OpenBankingProvider is the outbound port each open-banking scheme adapter
// implements (AlTareq, PSD2, ...). Access tokens obtained during authorization
// are held inside the adapter and never surfaced, logged or persisted.
type OpenBankingProvider interface {
	// Scheme identifies which framework this provider serves.
	Scheme() domain.Scheme
	// CreateConsent registers an account-access consent and returns the URL the
	// customer must visit to authorize it.
	CreateConsent(ctx context.Context, req CreateConsentRequest) (ConsentResponse, error)
	// ExchangeAuthorization swaps the authorization code for access, caches the
	// resulting token against the consent, and returns the accessible accounts.
	ExchangeAuthorization(ctx context.Context, consentID, authCode string) (AccountsResponse, error)
	// GetBalance reads a balance for a linked account under an authorized consent.
	GetBalance(ctx context.Context, consentID, accountID string) (BalanceResponse, error)
	// RevokeConsent withdraws an account-access consent.
	RevokeConsent(ctx context.Context, consentID string) error
	// Health reports provider reachability for readiness checks.
	Health(ctx context.Context) error
}

// CreateConsentRequest is the app-level request to register a consent.
type CreateConsentRequest struct {
	CustomerRef string
	Permissions []string
}

// ConsentResponse is a provider's reply to consent creation.
type ConsentResponse struct {
	ConsentID        string
	Status           string
	AuthorizationURL string
	ExpiresInSeconds int
}

// AccountDTO is one account returned by a provider after authorization.
type AccountDTO struct {
	AccountID string
	IBAN      string
	Name      string
	Type      string
	Currency  string
}

// AccountsResponse carries the accounts accessible under a consent.
type AccountsResponse struct {
	Accounts []AccountDTO
}

// BalanceResponse is a balance reading from a provider.
type BalanceResponse struct {
	AccountID string
	Amount    string
	Currency  string
	Type      string
}

// LinkRepository is the outbound port for durable consent + linked-account state.
type LinkRepository interface {
	SaveConsent(ctx context.Context, c *domain.Consent) error
	UpdateConsentStatus(ctx context.Context, consentID string, status domain.ConsentStatus) error
	GetConsent(ctx context.Context, consentID string) (*domain.Consent, error)

	SaveLinkedAccount(ctx context.Context, a *domain.LinkedAccount) error
	GetLinkedAccount(ctx context.Context, linkageID string) (*domain.LinkedAccount, error)
	ListLinkedAccounts(ctx context.Context, customerRef string) ([]domain.LinkedAccount, error)
	UpdateLinkedAccountStatus(ctx context.Context, linkageID string, status domain.LinkStatus) error

	Ping(ctx context.Context) error
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_openbanking_Logfile.log at runtime.
var _ = func() bool { flog.For("9_openbanking").Info("source file initialized"); return true }()
