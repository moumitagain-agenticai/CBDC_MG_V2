package config

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

// Config is the fully-resolved application configuration.
type Config struct {
	Server    ServerConfig    `yaml:"server"`
	Providers ProvidersConfig `yaml:"providers"`
	Database  DatabaseConfig  `yaml:"database"`
	Log       LogConfig       `yaml:"log"`
}

type ServerConfig struct {
	Port            int           `yaml:"port"`
	ReadTimeout     time.Duration `yaml:"read_timeout"`
	WriteTimeout    time.Duration `yaml:"write_timeout"`
	ShutdownTimeout time.Duration `yaml:"shutdown_timeout"`
	RateLimitPerMin int           `yaml:"rate_limit_per_min"`
}

// ProvidersConfig holds one block per supported open-banking scheme.
type ProvidersConfig struct {
	AlTareq ProviderConfig `yaml:"altareq"`
	PSD2    ProviderConfig `yaml:"psd2"`
}

// ProviderConfig is the connection + resilience config for one scheme adapter.
type ProviderConfig struct {
	Enabled            bool          `yaml:"enabled"`
	BaseURL            string        `yaml:"base_url"`
	AuthMode           string        `yaml:"auth_mode"` // apikey | oauth2 | mtls
	APIKey             string        `yaml:"api_key"`
	OAuthTokenURL      string        `yaml:"oauth_token_url"`
	ClientID           string        `yaml:"client_id"`
	ClientSecret       string        `yaml:"client_secret"`
	RedirectURL        string        `yaml:"redirect_url"`
	DefaultPermissions []string      `yaml:"default_permissions"`
	ConsentTTL         time.Duration `yaml:"consent_ttl"`
	Timeout            time.Duration `yaml:"timeout"`
	MaxRetries         int           `yaml:"max_retries"`
	BreakerMaxReq      uint32        `yaml:"breaker_max_requests"`
	BreakerName        string        `yaml:"breaker_name"`
}

type DatabaseConfig struct {
	DSN             string        `yaml:"dsn"`
	MaxOpenConns    int           `yaml:"max_open_conns"`
	MaxIdleConns    int           `yaml:"max_idle_conns"`
	ConnMaxLifetime time.Duration `yaml:"conn_max_lifetime"`
	Enabled         bool          `yaml:"enabled"`
}

type LogConfig struct {
	Level string `yaml:"level"`
	JSON  bool   `yaml:"json"`
}

func providerDefaults(name string) ProviderConfig {
	return ProviderConfig{
		AuthMode:           "apikey",
		DefaultPermissions: []string{"ReadAccountsBasic", "ReadBalances"},
		ConsentTTL:         24 * time.Hour,
		Timeout:            8 * time.Second,
		MaxRetries:         3,
		BreakerMaxReq:      5,
		BreakerName:        name,
	}
}

// Default returns production-sane defaults.
func Default() Config {
	return Config{
		Server: ServerConfig{
			Port:            8080,
			ReadTimeout:     10 * time.Second,
			WriteTimeout:    15 * time.Second,
			ShutdownTimeout: 20 * time.Second,
			RateLimitPerMin: 120,
		},
		Providers: ProvidersConfig{
			AlTareq: providerDefaults("altareq-open-finance"),
			PSD2:    providerDefaults("psd2-open-banking"),
		},
		Database: DatabaseConfig{
			MaxOpenConns:    25,
			MaxIdleConns:    5,
			ConnMaxLifetime: 30 * time.Minute,
			Enabled:         false,
		},
		Log: LogConfig{Level: "info", JSON: true},
	}
}

// Load reads YAML (if present), applies env overrides, then validates.
func Load(path string) (Config, error) {
	cfg := Default()
	if path != "" {
		data, err := os.ReadFile(path)
		if err == nil {
			if err := yaml.Unmarshal(data, &cfg); err != nil {
				return Config{}, fmt.Errorf("parsing config %s: %w", path, err)
			}
		} else if !os.IsNotExist(err) {
			return Config{}, fmt.Errorf("reading config %s: %w", path, err)
		}
	}
	applyEnvOverrides(&cfg)
	normalizePermissions(&cfg.Providers.AlTareq)
	normalizePermissions(&cfg.Providers.PSD2)
	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

func normalizePermissions(p *ProviderConfig) {
	if len(p.DefaultPermissions) == 0 {
		p.DefaultPermissions = []string{"ReadAccountsBasic", "ReadBalances"}
	}
}

func applyEnvOverrides(cfg *Config) {
	if v := os.Getenv("SERVER_PORT"); v != "" {
		if p, err := strconv.Atoi(v); err == nil {
			cfg.Server.Port = p
		}
	}
	applyProviderEnv(&cfg.Providers.AlTareq, "ALTAREQ")
	applyProviderEnv(&cfg.Providers.PSD2, "PSD2")

	if v := os.Getenv("DATABASE_DSN"); v != "" {
		cfg.Database.DSN = v
		cfg.Database.Enabled = true
	}
	if v := os.Getenv("LOG_LEVEL"); v != "" {
		cfg.Log.Level = v
	}
}

func applyProviderEnv(p *ProviderConfig, prefix string) {
	if v := os.Getenv(prefix + "_BASE_URL"); v != "" {
		p.BaseURL = v
		p.Enabled = true
	}
	if v := os.Getenv(prefix + "_ENABLED"); v == "true" {
		p.Enabled = true
	}
	if v := os.Getenv(prefix + "_AUTH_MODE"); v != "" {
		p.AuthMode = v
	}
	if v := os.Getenv(prefix + "_API_KEY"); v != "" {
		p.APIKey = v
	}
	if v := os.Getenv(prefix + "_OAUTH_TOKEN_URL"); v != "" {
		p.OAuthTokenURL = v
	}
	if v := os.Getenv(prefix + "_CLIENT_ID"); v != "" {
		p.ClientID = v
	}
	if v := os.Getenv(prefix + "_CLIENT_SECRET"); v != "" {
		p.ClientSecret = v
	}
	if v := os.Getenv(prefix + "_REDIRECT_URL"); v != "" {
		p.RedirectURL = v
	}
	if v := os.Getenv(prefix + "_PERMISSIONS"); v != "" {
		p.DefaultPermissions = splitCSV(v)
	}
}

func splitCSV(v string) []string {
	var out []string
	for _, p := range strings.Split(v, ",") {
		if s := strings.TrimSpace(p); s != "" {
			out = append(out, s)
		}
	}
	return out
}

// Validate fails fast on inconsistent configuration.
func (c Config) Validate() error {
	if c.Server.Port <= 0 || c.Server.Port > 65535 {
		return fmt.Errorf("invalid server port: %d", c.Server.Port)
	}
	if !c.Providers.AlTareq.Enabled && !c.Providers.PSD2.Enabled {
		return fmt.Errorf("at least one provider must be enabled (altareq and/or psd2)")
	}
	if c.Providers.AlTareq.Enabled {
		if err := c.Providers.AlTareq.validate("altareq"); err != nil {
			return err
		}
	}
	if c.Providers.PSD2.Enabled {
		if err := c.Providers.PSD2.validate("psd2"); err != nil {
			return err
		}
	}
	if c.Database.Enabled && c.Database.DSN == "" {
		return fmt.Errorf("database.dsn is required when database is enabled")
	}
	return nil
}

func (p ProviderConfig) validate(name string) error {
	if p.BaseURL == "" {
		return fmt.Errorf("providers.%s.base_url is required when enabled", name)
	}
	switch p.AuthMode {
	case "apikey":
		if p.APIKey == "" {
			return fmt.Errorf("providers.%s.api_key is required when auth_mode=apikey", name)
		}
	case "oauth2":
		if p.OAuthTokenURL == "" || p.ClientID == "" || p.ClientSecret == "" {
			return fmt.Errorf("providers.%s oauth2 auth requires oauth_token_url, client_id and client_secret", name)
		}
	case "mtls":
		// certs mounted at deploy time
	default:
		return fmt.Errorf("providers.%s unsupported auth_mode %q (want apikey|oauth2|mtls)", name, p.AuthMode)
	}
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_config_Logfile.log at runtime.
var _ = func() bool { flog.For("9_config").Info("source file initialized"); return true }()
