package repository

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"context"
	"sync"

	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
)

// MemoryRepository is a process-local LinkRepository used when no database is
// configured. It keeps the linking flow fully functional out of the box; state
// is not durable across restarts.
type MemoryRepository struct {
	mu       sync.RWMutex
	consents map[string]*domain.Consent
	accounts map[string]*domain.LinkedAccount // keyed by linkage id
}

var _ ports.LinkRepository = (*MemoryRepository)(nil)

// NewMemory builds an empty in-memory repository.
func NewMemory() *MemoryRepository {
	return &MemoryRepository{
		consents: make(map[string]*domain.Consent),
		accounts: make(map[string]*domain.LinkedAccount),
	}
}

func (r *MemoryRepository) SaveConsent(_ context.Context, c *domain.Consent) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	cp := *c
	r.consents[c.ConsentID] = &cp
	return nil
}

func (r *MemoryRepository) UpdateConsentStatus(_ context.Context, consentID string, status domain.ConsentStatus) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	c, ok := r.consents[consentID]
	if !ok {
		return domain.NewNotFoundError("consent not found", nil)
	}
	c.Status = status
	return nil
}

func (r *MemoryRepository) GetConsent(_ context.Context, consentID string) (*domain.Consent, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	c, ok := r.consents[consentID]
	if !ok {
		return nil, domain.NewNotFoundError("consent not found", nil)
	}
	cp := *c
	return &cp, nil
}

func (r *MemoryRepository) SaveLinkedAccount(_ context.Context, a *domain.LinkedAccount) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	cp := *a
	r.accounts[a.LinkageID] = &cp
	return nil
}

func (r *MemoryRepository) GetLinkedAccount(_ context.Context, linkageID string) (*domain.LinkedAccount, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	a, ok := r.accounts[linkageID]
	if !ok {
		return nil, domain.NewNotFoundError("linked account not found", nil)
	}
	cp := *a
	return &cp, nil
}

func (r *MemoryRepository) ListLinkedAccounts(_ context.Context, customerRef string) ([]domain.LinkedAccount, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	var out []domain.LinkedAccount
	for _, a := range r.accounts {
		if a.CustomerRef == customerRef {
			out = append(out, *a)
		}
	}
	return out, nil
}

func (r *MemoryRepository) UpdateLinkedAccountStatus(_ context.Context, linkageID string, status domain.LinkStatus) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	a, ok := r.accounts[linkageID]
	if !ok {
		return domain.NewNotFoundError("linked account not found", nil)
	}
	a.Status = status
	return nil
}

func (r *MemoryRepository) Ping(_ context.Context) error { return nil }

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_memory_Logfile.log at runtime.
var _ = func() bool { flog.For("9_memory").Info("source file initialized"); return true }()
