package repository

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"context"
	"database/sql"
	"errors"
	"strings"

	_ "github.com/lib/pq" // postgres driver (side-effect import)

	"github.com/fineract/openfinance-connector/internal/config"
	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
)

// Repository is a PostgreSQL-backed LinkRepository.
type Repository struct {
	db *sql.DB
}

var _ ports.LinkRepository = (*Repository)(nil)

// OpenDB opens and configures a *sql.DB from database configuration.
func OpenDB(cfg config.DatabaseConfig) (*sql.DB, error) {
	db, err := sql.Open("postgres", cfg.DSN)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(cfg.MaxOpenConns)
	db.SetMaxIdleConns(cfg.MaxIdleConns)
	db.SetConnMaxLifetime(cfg.ConnMaxLifetime)
	return db, nil
}

// New builds a Repository over an existing *sql.DB.
func New(db *sql.DB) *Repository { return &Repository{db: db} }

func (r *Repository) SaveConsent(ctx context.Context, c *domain.Consent) error {
	const q = `
INSERT INTO of_consents (consent_id, scheme, customer_ref, permissions, status, created_at, expires_at)
VALUES ($1,$2,$3,$4,$5,$6,$7)
ON CONFLICT (consent_id) DO UPDATE SET status = EXCLUDED.status`
	var expires interface{}
	if !c.ExpiresAt.IsZero() {
		expires = c.ExpiresAt
	}
	_, err := r.db.ExecContext(ctx, q, c.ConsentID, c.Scheme, c.CustomerRef, strings.Join(c.Permissions, ","), c.Status, c.CreatedAt, expires)
	if err != nil {
		return domain.NewInternalError("persist consent", err)
	}
	return nil
}

func (r *Repository) UpdateConsentStatus(ctx context.Context, consentID string, status domain.ConsentStatus) error {
	res, err := r.db.ExecContext(ctx, `UPDATE of_consents SET status=$2 WHERE consent_id=$1`, consentID, status)
	if err != nil {
		return domain.NewInternalError("update consent status", err)
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return domain.NewNotFoundError("consent not found: "+consentID, nil)
	}
	return nil
}

func (r *Repository) GetConsent(ctx context.Context, consentID string) (*domain.Consent, error) {
	const q = `SELECT consent_id, scheme, customer_ref, permissions, status, created_at, COALESCE(expires_at, 'epoch') FROM of_consents WHERE consent_id=$1`
	var c domain.Consent
	var perms string
	err := r.db.QueryRowContext(ctx, q, consentID).Scan(&c.ConsentID, &c.Scheme, &c.CustomerRef, &perms, &c.Status, &c.CreatedAt, &c.ExpiresAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, domain.NewNotFoundError("consent not found", err)
	}
	if err != nil {
		return nil, domain.NewInternalError("scan consent", err)
	}
	if perms != "" {
		c.Permissions = strings.Split(perms, ",")
	}
	return &c, nil
}

func (r *Repository) SaveLinkedAccount(ctx context.Context, a *domain.LinkedAccount) error {
	const q = `
INSERT INTO linked_accounts
  (linkage_id, consent_id, scheme, customer_ref, account_id, account_name, masked_iban, account_type, currency, status, linked_at)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
ON CONFLICT (consent_id, account_id) DO UPDATE
  SET status = EXCLUDED.status, masked_iban = EXCLUDED.masked_iban`
	_, err := r.db.ExecContext(ctx, q,
		a.LinkageID, a.ConsentID, a.Scheme, a.CustomerRef, a.AccountID, a.AccountName,
		a.MaskedIBAN, a.AccountType, a.Currency, a.Status, a.LinkedAt,
	)
	if err != nil {
		return domain.NewInternalError("persist linked account", err)
	}
	return nil
}

func (r *Repository) GetLinkedAccount(ctx context.Context, linkageID string) (*domain.LinkedAccount, error) {
	const q = selectAccounts + ` WHERE linkage_id=$1`
	return scanAccount(r.db.QueryRowContext(ctx, q, linkageID))
}

func (r *Repository) ListLinkedAccounts(ctx context.Context, customerRef string) ([]domain.LinkedAccount, error) {
	const q = selectAccounts + ` WHERE customer_ref=$1 ORDER BY linked_at DESC`
	rows, err := r.db.QueryContext(ctx, q, customerRef)
	if err != nil {
		return nil, domain.NewInternalError("query linked accounts", err)
	}
	defer rows.Close()
	var out []domain.LinkedAccount
	for rows.Next() {
		a, err := scanAccountRows(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, *a)
	}
	return out, rows.Err()
}

func (r *Repository) UpdateLinkedAccountStatus(ctx context.Context, linkageID string, status domain.LinkStatus) error {
	res, err := r.db.ExecContext(ctx, `UPDATE linked_accounts SET status=$2 WHERE linkage_id=$1`, linkageID, status)
	if err != nil {
		return domain.NewInternalError("update linked account status", err)
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return domain.NewNotFoundError("linked account not found: "+linkageID, nil)
	}
	return nil
}

func (r *Repository) Ping(ctx context.Context) error {
	if err := r.db.PingContext(ctx); err != nil {
		return domain.NewInternalError("database ping failed", err)
	}
	return nil
}

const selectAccounts = `
SELECT linkage_id, consent_id, scheme, customer_ref, account_id, account_name, masked_iban, account_type, currency, status, linked_at
  FROM linked_accounts`

type scanner interface {
	Scan(dest ...any) error
}

func scanAccount(row scanner) (*domain.LinkedAccount, error) {
	a, err := scanAccountRows(row)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, domain.NewNotFoundError("linked account not found", err)
	}
	return a, err
}

func scanAccountRows(row scanner) (*domain.LinkedAccount, error) {
	var a domain.LinkedAccount
	if err := row.Scan(&a.LinkageID, &a.ConsentID, &a.Scheme, &a.CustomerRef, &a.AccountID, &a.AccountName,
		&a.MaskedIBAN, &a.AccountType, &a.Currency, &a.Status, &a.LinkedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, err
		}
		return nil, domain.NewInternalError("scan linked account", err)
	}
	return &a, nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_postgres_Logfile.log at runtime.
var _ = func() bool { flog.For("9_postgres").Info("source file initialized"); return true }()
