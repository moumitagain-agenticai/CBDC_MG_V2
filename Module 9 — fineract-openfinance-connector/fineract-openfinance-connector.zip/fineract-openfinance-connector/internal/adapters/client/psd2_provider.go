package client

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"context"
	"net/http"
	"net/url"

	"github.com/fineract/openfinance-connector/internal/config"
	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
)

// PSD2Provider implements the EU PSD2 (Berlin Group-style) scheme. It maps the
// Berlin Group wire shapes (consentId/consentStatus/scaRedirect, balances array)
// onto the connector's scheme-neutral port.
type PSD2Provider struct {
	c      *caller
	tokens *tokenCache
}

var _ ports.OpenBankingProvider = (*PSD2Provider)(nil)

// NewPSD2 builds a PSD2 provider from configuration.
func NewPSD2(cfg config.ProviderConfig) (*PSD2Provider, error) {
	c, err := newCaller(cfg)
	if err != nil {
		return nil, err
	}
	return &PSD2Provider{c: c, tokens: newTokenCache()}, nil
}

func (p *PSD2Provider) Scheme() domain.Scheme { return domain.SchemePSD2 }

type psd2ConsentReq struct {
	Access         map[string][]string `json:"access"`
	PSUReference   string              `json:"psu_reference"`
	TPPRedirectURI string              `json:"tpp_redirect_uri,omitempty"`
}

type psd2ConsentResp struct {
	ConsentID     string `json:"consentId"`
	ConsentStatus string `json:"consentStatus"`
	SCARedirect   string `json:"scaRedirect"`
	ExpiresIn     int    `json:"expires_in"`
}

type psd2AuthReq struct {
	AuthorizationCode string `json:"authorization_code"`
}

type psd2Account struct {
	ResourceID      string `json:"resourceId"`
	IBAN            string `json:"iban"`
	Name            string `json:"name"`
	CashAccountType string `json:"cashAccountType"`
	Currency        string `json:"currency"`
}

type psd2AuthResp struct {
	AccessToken string        `json:"access_token"`
	Accounts    []psd2Account `json:"accounts"`
}

type psd2Amount struct {
	Amount   string `json:"amount"`
	Currency string `json:"currency"`
}

type psd2Balance struct {
	BalanceAmount psd2Amount `json:"balanceAmount"`
	BalanceType   string     `json:"balanceType"`
}

type psd2BalanceResp struct {
	Account struct {
		ResourceID string `json:"resourceId"`
	} `json:"account"`
	Balances []psd2Balance `json:"balances"`
}

func (p *PSD2Provider) CreateConsent(ctx context.Context, req ports.CreateConsentRequest) (ports.ConsentResponse, error) {
	perms := req.Permissions
	if len(perms) == 0 {
		perms = domain.DefaultPermissions
	}
	// Map generic permissions onto the Berlin Group "access" object.
	access := map[string][]string{"accounts": {}, "balances": {}}
	body := psd2ConsentReq{Access: access, PSUReference: req.CustomerRef, TPPRedirectURI: p.c.redirectURL}
	var out psd2ConsentResp
	if err := p.c.do(ctx, http.MethodPost, "/v1/consents", body, &out, ""); err != nil {
		return ports.ConsentResponse{}, err
	}
	return ports.ConsentResponse{
		ConsentID:        out.ConsentID,
		Status:           out.ConsentStatus,
		AuthorizationURL: out.SCARedirect,
		ExpiresInSeconds: out.ExpiresIn,
	}, nil
}

func (p *PSD2Provider) ExchangeAuthorization(ctx context.Context, consentID, authCode string) (ports.AccountsResponse, error) {
	var out psd2AuthResp
	path := "/v1/consents/" + url.PathEscape(consentID) + "/token"
	if err := p.c.do(ctx, http.MethodPost, path, psd2AuthReq{AuthorizationCode: authCode}, &out, ""); err != nil {
		return ports.AccountsResponse{}, err
	}
	p.tokens.set(consentID, out.AccessToken)
	accts := make([]ports.AccountDTO, 0, len(out.Accounts))
	for _, a := range out.Accounts {
		accts = append(accts, ports.AccountDTO{AccountID: a.ResourceID, IBAN: a.IBAN, Name: a.Name, Type: a.CashAccountType, Currency: a.Currency})
	}
	return ports.AccountsResponse{Accounts: accts}, nil
}

func (p *PSD2Provider) GetBalance(ctx context.Context, consentID, accountID string) (ports.BalanceResponse, error) {
	token := p.tokens.get(consentID)
	if token == "" {
		return ports.BalanceResponse{}, domain.NewUnauthorizedError("no active authorization for this consent; re-link the account", nil)
	}
	var out psd2BalanceResp
	path := "/v1/accounts/" + url.PathEscape(accountID) + "/balances"
	if err := p.c.do(ctx, http.MethodGet, path, nil, &out, token); err != nil {
		return ports.BalanceResponse{}, err
	}
	if len(out.Balances) == 0 {
		return ports.BalanceResponse{}, domain.NewUpstreamError("provider returned no balances", nil)
	}
	b := pickBalance(out.Balances)
	return ports.BalanceResponse{AccountID: accountID, Amount: b.BalanceAmount.Amount, Currency: b.BalanceAmount.Currency, Type: b.BalanceType}, nil
}

// pickBalance prefers an interim/available balance, else the first entry.
func pickBalance(bs []psd2Balance) psd2Balance {
	for _, b := range bs {
		switch b.BalanceType {
		case "interimAvailable", "expected", "available":
			return b
		}
	}
	return bs[0]
}

func (p *PSD2Provider) RevokeConsent(ctx context.Context, consentID string) error {
	path := "/v1/consents/" + url.PathEscape(consentID)
	if err := p.c.do(ctx, http.MethodDelete, path, nil, nil, ""); err != nil {
		return err
	}
	p.tokens.delete(consentID)
	return nil
}

func (p *PSD2Provider) Health(ctx context.Context) error {
	return p.c.do(ctx, http.MethodGet, "/v1/health", nil, nil, "")
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_psd2_provider_Logfile.log at runtime.
var _ = func() bool { flog.For("9_psd2_provider").Info("source file initialized"); return true }()
