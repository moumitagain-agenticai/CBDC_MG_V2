package client

import "github.com/fineract/openfinance-connector/pkg/flog"
import (
	"context"
	"net/http"
	"net/url"

	"github.com/fineract/openfinance-connector/internal/config"
	"github.com/fineract/openfinance-connector/internal/domain"
	"github.com/fineract/openfinance-connector/internal/ports"
)

// AlTareqProvider implements the UAE Open Finance (AlTareq) scheme.
type AlTareqProvider struct {
	c      *caller
	tokens *tokenCache
}

var _ ports.OpenBankingProvider = (*AlTareqProvider)(nil)

// NewAlTareq builds an AlTareq provider from configuration.
func NewAlTareq(cfg config.ProviderConfig) (*AlTareqProvider, error) {
	c, err := newCaller(cfg)
	if err != nil {
		return nil, err
	}
	return &AlTareqProvider{c: c, tokens: newTokenCache()}, nil
}

func (p *AlTareqProvider) Scheme() domain.Scheme { return domain.SchemeAlTareq }

type altareqConsentReq struct {
	Permissions []string `json:"permissions"`
	CustomerRef string   `json:"customer_ref"`
	RedirectURL string   `json:"redirect_url,omitempty"`
}

type altareqConsentResp struct {
	ConsentID        string `json:"consent_id"`
	Status           string `json:"status"`
	AuthorizationURL string `json:"authorization_url"`
	ExpiresIn        int    `json:"expires_in"`
}

type altareqAuthReq struct {
	ConsentID         string `json:"consent_id"`
	AuthorizationCode string `json:"authorization_code"`
}

type altareqAccount struct {
	AccountID string `json:"account_id"`
	IBAN      string `json:"iban"`
	Name      string `json:"name"`
	Type      string `json:"type"`
	Currency  string `json:"currency"`
}

type altareqAuthResp struct {
	AccessToken string           `json:"access_token"`
	Accounts    []altareqAccount `json:"accounts"`
}

type altareqBalanceResp struct {
	AccountID string `json:"account_id"`
	Amount    string `json:"amount"`
	Currency  string `json:"currency"`
	Type      string `json:"type"`
}

func (p *AlTareqProvider) CreateConsent(ctx context.Context, req ports.CreateConsentRequest) (ports.ConsentResponse, error) {
	perms := req.Permissions
	if len(perms) == 0 {
		perms = domain.DefaultPermissions
	}
	var out altareqConsentResp
	body := altareqConsentReq{Permissions: perms, CustomerRef: req.CustomerRef, RedirectURL: p.c.redirectURL}
	if err := p.c.do(ctx, http.MethodPost, "/open-finance/v1/account-access-consents", body, &out, ""); err != nil {
		return ports.ConsentResponse{}, err
	}
	return ports.ConsentResponse{ConsentID: out.ConsentID, Status: out.Status, AuthorizationURL: out.AuthorizationURL, ExpiresInSeconds: out.ExpiresIn}, nil
}

func (p *AlTareqProvider) ExchangeAuthorization(ctx context.Context, consentID, authCode string) (ports.AccountsResponse, error) {
	var out altareqAuthResp
	if err := p.c.do(ctx, http.MethodPost, "/open-finance/v1/authorizations", altareqAuthReq{ConsentID: consentID, AuthorizationCode: authCode}, &out, ""); err != nil {
		return ports.AccountsResponse{}, err
	}
	p.tokens.set(consentID, out.AccessToken)
	accts := make([]ports.AccountDTO, 0, len(out.Accounts))
	for _, a := range out.Accounts {
		accts = append(accts, ports.AccountDTO{AccountID: a.AccountID, IBAN: a.IBAN, Name: a.Name, Type: a.Type, Currency: a.Currency})
	}
	return ports.AccountsResponse{Accounts: accts}, nil
}

func (p *AlTareqProvider) GetBalance(ctx context.Context, consentID, accountID string) (ports.BalanceResponse, error) {
	token := p.tokens.get(consentID)
	if token == "" {
		return ports.BalanceResponse{}, domain.NewUnauthorizedError("no active authorization for this consent; re-link the account", nil)
	}
	var out altareqBalanceResp
	path := "/open-finance/v1/accounts/" + url.PathEscape(accountID) + "/balances"
	if err := p.c.do(ctx, http.MethodGet, path, nil, &out, token); err != nil {
		return ports.BalanceResponse{}, err
	}
	return ports.BalanceResponse{AccountID: out.AccountID, Amount: out.Amount, Currency: out.Currency, Type: out.Type}, nil
}

func (p *AlTareqProvider) RevokeConsent(ctx context.Context, consentID string) error {
	path := "/open-finance/v1/account-access-consents/" + url.PathEscape(consentID)
	if err := p.c.do(ctx, http.MethodDelete, path, nil, nil, ""); err != nil {
		return err
	}
	p.tokens.delete(consentID)
	return nil
}

func (p *AlTareqProvider) Health(ctx context.Context) error {
	return p.c.do(ctx, http.MethodGet, "/open-finance/v1/health", nil, nil, "")
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/9_altareq_provider_Logfile.log at runtime.
var _ = func() bool { flog.For("9_altareq_provider").Info("source file initialized"); return true }()
