package txnrepo

import (
	"errors"
	"fmt"
)

// Code classifies a repository error.
type Code string

// Error codes.
const (
	CodeValidation Code = "validation"
	CodeNotFound   Code = "not_found"
	CodeConflict   Code = "conflict"
	CodeInternal   Code = "internal"
)

// Error is the classified error type.
type Error struct {
	Code    Code
	Message string
	Err     error
}

func (e *Error) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

func (e *Error) Unwrap() error { return e.Err }

// ErrValidation builds a validation error.
func ErrValidation(m string) *Error { return &Error{Code: CodeValidation, Message: m} }

// ErrNotFound builds a not-found error.
func ErrNotFound(m string) *Error { return &Error{Code: CodeNotFound, Message: m} }

// ErrConflict builds a conflict error.
func ErrConflict(m string) *Error { return &Error{Code: CodeConflict, Message: m} }

// ErrInternal wraps an internal error.
func ErrInternal(m string, err error) *Error { return &Error{Code: CodeInternal, Message: m, Err: err} }

// CodeOf returns the classification of err.
func CodeOf(err error) Code {
	if err == nil {
		return ""
	}
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return CodeInternal
}
