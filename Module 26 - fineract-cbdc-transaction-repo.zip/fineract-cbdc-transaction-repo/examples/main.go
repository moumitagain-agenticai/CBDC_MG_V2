// Command example demonstrates Module 26: saving a transaction and changing its
// status each emit an outbox event, proving the outbox-on-producers guarantee.
//
//	go run ./examples
package main

import (
	"context"
	"fmt"

	txnrepo "github.com/fineract/cbdc/transaction-repo"
	"github.com/fineract/cbdc/transaction-repo/store"
)

func main() {
	ctx := context.Background()
	s := store.NewMemory()

	txn := txnrepo.NewTransaction("transfer", "acc-alice", "acc-bob", 50000, "INR", "invoice-42")
	if err := s.Save(ctx, txn); err != nil {
		panic(err)
	}
	fmt.Printf("saved transaction %s (status=%s)\n", txn.ID, txn.Status)

	if err := s.SetStatus(ctx, txn.ID, txnrepo.StatusPosted); err != nil {
		panic(err)
	}
	fmt.Println("status updated to POSTED")

	fmt.Println("\noutbox events produced (delivered later by the outbox-relay, N1):")
	for _, ev := range s.Events() {
		fmt.Printf("  %-28s txn=%s  %s\n", ev.EventType, ev.TxnID, string(ev.Payload))
	}
}
