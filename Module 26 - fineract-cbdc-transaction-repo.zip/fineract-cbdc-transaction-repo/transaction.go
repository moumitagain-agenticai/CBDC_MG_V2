// Package txnrepo is Module 26 of the E1 CBDC platform: the transaction
// repository.
//
// This rework adds the OUTBOX-ON-PRODUCERS guarantee: every write that PRODUCES
// or changes a transaction also writes an outbox event in the SAME database
// transaction. A transaction and its event therefore commit together or not at
// all, so downstream consumers never miss a state change even if the process
// crashes right after the commit. The outbox rows are delivered by the
// outbox-relay (Module N1); consumers dedupe via the idempotency-gateway (N2).
package txnrepo

import (
	"encoding/json"
	"strings"
	"time"

	"github.com/google/uuid"
)

// Status is the lifecycle state of a transaction.
type Status string

// Transaction statuses.
const (
	StatusPending  Status = "PENDING"
	StatusPosted   Status = "POSTED"
	StatusReversed Status = "REVERSED"
)

// Valid reports whether s is a known status.
func (s Status) Valid() bool {
	switch s {
	case StatusPending, StatusPosted, StatusReversed:
		return true
	}
	return false
}

// Transaction is a ledger transaction record.
type Transaction struct {
	ID            string    `json:"id"`
	Type          string    `json:"type"` // e.g. "transfer", "settlement"
	DebitAccount  string    `json:"debit_account"`
	CreditAccount string    `json:"credit_account"`
	AmountMinor   int64     `json:"amount_minor"`
	Currency      string    `json:"currency"`
	Status        Status    `json:"status"`
	Reference     string    `json:"reference"`
	CreatedAt     time.Time `json:"created_at"`
	UpdatedAt     time.Time `json:"updated_at"`
}

// NewTransaction builds a PENDING transaction with a fresh id and timestamps.
func NewTransaction(txnType, debit, credit string, amountMinor int64, currency, reference string) *Transaction {
	now := time.Now().UTC()
	return &Transaction{
		ID:            uuid.NewString(),
		Type:          strings.TrimSpace(txnType),
		DebitAccount:  strings.TrimSpace(debit),
		CreditAccount: strings.TrimSpace(credit),
		AmountMinor:   amountMinor,
		Currency:      strings.TrimSpace(currency),
		Status:        StatusPending,
		Reference:     strings.TrimSpace(reference),
		CreatedAt:     now,
		UpdatedAt:     now,
	}
}

// Validate reports whether the transaction is well-formed.
func (t *Transaction) Validate() error {
	if t.ID == "" {
		return ErrValidation("id is required")
	}
	if t.Type == "" {
		return ErrValidation("type is required")
	}
	if t.DebitAccount == "" || t.CreditAccount == "" {
		return ErrValidation("debit and credit accounts are required")
	}
	if t.DebitAccount == t.CreditAccount {
		return ErrValidation("debit and credit accounts must differ")
	}
	if t.AmountMinor <= 0 {
		return ErrValidation("amount must be positive")
	}
	if len(t.Currency) != 3 {
		return ErrValidation("currency must be a 3-letter code")
	}
	if !t.Status.Valid() {
		return ErrValidation("invalid status")
	}
	return nil
}

// Event types emitted to the outbox.
const (
	EventCreated       = "transaction.created"
	EventStatusChanged = "transaction.status_changed"
)

// Event is an outbox event produced by a transaction write. It is what the
// outbox-relay (N1) delivers to consumers.
type Event struct {
	ID        string    `json:"id"`
	TxnID     string    `json:"txn_id"`
	EventType string    `json:"event_type"`
	Payload   []byte    `json:"payload"`
	CreatedAt time.Time `json:"created_at"`
}

// eventPayload is the JSON body carried by an event.
type eventPayload struct {
	TxnID    string `json:"txn_id"`
	Type     string `json:"type"`
	Status   Status `json:"status"`
	Amount   int64  `json:"amount_minor"`
	Currency string `json:"currency"`
}

// NewEvent builds an outbox event describing the current state of a transaction.
func NewEvent(eventType string, t *Transaction) *Event {
	body, _ := json.Marshal(eventPayload{
		TxnID: t.ID, Type: t.Type, Status: t.Status, Amount: t.AmountMinor, Currency: t.Currency,
	})
	return &Event{
		ID:        uuid.NewString(),
		TxnID:     t.ID,
		EventType: eventType,
		Payload:   body,
		CreatedAt: time.Now().UTC(),
	}
}
