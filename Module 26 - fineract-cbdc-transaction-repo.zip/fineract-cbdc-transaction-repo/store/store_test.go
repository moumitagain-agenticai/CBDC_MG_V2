package store_test

import (
	"context"
	"testing"

	txnrepo "github.com/fineract/cbdc/transaction-repo"
	"github.com/fineract/cbdc/transaction-repo/store"
)

func TestSaveEmitsCreatedEventAtomically(t *testing.T) {
	s := store.NewMemory()
	ctx := context.Background()
	txn := txnrepo.NewTransaction("transfer", "acc-a", "acc-b", 50000, "INR", "ref-1")
	if err := s.Save(ctx, txn); err != nil {
		t.Fatalf("save: %v", err)
	}
	events := s.Events()
	if len(events) != 1 {
		t.Fatalf("want exactly 1 outbox event after Save, got %d", len(events))
	}
	if events[0].EventType != txnrepo.EventCreated || events[0].TxnID != txn.ID {
		t.Fatalf("unexpected event: %+v", events[0])
	}
}

func TestSetStatusEmitsStatusEvent(t *testing.T) {
	s := store.NewMemory()
	ctx := context.Background()
	txn := txnrepo.NewTransaction("transfer", "acc-a", "acc-b", 50000, "INR", "ref-1")
	_ = s.Save(ctx, txn)
	if err := s.SetStatus(ctx, txn.ID, txnrepo.StatusPosted); err != nil {
		t.Fatalf("set status: %v", err)
	}
	events := s.Events()
	if len(events) != 2 {
		t.Fatalf("want 2 events (created + status_changed), got %d", len(events))
	}
	if events[1].EventType != txnrepo.EventStatusChanged {
		t.Fatalf("want status_changed, got %s", events[1].EventType)
	}
	got, _ := s.Get(ctx, txn.ID)
	if got.Status != txnrepo.StatusPosted {
		t.Fatalf("want POSTED, got %s", got.Status)
	}
}

func TestDuplicateSaveConflicts(t *testing.T) {
	s := store.NewMemory()
	ctx := context.Background()
	txn := txnrepo.NewTransaction("transfer", "acc-a", "acc-b", 1, "INR", "r")
	_ = s.Save(ctx, txn)
	if err := s.Save(ctx, txn); txnrepo.CodeOf(err) != txnrepo.CodeConflict {
		t.Fatalf("want conflict on duplicate save, got %v", err)
	}
	// a rejected save must NOT emit a second event
	if len(s.Events()) != 1 {
		t.Fatalf("want 1 event after rejected duplicate, got %d", len(s.Events()))
	}
}

func TestSetStatusUnknownNotFound(t *testing.T) {
	s := store.NewMemory()
	if err := s.SetStatus(context.Background(), "nope", txnrepo.StatusPosted); txnrepo.CodeOf(err) != txnrepo.CodeNotFound {
		t.Fatalf("want not found, got %v", err)
	}
}

func TestListByAccount(t *testing.T) {
	s := store.NewMemory()
	ctx := context.Background()
	_ = s.Save(ctx, txnrepo.NewTransaction("transfer", "acc-a", "acc-b", 1, "INR", "r1"))
	_ = s.Save(ctx, txnrepo.NewTransaction("transfer", "acc-c", "acc-a", 2, "INR", "r2"))
	_ = s.Save(ctx, txnrepo.NewTransaction("transfer", "acc-c", "acc-d", 3, "INR", "r3"))
	list, _ := s.ListByAccount(ctx, "acc-a")
	if len(list) != 2 {
		t.Fatalf("want 2 for acc-a, got %d", len(list))
	}
}

func TestValidation(t *testing.T) {
	s := store.NewMemory()
	ctx := context.Background()
	// same debit/credit
	bad := txnrepo.NewTransaction("transfer", "acc-a", "acc-a", 1, "INR", "r")
	if err := s.Save(ctx, bad); txnrepo.CodeOf(err) != txnrepo.CodeValidation {
		t.Fatalf("want validation for same accounts, got %v", err)
	}
	// non-positive amount
	bad2 := txnrepo.NewTransaction("transfer", "acc-a", "acc-b", 0, "INR", "r")
	if err := s.Save(ctx, bad2); txnrepo.CodeOf(err) != txnrepo.CodeValidation {
		t.Fatalf("want validation for zero amount, got %v", err)
	}
}
