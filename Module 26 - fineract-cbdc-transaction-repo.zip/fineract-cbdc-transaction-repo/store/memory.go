package store

import (
	"context"
	"sort"
	"sync"
	"time"

	txnrepo "github.com/fineract/cbdc/transaction-repo"
)

// Memory is an in-memory Store. It captures emitted outbox events so tests can
// assert the outbox-on-producers guarantee.
type Memory struct {
	mu     sync.Mutex
	txns   map[string]*txnrepo.Transaction
	events []txnrepo.Event
}

var _ Store = (*Memory)(nil)

// NewMemory returns a ready in-memory store.
func NewMemory() *Memory {
	return &Memory{txns: make(map[string]*txnrepo.Transaction)}
}

func clone(t *txnrepo.Transaction) *txnrepo.Transaction {
	cp := *t
	return &cp
}

// Save persists a transaction and emits a created event atomically (under lock).
func (s *Memory) Save(_ context.Context, t *txnrepo.Transaction) error {
	if err := t.Validate(); err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.txns[t.ID]; ok {
		return txnrepo.ErrConflict("transaction already exists: " + t.ID)
	}
	s.txns[t.ID] = clone(t)
	s.events = append(s.events, *txnrepo.NewEvent(txnrepo.EventCreated, t))
	return nil
}

// SetStatus updates status and emits a status-changed event atomically.
func (s *Memory) SetStatus(_ context.Context, id string, status txnrepo.Status) error {
	if !status.Valid() {
		return txnrepo.ErrValidation("invalid status")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	t, ok := s.txns[id]
	if !ok {
		return txnrepo.ErrNotFound("transaction not found: " + id)
	}
	t.Status = status
	t.UpdatedAt = time.Now().UTC()
	s.events = append(s.events, *txnrepo.NewEvent(txnrepo.EventStatusChanged, t))
	return nil
}

// Get returns a transaction by id.
func (s *Memory) Get(_ context.Context, id string) (*txnrepo.Transaction, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	t, ok := s.txns[id]
	if !ok {
		return nil, txnrepo.ErrNotFound("transaction not found: " + id)
	}
	return clone(t), nil
}

// ListByAccount returns transactions touching the account, newest first.
func (s *Memory) ListByAccount(_ context.Context, account string) ([]txnrepo.Transaction, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []txnrepo.Transaction
	for _, t := range s.txns {
		if t.DebitAccount == account || t.CreditAccount == account {
			out = append(out, *clone(t))
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].CreatedAt.After(out[j].CreatedAt) })
	return out, nil
}

// Ping is always healthy.
func (s *Memory) Ping(_ context.Context) error { return nil }

// Events returns a copy of all emitted outbox events (test helper). It proves
// that each producing write emitted exactly one event.
func (s *Memory) Events() []txnrepo.Event {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]txnrepo.Event(nil), s.events...)
}
