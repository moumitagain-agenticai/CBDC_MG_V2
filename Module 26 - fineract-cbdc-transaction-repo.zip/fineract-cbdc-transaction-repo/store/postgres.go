package store

import (
	"context"
	"database/sql"
	"errors"
	"time"

	txnrepo "github.com/fineract/cbdc/transaction-repo"
	_ "github.com/lib/pq"
)

// Postgres is a PostgreSQL-backed Store. Save and SetStatus each write the
// transaction row and the outbox event row inside ONE sql.Tx, which is the
// outbox-on-producers guarantee: the event is committed atomically with the
// state change it describes.
type Postgres struct{ db *sql.DB }

var _ Store = (*Postgres)(nil)

// NewPostgres wraps an existing *sql.DB.
func NewPostgres(db *sql.DB) *Postgres { return &Postgres{db: db} }

// Open opens a PostgreSQL database from a DSN.
func Open(dsn string) (*sql.DB, error) { return sql.Open("postgres", dsn) }

const schema = `
CREATE TABLE IF NOT EXISTS transactions (
    id             TEXT PRIMARY KEY,
    type           TEXT NOT NULL,
    debit_account  TEXT NOT NULL,
    credit_account TEXT NOT NULL,
    amount_minor   BIGINT NOT NULL,
    currency       TEXT NOT NULL,
    status         TEXT NOT NULL,
    reference      TEXT NOT NULL DEFAULT '',
    created_at     TIMESTAMPTZ NOT NULL,
    updated_at     TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_txn_debit  ON transactions (debit_account);
CREATE INDEX IF NOT EXISTS idx_txn_credit ON transactions (credit_account);

CREATE TABLE IF NOT EXISTS transaction_outbox (
    id         TEXT PRIMARY KEY,
    txn_id     TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload    BYTEA NOT NULL,
    status     TEXT NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_txn_outbox_pending ON transaction_outbox (status, created_at);
`

// Migrate creates the transactions and transaction_outbox tables.
func (s *Postgres) Migrate(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, schema)
	return err
}

func insertEvent(ctx context.Context, tx *sql.Tx, ev *txnrepo.Event) error {
	_, err := tx.ExecContext(ctx,
		`INSERT INTO transaction_outbox (id, txn_id, event_type, payload, status, created_at)
		 VALUES ($1,$2,$3,$4,'PENDING',$5)`,
		ev.ID, ev.TxnID, ev.EventType, ev.Payload, ev.CreatedAt)
	return err
}

// Save writes the transaction and its created event in one transaction.
func (s *Postgres) Save(ctx context.Context, t *txnrepo.Transaction) error {
	if err := t.Validate(); err != nil {
		return err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return txnrepo.ErrInternal("begin", err)
	}
	defer func() { _ = tx.Rollback() }()

	_, err = tx.ExecContext(ctx,
		`INSERT INTO transactions
		 (id, type, debit_account, credit_account, amount_minor, currency, status, reference, created_at, updated_at)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
		t.ID, t.Type, t.DebitAccount, t.CreditAccount, t.AmountMinor, t.Currency, t.Status, t.Reference, t.CreatedAt, t.UpdatedAt)
	if err != nil {
		return txnrepo.ErrConflict("insert transaction failed (possibly duplicate id): " + t.ID)
	}
	if err := insertEvent(ctx, tx, txnrepo.NewEvent(txnrepo.EventCreated, t)); err != nil {
		return txnrepo.ErrInternal("insert outbox event", err)
	}
	if err := tx.Commit(); err != nil {
		return txnrepo.ErrInternal("commit", err)
	}
	return nil
}

// SetStatus updates status and writes a status-changed event in one transaction.
func (s *Postgres) SetStatus(ctx context.Context, id string, status txnrepo.Status) error {
	if !status.Valid() {
		return txnrepo.ErrValidation("invalid status")
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return txnrepo.ErrInternal("begin", err)
	}
	defer func() { _ = tx.Rollback() }()

	now := time.Now().UTC()
	res, err := tx.ExecContext(ctx,
		`UPDATE transactions SET status=$2, updated_at=$3 WHERE id=$1`, id, status, now)
	if err != nil {
		return txnrepo.ErrInternal("update status", err)
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return txnrepo.ErrNotFound("transaction not found: " + id)
	}
	t, err := s.getTx(ctx, tx, id)
	if err != nil {
		return err
	}
	if err := insertEvent(ctx, tx, txnrepo.NewEvent(txnrepo.EventStatusChanged, t)); err != nil {
		return txnrepo.ErrInternal("insert outbox event", err)
	}
	if err := tx.Commit(); err != nil {
		return txnrepo.ErrInternal("commit", err)
	}
	return nil
}

func (s *Postgres) getTx(ctx context.Context, tx *sql.Tx, id string) (*txnrepo.Transaction, error) {
	var t txnrepo.Transaction
	err := tx.QueryRowContext(ctx,
		`SELECT id, type, debit_account, credit_account, amount_minor, currency, status, reference, created_at, updated_at
		 FROM transactions WHERE id=$1`, id).
		Scan(&t.ID, &t.Type, &t.DebitAccount, &t.CreditAccount, &t.AmountMinor, &t.Currency, &t.Status, &t.Reference, &t.CreatedAt, &t.UpdatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, txnrepo.ErrNotFound("transaction not found: " + id)
	}
	if err != nil {
		return nil, txnrepo.ErrInternal("scan transaction", err)
	}
	return &t, nil
}

// Get returns a transaction by id.
func (s *Postgres) Get(ctx context.Context, id string) (*txnrepo.Transaction, error) {
	var t txnrepo.Transaction
	err := s.db.QueryRowContext(ctx,
		`SELECT id, type, debit_account, credit_account, amount_minor, currency, status, reference, created_at, updated_at
		 FROM transactions WHERE id=$1`, id).
		Scan(&t.ID, &t.Type, &t.DebitAccount, &t.CreditAccount, &t.AmountMinor, &t.Currency, &t.Status, &t.Reference, &t.CreatedAt, &t.UpdatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, txnrepo.ErrNotFound("transaction not found: " + id)
	}
	if err != nil {
		return nil, txnrepo.ErrInternal("query transaction", err)
	}
	return &t, nil
}

// ListByAccount returns transactions touching the account, newest first.
func (s *Postgres) ListByAccount(ctx context.Context, account string) ([]txnrepo.Transaction, error) {
	rows, err := s.db.QueryContext(ctx,
		`SELECT id, type, debit_account, credit_account, amount_minor, currency, status, reference, created_at, updated_at
		 FROM transactions WHERE debit_account=$1 OR credit_account=$1 ORDER BY created_at DESC`, account)
	if err != nil {
		return nil, txnrepo.ErrInternal("list", err)
	}
	defer rows.Close()
	var out []txnrepo.Transaction
	for rows.Next() {
		var t txnrepo.Transaction
		if err := rows.Scan(&t.ID, &t.Type, &t.DebitAccount, &t.CreditAccount, &t.AmountMinor, &t.Currency, &t.Status, &t.Reference, &t.CreatedAt, &t.UpdatedAt); err != nil {
			return nil, txnrepo.ErrInternal("scan", err)
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

// Ping checks database health.
func (s *Postgres) Ping(ctx context.Context) error { return s.db.PingContext(ctx) }
