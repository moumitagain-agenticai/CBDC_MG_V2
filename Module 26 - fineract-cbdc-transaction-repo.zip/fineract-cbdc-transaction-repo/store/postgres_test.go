package store_test

import (
	"context"
	"os"
	"testing"

	txnrepo "github.com/fineract/cbdc/transaction-repo"
	"github.com/fineract/cbdc/transaction-repo/store"
)

func TestPostgresSaveWritesOutbox(t *testing.T) {
	dsn := os.Getenv("DATABASE_DSN")
	if dsn == "" {
		t.Skip("DATABASE_DSN not set")
	}
	db, err := store.Open(dsn)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer db.Close()
	pg := store.NewPostgres(db)
	ctx := context.Background()
	if err := pg.Migrate(ctx); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	txn := txnrepo.NewTransaction("transfer", "acc-a", "acc-b", 50000, "INR", "ref-1")
	if err := pg.Save(ctx, txn); err != nil {
		t.Fatalf("save: %v", err)
	}
	var n int
	if err := db.QueryRowContext(ctx, `SELECT count(*) FROM transaction_outbox WHERE txn_id=$1`, txn.ID).Scan(&n); err != nil {
		t.Fatalf("count outbox: %v", err)
	}
	if n != 1 {
		t.Fatalf("want 1 outbox row committed with the transaction, got %d", n)
	}
}
