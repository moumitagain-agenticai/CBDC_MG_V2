// Package store persists transactions with the outbox-on-producers guarantee:
// Save and SetStatus each write the transaction AND an outbox event atomically.
// It provides an in-memory store and a PostgreSQL store (using lib/pq).
package store

import (
	"context"

	txnrepo "github.com/fineract/cbdc/transaction-repo"
)

// Store persists transactions and emits outbox events on every producing write.
type Store interface {
	// Save persists a new transaction AND a "transaction.created" outbox event in
	// a single atomic operation.
	Save(ctx context.Context, t *txnrepo.Transaction) error
	// SetStatus updates a transaction's status AND emits a
	// "transaction.status_changed" outbox event atomically.
	SetStatus(ctx context.Context, id string, status txnrepo.Status) error
	// Get returns a transaction by id.
	Get(ctx context.Context, id string) (*txnrepo.Transaction, error)
	// ListByAccount returns transactions where the account is debit or credit.
	ListByAccount(ctx context.Context, account string) ([]txnrepo.Transaction, error)
	// Ping checks backend health.
	Ping(ctx context.Context) error
}
