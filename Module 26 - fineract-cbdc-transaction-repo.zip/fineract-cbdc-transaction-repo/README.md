# fineract-cbdc-transaction-repo  (Module 26 — P0 rework)

The **transaction repository**. This rework adds the **outbox-on-producers**
guarantee: every write that produces or changes a transaction also writes an
**outbox event in the same database transaction**, so downstream consumers never
miss a state change — even if the process crashes immediately after commit.

Module path: `github.com/fineract/cbdc/transaction-repo` · Go 1.21+.

## The guarantee

```
Save(txn)      ─┐ one DB transaction ┌─ INSERT into transactions
                └────────────────────┴─ INSERT "transaction.created" into transaction_outbox

SetStatus(...) ─┐ one DB transaction ┌─ UPDATE transactions
                └────────────────────┴─ INSERT "transaction.status_changed" into transaction_outbox
```

Either both rows commit or neither does. The outbox rows are then delivered by
the **outbox-relay (Module N1)**; consumers dedupe duplicates via the
**idempotency-gateway (Module N2)**. This module is where the producers live —
it is the reason N1 has anything to relay.

## Interface

```go
s.Save(ctx, txn)                     // persists txn + emits transaction.created
s.SetStatus(ctx, id, StatusPosted)   // updates + emits transaction.status_changed
s.Get(ctx, id)
s.ListByAccount(ctx, account)        // debit or credit side
s.Ping(ctx)
```

`txnrepo.NewTransaction(type, debit, credit, amountMinor, currency, reference)`
builds a `PENDING` transaction with a fresh id.

## Why the event lives with the write

If a service updated `transactions` and *then* published an event as a separate
step, a crash in between would lose the event. Writing the event row **inside the
same transaction** removes that gap. The in-memory store captures emitted events
(`Events()`) so tests can assert the invariant; the PostgreSQL store does the two
inserts inside one `sql.Tx`.

## Packages

| Path | Responsibility |
|------|----------------|
| `transaction.go` | `Transaction`, `Status`, `Event`, `NewTransaction`, `NewEvent`. |
| `store/` | `Store` port + in-memory (event-capturing) and PostgreSQL (atomic txn + outbox) + `Migrate`. |
| `migrations/001_init.sql` | `transactions` and `transaction_outbox` tables. |

## Build, test, run

```bash
go build ./...
go vet ./...
go test ./...                       # unit tests (event emission proven in-memory)
DATABASE_DSN=postgres://... go test ./store/...   # DB-gated: proves outbox row commits with txn
go run ./examples
```

## Error model

`txnrepo.CodeOf(err)` returns one of: `validation`, `not_found`, `conflict`,
`internal`.

## Dependencies

`github.com/google/uuid` (ids) and `github.com/lib/pq` (PostgreSQL driver).
