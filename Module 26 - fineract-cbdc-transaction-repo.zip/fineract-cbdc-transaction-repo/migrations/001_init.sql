-- fineract-cbdc-transaction-repo: transactions + producer outbox.
-- Save/SetStatus write to both tables in one DB transaction (outbox on producers).
CREATE TABLE IF NOT EXISTS transactions (
    id             TEXT PRIMARY KEY,
    type           TEXT NOT NULL,
    debit_account  TEXT NOT NULL,
    credit_account TEXT NOT NULL,
    amount_minor   BIGINT NOT NULL,
    currency       TEXT NOT NULL,
    status         TEXT NOT NULL,
    reference      TEXT NOT NULL DEFAULT '',
    created_at     TIMESTAMPTZ NOT NULL,
    updated_at     TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_txn_debit  ON transactions (debit_account);
CREATE INDEX IF NOT EXISTS idx_txn_credit ON transactions (credit_account);

CREATE TABLE IF NOT EXISTS transaction_outbox (
    id         TEXT PRIMARY KEY,
    txn_id     TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload    BYTEA NOT NULL,
    status     TEXT NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_txn_outbox_pending ON transaction_outbox (status, created_at);
