# BUILD REPORT — fineract-cbdc-transaction-repo (Module 26)

Toolchain: Go 1.22 (module declares `go 1.21`). Module path:
`github.com/fineract/cbdc/transaction-repo`.

| Check | Command | Result |
|-------|---------|--------|
| Formatting | `gofmt -l .` | clean |
| Dependencies | `go mod tidy` | clean (`google/uuid`, `lib/pq`) |
| Build | `go build ./...` | pass (exit 0) |
| Vet | `go vet ./...` | pass (exit 0) |
| Unit tests | `go test ./...` | pass (store) |
| Example | `go run ./examples` | Save + SetStatus each emit an outbox event |

Requirement coverage (finalised list, #26 — REWORK outbox on producers): every
producing write (`Save`, `SetStatus`) emits an outbox event atomically with the
transaction change. The in-memory store captures events; the PostgreSQL store
writes the transaction row and the `transaction_outbox` row in a single `sql.Tx`.

Tests: Save emits exactly one `transaction.created` event; SetStatus emits
`transaction.status_changed` and updates status; a rejected duplicate Save emits
no extra event; set-status on unknown id → not found; list-by-account (debit or
credit); validation (same debit/credit, non-positive amount). A DB-gated Postgres
test asserts exactly one outbox row is committed with the transaction. Nothing
pushed to any remote.
