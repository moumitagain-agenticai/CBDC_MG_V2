# fineract-cbdc-giftcity-connector

Module 4 of the E1 Cross-Border CBDC platform. It connects Apache Fineract to a
**Gift City (GIFT City IFSC) API provider** — an alternative route to the UAE
partner bank (Module 3) for **Digital Dirham (AED)** operations — and exposes the
standard connector operations (**issue, transfer, lock, burn, redeem**) plus
balance, status, and health endpoints. Its distinguishing feature is **Gift City
authentication**: a signed-request scheme (HMAC-SHA256 over a canonical request
string, with participant code, nonce, and timestamp) rather than a plain API key.

It is built to the same contract as **Module 1**
(`fineract-cbdc-connector-abstraction`) and the same convention as Modules 2–3.
The connector service implements the same five operations, so this module is a
drop-in implementation of the shared abstraction. It builds and runs stand-alone
today, and wires into the monorepo on top of Module 1 with no code changes (see
the commented block in `go.mod`).

## Architecture

Hexagonal (ports & adapters):

```
cmd/server            entrypoint: config load, DI wiring, graceful shutdown
internal/domain       entities + typed error taxonomy (no leaking internals)
internal/ports        interfaces + DTOs (CBDCClient, TransactionRepository)
internal/service      business logic: validate → persist → call provider → update
internal/adapters/
  api                 chi router, handlers, middleware (request-id, recover, logs)
  client              Gift City provider HTTP client + Gift City signed-request
                      auth (retry + circuit breaker + auth)
  repository          PostgreSQL transaction audit trail (parameterized SQL)
internal/config       YAML + env config, validated fail-fast on startup
pkg/logger            zap structured logging
pkg/metrics           Prometheus metrics on a private registry
pkg/utils             money-safe amount validation (big.Rat, never float)
```

## Gift City authentication

The default `auth_mode` is `giftcity`. Every outbound request is signed with an
HMAC-SHA256 over a canonical string of `method \n path \n query \n timestamp \n
nonce \n participant`, keyed by the participant's `secret_key`. The signature
and its inputs travel in headers the provider verifies to authenticate the
caller and reject replays:

```
X-GiftCity-Key          the participant's access key
X-GiftCity-Participant  the IFSC participant code
X-GiftCity-Timestamp    unix seconds (for replay windows)
X-GiftCity-Nonce        unique per request
X-GiftCity-Signature    hex HMAC-SHA256 of the canonical string
```

`apikey`, `oauth2`, and `mtls` modes remain available for other providers.

## Quickstart

```bash
# 1. dependencies + build (creates go.sum on first run)
make build            # or: go build ./cmd/server

# 2. configure
cp configs/config.example.yaml configs/config.yaml
cp .env.example .env   # put your giftcity-provider credentials here

# 3. run
make run               # or: go run ./cmd/server -config configs/config.yaml

# 4. test
make test              # unit tests
make itest             # integration tests (httptest against mocks)
```

With Docker:

```bash
docker compose -f deployments/docker-compose.yaml up --build
```

## Configuration

Config comes from `configs/config.yaml`, overridden by environment variables
(secrets should always come from env). Key variables:

| Env | Meaning |
|-----|---------|
| `CBDC_BASE_URL` | Gift City provider Digital Dirham API base URL (required) |
| `CBDC_AUTH_MODE` | `giftcity` \| `apikey` \| `oauth2` \| `mtls` |
| `CBDC_PARTICIPANT_CODE` / `CBDC_ACCESS_KEY` / `CBDC_SECRET_KEY` | Gift City signed-request auth (giftcity mode) |
| `CBDC_API_KEY` | API key (apikey mode) |
| `CBDC_OAUTH_TOKEN_URL` / `CBDC_CLIENT_ID` / `CBDC_CLIENT_SECRET` | oauth2 mode |
| `DATABASE_DSN` | Postgres DSN; setting it enables the audit trail |
| `SERVER_PORT` | HTTP port (default 8080) |
| `LOG_LEVEL` | `debug` \| `info` \| `warn` \| `error` |

The server **fails fast** on startup if required config is missing or
inconsistent.

## Database migrations

When persistence is enabled (`DATABASE_DSN` set), the connector **runs pending
migrations automatically on startup** and records them in a `schema_migrations`
table. Migrations are defined in Go (`internal/adapters/repository/migration.go`)
with versioned up/down SQL.

```bash
# roll back the last migration and exit
go run ./cmd/server -rollback 1
```

`migrations/001_init.sql` is also provided as a standalone reference you can
apply manually (`psql "$DATABASE_DSN" -f migrations/001_init.sql`) if you prefer
to manage schema outside the app.

## API

Base path `/api/v1`. See `api/openapi.yaml` for the full spec.

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/v1/issue` | Mint Digital Dirham into a wallet |
| POST | `/api/v1/transfer` | Move Digital Dirham between wallets |
| POST | `/api/v1/lock` | Reserve Digital Dirham |
| POST | `/api/v1/burn` | Destroy Digital Dirham |
| POST | `/api/v1/redeem` | Redeem Digital Dirham to bank money |
| GET | `/api/v1/wallets/{walletID}/balance` | Wallet balance |
| GET | `/api/v1/transactions/{id}/status` | Upstream status |
| GET | `/api/v1/transactions/{id}` | Persisted transaction |
| GET | `/healthz` `/readyz` `/metrics` | Liveness / readiness / Prometheus |

Example:

```bash
curl -X POST localhost:8080/api/v1/issue \
  -H 'Content-Type: application/json' \
  -d '{"wallet_id":"w1","amount":"100.50","currency":"AED",
       "reference_id":"11111111-1111-4111-8111-111111111111"}'
```

Write operations are **idempotent** on `reference_id` (a UUIDv4): replaying the
same reference returns the original result instead of double-processing.

## Production features

Retry with backoff (`go-retryablehttp`), circuit breaker (`gobreaker`),
context timeouts, request-id correlation, structured logs, Prometheus metrics,
input validation (`validator/v10`), Gift City HMAC signed-request auth, a stable
error-code → HTTP-status mapping,
rate limiting, CORS, graceful shutdown, parameterized SQL, and a non-root
multi-stage Docker image.

## Note on `go.sum`

`go.sum` is generated on first `go mod tidy` / `go build` (it needs network to
fetch and checksum dependencies). Run `make deps` once in an environment with
internet access and commit the resulting `go.sum`. The dependency set in
`go.mod` is standard and pulls cleanly from the public Go proxy.

## Per-source-file logging (Logrus)

In addition to the primary structured logger (zap, used for console/DI logging),
this module ships a **Logrus** per-source-file logger in `pkg/flog`. Every source
file writes its own log file under `logs/`, named `4_<file>.log`
(module number + source file name), e.g. `4_main.log`,
`4_config.log`. Each file registers itself with the logger, and a
Logrus hook routes entries to the matching file (JSON formatted). The `logs/`
directory is created on startup and is git-ignored. `go.sum` for the added
`github.com/sirupsen/logrus` dependency is generated on first `go mod tidy`.
