package domain

import "github.com/fineract/cbdc/giftcity-connector/pkg/flog"

// Wallet identifies a CBDC holder account at the Gift City provider.
type Wallet struct {
	ID       string `json:"id"`
	Currency string `json:"currency"`
	Status   string `json:"status"`
}

// Balance is a point-in-time balance snapshot for a wallet. Amounts are held as
// strings to avoid floating-point rounding on monetary values.
type Balance struct {
	WalletID  string `json:"wallet_id"`
	Available string `json:"available"`
	Locked    string `json:"locked"`
	Currency  string `json:"currency"`
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/4_wallet_Logfile.log at runtime.
var _ = func() bool { flog.For("4_wallet").Info("source file initialized"); return true }()
