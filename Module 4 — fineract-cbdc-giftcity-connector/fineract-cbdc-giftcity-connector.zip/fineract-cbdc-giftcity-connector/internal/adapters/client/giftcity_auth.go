package client

import "github.com/fineract/cbdc/giftcity-connector/pkg/flog"
import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/hashicorp/go-retryablehttp"
)

// giftCityAuth implements the Gift City provider's signed-request authentication
// scheme. Each request is signed with an HMAC-SHA256 over a canonical string of
// method, path, query, timestamp, nonce and participant code, keyed by the
// participant's secret. The signature and its inputs travel in X-GiftCity-*
// headers so the provider can verify authenticity and reject replays.
type giftCityAuth struct {
	participant string
	accessKey   string
	secretKey   string
}

// canonicalString builds the exact string that both sides sign. Field order and
// separators are part of the contract and must not change.
func canonicalString(method, path, rawQuery, timestamp, nonce, participant string) string {
	return strings.Join([]string{method, path, rawQuery, timestamp, nonce, participant}, "\n")
}

// sign returns the hex HMAC-SHA256 signature of the canonical string.
func sign(secret, canonical string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(canonical))
	return hex.EncodeToString(mac.Sum(nil))
}

func (a *giftCityAuth) apply(_ context.Context, req *retryablehttp.Request) error {
	ts := strconv.FormatInt(time.Now().UTC().Unix(), 10)
	nonce := uuid.NewString()

	canonical := canonicalString(req.Method, req.URL.Path, req.URL.RawQuery, ts, nonce, a.participant)
	signature := sign(a.secretKey, canonical)

	req.Header.Set("X-GiftCity-Key", a.accessKey)
	req.Header.Set("X-GiftCity-Participant", a.participant)
	req.Header.Set("X-GiftCity-Timestamp", ts)
	req.Header.Set("X-GiftCity-Nonce", nonce)
	req.Header.Set("X-GiftCity-Signature", signature)
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/4_giftcity_auth_Logfile.log at runtime.
var _ = func() bool { flog.For("4_giftcity_auth").Info("source file initialized"); return true }()
