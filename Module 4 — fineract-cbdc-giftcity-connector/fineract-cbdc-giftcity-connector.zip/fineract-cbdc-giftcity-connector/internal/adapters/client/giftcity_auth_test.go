package client

import (
	"context"
	"testing"

	"github.com/hashicorp/go-retryablehttp"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestGiftCityAuth_SignsAndVerifies checks that apply() sets the expected
// headers and that the signature verifies against the canonical string rebuilt
// from those headers using the shared secret.
func TestGiftCityAuth_SignsAndVerifies(t *testing.T) {
	auth := &giftCityAuth{
		participant: "GIFT-PART-001",
		accessKey:   "AK-123",
		secretKey:   "super-secret",
	}

	req, err := retryablehttp.NewRequest("POST", "https://provider.example/v1/issue?dry=0", nil)
	require.NoError(t, err)

	require.NoError(t, auth.apply(context.Background(), req))

	assert.Equal(t, "AK-123", req.Header.Get("X-GiftCity-Key"))
	assert.Equal(t, "GIFT-PART-001", req.Header.Get("X-GiftCity-Participant"))

	ts := req.Header.Get("X-GiftCity-Timestamp")
	nonce := req.Header.Get("X-GiftCity-Nonce")
	sig := req.Header.Get("X-GiftCity-Signature")
	require.NotEmpty(t, ts)
	require.NotEmpty(t, nonce)
	require.NotEmpty(t, sig)

	// Recompute exactly as a verifying server would.
	want := sign("super-secret", canonicalString("POST", "/v1/issue", "dry=0", ts, nonce, "GIFT-PART-001"))
	assert.Equal(t, want, sig, "signature must verify against the canonical string")

	// A different secret must NOT verify.
	wrong := sign("other-secret", canonicalString("POST", "/v1/issue", "dry=0", ts, nonce, "GIFT-PART-001"))
	assert.NotEqual(t, wrong, sig)
}

// TestGiftCityAuth_NonceChanges ensures each request gets a fresh nonce.
func TestGiftCityAuth_NonceChanges(t *testing.T) {
	auth := &giftCityAuth{participant: "P", accessKey: "K", secretKey: "S"}

	r1, _ := retryablehttp.NewRequest("GET", "https://x/v1/health", nil)
	r2, _ := retryablehttp.NewRequest("GET", "https://x/v1/health", nil)
	require.NoError(t, auth.apply(context.Background(), r1))
	require.NoError(t, auth.apply(context.Background(), r2))

	assert.NotEqual(t, r1.Header.Get("X-GiftCity-Nonce"), r2.Header.Get("X-GiftCity-Nonce"))
}
