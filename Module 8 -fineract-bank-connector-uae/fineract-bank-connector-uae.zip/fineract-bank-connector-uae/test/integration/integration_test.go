//go:build integration

package integration

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/bank-connector-uae/internal/adapters/api"
	"github.com/fineract/bank-connector-uae/internal/adapters/client"
	"github.com/fineract/bank-connector-uae/internal/adapters/repository"
	"github.com/fineract/bank-connector-uae/internal/config"
	"github.com/fineract/bank-connector-uae/internal/service"
	"github.com/fineract/bank-connector-uae/pkg/metrics"
)

const testIBAN = "AE070331234567890123456"

func fakeAlTareq() *httptest.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/open-finance/v1/account-access-consents", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			w.WriteHeader(200)
			return
		}
		writeJSON(w, map[string]any{"consent_id": "CONSENT-1", "status": "AWAITING_AUTHORIZATION", "authorization_url": "https://altareq.example/auth?c=CONSENT-1", "expires_in": 3600})
	})
	// DELETE with an id in the path
	mux.HandleFunc("/open-finance/v1/account-access-consents/", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	mux.HandleFunc("/open-finance/v1/authorizations", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{
			"access_token": "tok-abc", "expires_in": 3600,
			"accounts": []map[string]any{{"account_id": "ACC-1", "iban": testIBAN, "name": "Current", "type": "Current", "currency": "AED"}},
		})
	})
	mux.HandleFunc("/open-finance/v1/accounts/ACC-1/balances", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") == "" {
			w.WriteHeader(401)
			return
		}
		writeJSON(w, map[string]any{"account_id": "ACC-1", "amount": "1234.50", "currency": "AED", "type": "available"})
	})
	mux.HandleFunc("/open-finance/v1/health", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	return httptest.NewServer(mux)
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}

func testServer(t *testing.T, url string) *httptest.Server {
	t.Helper()
	c, err := client.New(config.AlTareqConfig{
		BaseURL: url, AuthMode: "apikey", APIKey: "k", RedirectURL: "https://tpp.example/cb",
		DefaultPermissions: []string{"ReadAccountsBasic", "ReadBalances"}, ConsentTTL: time.Hour,
		Timeout: 2 * time.Second, MaxRetries: 0, BreakerMaxReq: 3, BreakerName: "test",
	})
	require.NoError(t, err)
	svc := service.NewLinking(c, repository.NewMemory(), config.Default().AlTareq, metrics.New(), zap.NewNop())
	return httptest.NewServer(api.NewRouter(api.NewHandler(svc, 1<<20), metrics.New(), zap.NewNop(), 0))
}

func do(t *testing.T, method, url, body string) (int, map[string]any) {
	t.Helper()
	var r io.Reader
	if body != "" {
		r = bytes.NewReader([]byte(body))
	}
	req, _ := http.NewRequest(method, url, r)
	if body != "" {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := http.DefaultClient.Do(req)
	require.NoError(t, err)
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	var m map[string]any
	_ = json.Unmarshal(b, &m)
	return resp.StatusCode, m
}

func TestFullFlow_ConsentLinkBalanceUnlink(t *testing.T) {
	bank := fakeAlTareq()
	defer bank.Close()
	srv := testServer(t, bank.URL)
	defer srv.Close()

	// 1) Create consent.
	code, res := do(t, http.MethodPost, srv.URL+"/api/v1/consents", `{"customer_ref":"CUST-1"}`)
	require.Equal(t, http.StatusCreated, code)
	assert.Equal(t, "CONSENT-1", res["consent_id"])
	assert.NotEmpty(t, res["authorization_url"])

	// 2) Complete linking.
	code, res = do(t, http.MethodPost, srv.URL+"/api/v1/consents/CONSENT-1/link", `{"authorization_code":"code123"}`)
	require.Equal(t, http.StatusOK, code)
	accounts, _ := res["linked_accounts"].([]any)
	require.Len(t, accounts, 1)
	first := accounts[0].(map[string]any)
	masked := first["masked_iban"].(string)
	assert.True(t, strings.HasSuffix(masked, "3456"))
	assert.NotContains(t, masked, "0331234567890")
	linkage := first["linkage_id"].(string)

	// 3) List.
	code, res = do(t, http.MethodGet, srv.URL+"/api/v1/accounts?customer_ref=CUST-1", "")
	require.Equal(t, http.StatusOK, code)
	assert.Len(t, res["accounts"].([]any), 1)

	// 4) Balance.
	code, res = do(t, http.MethodGet, srv.URL+"/api/v1/accounts/"+linkage+"/balance", "")
	require.Equal(t, http.StatusOK, code)
	assert.Equal(t, "1234.50", res["amount"])

	// 5) Unlink.
	code, _ = do(t, http.MethodDelete, srv.URL+"/api/v1/accounts/"+linkage, "")
	require.Equal(t, http.StatusOK, code)

	// 6) Balance after unlink -> conflict.
	code, _ = do(t, http.MethodGet, srv.URL+"/api/v1/accounts/"+linkage+"/balance", "")
	assert.Equal(t, http.StatusConflict, code)
}

func TestCreateConsent_MissingCustomerRef(t *testing.T) {
	bank := fakeAlTareq()
	defer bank.Close()
	srv := testServer(t, bank.URL)
	defer srv.Close()

	code, _ := do(t, http.MethodPost, srv.URL+"/api/v1/consents", `{}`)
	assert.Equal(t, http.StatusBadRequest, code)
}
