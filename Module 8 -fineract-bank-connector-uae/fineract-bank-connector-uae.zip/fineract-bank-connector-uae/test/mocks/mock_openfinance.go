package mocks

import (
	"context"

	"github.com/fineract/bank-connector-uae/internal/ports"
)

// MockOFClient is a configurable test double for ports.OpenFinanceClient.
type MockOFClient struct {
	ConsentResp  ports.ConsentResponse
	ConsentErr   error
	AccountsResp ports.AccountsResponse
	ExchangeErr  error
	BalanceResp  ports.BalanceResponse
	BalanceErr   error
	RevokeErr    error
	HealthErr    error

	Revoked []string
}

var _ ports.OpenFinanceClient = (*MockOFClient)(nil)

func (m *MockOFClient) CreateConsent(_ context.Context, _ ports.CreateConsentRequest) (ports.ConsentResponse, error) {
	return m.ConsentResp, m.ConsentErr
}
func (m *MockOFClient) ExchangeAuthorization(_ context.Context, _ string, _ string) (ports.AccountsResponse, error) {
	return m.AccountsResp, m.ExchangeErr
}
func (m *MockOFClient) GetBalance(_ context.Context, _ string, _ string) (ports.BalanceResponse, error) {
	return m.BalanceResp, m.BalanceErr
}
func (m *MockOFClient) RevokeConsent(_ context.Context, consentID string) error {
	m.Revoked = append(m.Revoked, consentID)
	return m.RevokeErr
}
func (m *MockOFClient) Health(_ context.Context) error { return m.HealthErr }
