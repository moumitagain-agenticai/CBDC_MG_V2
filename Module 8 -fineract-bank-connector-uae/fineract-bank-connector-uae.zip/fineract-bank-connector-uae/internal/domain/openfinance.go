package domain

import "github.com/fineract/bank-connector-uae/pkg/flog"
import (
	"time"

	"github.com/fineract/bank-connector-uae/pkg/utils"
)

// CurrencyAED is the settlement currency for UAE accounts.
const CurrencyAED = "AED"

// DefaultPermissions is the minimal Open Finance permission set for linking.
var DefaultPermissions = []string{"ReadAccountsBasic", "ReadBalances"}

// ConsentStatus is the lifecycle of an account-access consent.
type ConsentStatus string

const (
	ConsentAwaitingAuthorization ConsentStatus = "AWAITING_AUTHORIZATION"
	ConsentAuthorized            ConsentStatus = "AUTHORIZED"
	ConsentRejected              ConsentStatus = "REJECTED"
	ConsentRevoked               ConsentStatus = "REVOKED"
)

// LinkStatus is the lifecycle of a linked account.
type LinkStatus string

const (
	LinkActive   LinkStatus = "ACTIVE"
	LinkUnlinked LinkStatus = "UNLINKED"
)

// Consent is an AlTareq Open Finance account-access consent.
type Consent struct {
	ConsentID        string        `json:"consent_id"`
	CustomerRef      string        `json:"customer_ref"`
	Permissions      []string      `json:"permissions"`
	Status           ConsentStatus `json:"status"`
	AuthorizationURL string        `json:"authorization_url,omitempty"`
	CreatedAt        time.Time     `json:"created_at"`
	ExpiresAt        time.Time     `json:"expires_at,omitempty"`
}

// LinkedAccount is a customer bank account linked via a consent. Only a masked
// IBAN is retained.
type LinkedAccount struct {
	LinkageID   string     `json:"linkage_id"`
	ConsentID   string     `json:"consent_id"`
	CustomerRef string     `json:"customer_ref"`
	AccountID   string     `json:"account_id"` // partner-side account identifier
	AccountName string     `json:"account_name"`
	MaskedIBAN  string     `json:"masked_iban"`
	AccountType string     `json:"account_type"`
	Currency    string     `json:"currency"`
	Status      LinkStatus `json:"status"`
	LinkedAt    time.Time  `json:"linked_at"`
}

// Balance is a point-in-time balance for a linked account.
type Balance struct {
	LinkageID string    `json:"linkage_id"`
	Amount    string    `json:"amount"`
	Currency  string    `json:"currency"`
	Type      string    `json:"type,omitempty"`
	AsOf      time.Time `json:"as_of"`
}

// CreateConsentRequest starts an account-linking flow.
type CreateConsentRequest struct {
	CustomerRef string   `json:"customer_ref"`
	Permissions []string `json:"permissions,omitempty"`
}

// Validate checks the consent request.
func (r CreateConsentRequest) Validate() error {
	if r.CustomerRef == "" {
		return NewValidationError("customer_ref is required", nil)
	}
	return nil
}

// CompleteLinkRequest finishes linking after the customer authorizes the consent.
type CompleteLinkRequest struct {
	ConsentID         string `json:"consent_id"`
	AuthorizationCode string `json:"authorization_code"`
}

// Validate checks the completion request.
func (r CompleteLinkRequest) Validate() error {
	if r.ConsentID == "" {
		return NewValidationError("consent_id is required", nil)
	}
	if r.AuthorizationCode == "" {
		return NewValidationError("authorization_code is required", nil)
	}
	return nil
}

// NewLinkedAccount builds a linked-account record from partner account data,
// masking the IBAN. It validates the IBAN format defensively.
func NewLinkedAccount(linkageID, consentID, customerRef, accountID, name, iban, acctType, currency string, now time.Time) (*LinkedAccount, error) {
	if iban != "" && !utils.IsValidIBAN(iban) {
		return nil, NewUpstreamError("partner returned an invalid IBAN", nil)
	}
	if currency == "" {
		currency = CurrencyAED
	}
	if !utils.IsValidCurrency(currency) {
		return nil, NewUpstreamError("partner returned an invalid currency", nil)
	}
	return &LinkedAccount{
		LinkageID: linkageID, ConsentID: consentID, CustomerRef: customerRef,
		AccountID: accountID, AccountName: name, MaskedIBAN: utils.MaskIBAN(iban),
		AccountType: acctType, Currency: currency, Status: LinkActive, LinkedAt: now,
	}, nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/8_openfinance_Logfile.log at runtime.
var _ = func() bool { flog.For("8_openfinance").Info("source file initialized"); return true }()
