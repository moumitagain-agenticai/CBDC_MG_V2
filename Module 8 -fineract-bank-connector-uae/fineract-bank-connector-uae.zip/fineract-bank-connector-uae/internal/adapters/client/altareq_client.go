package client

import "github.com/fineract/bank-connector-uae/pkg/flog"
import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/hashicorp/go-retryablehttp"
	"github.com/sony/gobreaker"

	"github.com/fineract/bank-connector-uae/internal/config"
	"github.com/fineract/bank-connector-uae/internal/domain"
	"github.com/fineract/bank-connector-uae/internal/ports"
)

// AlTareqClient is the concrete AlTareq Open Finance adapter. It wraps a
// retrying HTTP client with a circuit breaker and pluggable app authentication,
// and caches per-consent access tokens internally (never exposing them).
type AlTareqClient struct {
	baseURL     string
	redirectURL string
	http        *retryablehttp.Client
	breaker     *gobreaker.CircuitBreaker
	auth        authorizer

	mu     sync.Mutex
	tokens map[string]string // consentID -> access token
}

var _ ports.OpenFinanceClient = (*AlTareqClient)(nil)

// New builds an AlTareqClient from configuration.
func New(cfg config.AlTareqConfig) (*AlTareqClient, error) {
	rc := retryablehttp.NewClient()
	rc.RetryMax = cfg.MaxRetries
	rc.HTTPClient.Timeout = cfg.Timeout
	rc.Logger = nil

	cb := gobreaker.NewCircuitBreaker(gobreaker.Settings{
		Name:        cfg.BreakerName,
		MaxRequests: cfg.BreakerMaxReq,
		Interval:    60 * time.Second,
		Timeout:     30 * time.Second,
		ReadyToTrip: func(c gobreaker.Counts) bool { return c.ConsecutiveFailures >= 5 },
	})
	auth, err := newAuthorizer(cfg)
	if err != nil {
		return nil, err
	}
	return &AlTareqClient{
		baseURL:     strings.TrimRight(cfg.BaseURL, "/"),
		redirectURL: cfg.RedirectURL,
		http:        rc,
		breaker:     cb,
		auth:        auth,
		tokens:      make(map[string]string),
	}, nil
}

// ---- wire DTOs ----

type consentReqWire struct {
	Permissions []string `json:"permissions"`
	CustomerRef string   `json:"customer_ref"`
	RedirectURL string   `json:"redirect_url,omitempty"`
}

type consentRespWire struct {
	ConsentID        string `json:"consent_id"`
	Status           string `json:"status"`
	AuthorizationURL string `json:"authorization_url"`
	ExpiresIn        int    `json:"expires_in"`
}

type authReqWire struct {
	ConsentID         string `json:"consent_id"`
	AuthorizationCode string `json:"authorization_code"`
}

type accountWire struct {
	AccountID string `json:"account_id"`
	IBAN      string `json:"iban"`
	Name      string `json:"name"`
	Type      string `json:"type"`
	Currency  string `json:"currency"`
}

type authRespWire struct {
	AccessToken string        `json:"access_token"`
	ExpiresIn   int           `json:"expires_in"`
	Accounts    []accountWire `json:"accounts"`
}

type balanceRespWire struct {
	AccountID string `json:"account_id"`
	Amount    string `json:"amount"`
	Currency  string `json:"currency"`
	Type      string `json:"type"`
}

// ---- OpenFinanceClient methods ----

func (c *AlTareqClient) CreateConsent(ctx context.Context, req ports.CreateConsentRequest) (ports.ConsentResponse, error) {
	perms := req.Permissions
	if len(perms) == 0 {
		perms = domain.DefaultPermissions
	}
	body := consentReqWire{Permissions: perms, CustomerRef: req.CustomerRef, RedirectURL: c.redirectURL}
	var out consentRespWire
	if err := c.do(ctx, http.MethodPost, "/open-finance/v1/account-access-consents", body, &out, ""); err != nil {
		return ports.ConsentResponse{}, err
	}
	return ports.ConsentResponse{
		ConsentID:        out.ConsentID,
		Status:           out.Status,
		AuthorizationURL: out.AuthorizationURL,
		ExpiresInSeconds: out.ExpiresIn,
	}, nil
}

func (c *AlTareqClient) ExchangeAuthorization(ctx context.Context, consentID, authCode string) (ports.AccountsResponse, error) {
	var out authRespWire
	body := authReqWire{ConsentID: consentID, AuthorizationCode: authCode}
	if err := c.do(ctx, http.MethodPost, "/open-finance/v1/authorizations", body, &out, ""); err != nil {
		return ports.AccountsResponse{}, err
	}
	if out.AccessToken != "" {
		c.mu.Lock()
		c.tokens[consentID] = out.AccessToken
		c.mu.Unlock()
	}
	accounts := make([]ports.AccountDTO, 0, len(out.Accounts))
	for _, a := range out.Accounts {
		accounts = append(accounts, ports.AccountDTO{
			AccountID: a.AccountID, IBAN: a.IBAN, Name: a.Name, Type: a.Type, Currency: a.Currency,
		})
	}
	return ports.AccountsResponse{Accounts: accounts}, nil
}

func (c *AlTareqClient) GetBalance(ctx context.Context, consentID, accountID string) (ports.BalanceResponse, error) {
	c.mu.Lock()
	token := c.tokens[consentID]
	c.mu.Unlock()
	if token == "" {
		return ports.BalanceResponse{}, domain.NewUnauthorizedError("no active authorization for this consent; re-link the account", nil)
	}
	var out balanceRespWire
	path := "/open-finance/v1/accounts/" + url.PathEscape(accountID) + "/balances"
	if err := c.do(ctx, http.MethodGet, path, nil, &out, token); err != nil {
		return ports.BalanceResponse{}, err
	}
	return ports.BalanceResponse{AccountID: out.AccountID, Amount: out.Amount, Currency: out.Currency, Type: out.Type}, nil
}

func (c *AlTareqClient) RevokeConsent(ctx context.Context, consentID string) error {
	path := "/open-finance/v1/account-access-consents/" + url.PathEscape(consentID)
	if err := c.do(ctx, http.MethodDelete, path, nil, nil, ""); err != nil {
		return err
	}
	c.mu.Lock()
	delete(c.tokens, consentID)
	c.mu.Unlock()
	return nil
}

func (c *AlTareqClient) Health(ctx context.Context) error {
	return c.do(ctx, http.MethodGet, "/open-finance/v1/health", nil, nil, "")
}

// ---- HTTP plumbing ----

// do executes a call through the breaker. When bearer is non-empty it is used as
// the Authorization header (per-consent); otherwise app-level auth is applied.
func (c *AlTareqClient) do(ctx context.Context, method, path string, body, out any, bearer string) error {
	var payload []byte
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return domain.NewInternalError("marshal request", err)
		}
		payload = b
	}
	_, err := c.breaker.Execute(func() (any, error) {
		return nil, c.roundtrip(ctx, method, path, payload, out, bearer)
	})
	if err == gobreaker.ErrOpenState || err == gobreaker.ErrTooManyRequests {
		return domain.NewCircuitOpenError("altareq circuit open", err)
	}
	return err
}

func (c *AlTareqClient) roundtrip(ctx context.Context, method, path string, payload []byte, out any, bearer string) error {
	var reader io.Reader
	if payload != nil {
		reader = bytes.NewReader(payload)
	}
	req, err := retryablehttp.NewRequestWithContext(ctx, method, c.baseURL+path, reader)
	if err != nil {
		return domain.NewInternalError("build request", err)
	}
	req.Header.Set("Accept", "application/json")
	if payload != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if bearer != "" {
		req.Header.Set("Authorization", "Bearer "+bearer)
	} else if err := c.auth.apply(ctx, req); err != nil {
		return err
	}

	resp, err := c.http.Do(req)
	if err != nil {
		if ctx.Err() == context.DeadlineExceeded {
			return domain.NewTimeoutError("altareq timeout", err)
		}
		return domain.NewUpstreamError("altareq request failed", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode >= 400 {
		return mapHTTPError(resp.StatusCode, respBody)
	}
	if out != nil && len(respBody) > 0 {
		if err := json.Unmarshal(respBody, out); err != nil {
			return domain.NewUpstreamError("decode altareq response", err)
		}
	}
	return nil
}

func mapHTTPError(status int, body []byte) error {
	msg := fmt.Sprintf("altareq returned %d", status)
	if snippet := strings.TrimSpace(string(body)); snippet != "" {
		msg = msg + ": " + snippet
	}
	switch {
	case status == http.StatusUnauthorized, status == http.StatusForbidden:
		return domain.NewUnauthorizedError(msg, nil)
	case status == http.StatusNotFound:
		return domain.NewNotFoundError(msg, nil)
	case status == http.StatusConflict:
		return domain.NewConflictError(msg, nil)
	default:
		return domain.NewUpstreamError(msg, nil)
	}
}

// ---- authentication strategies ----

type authorizer interface {
	apply(ctx context.Context, req *retryablehttp.Request) error
}

func newAuthorizer(cfg config.AlTareqConfig) (authorizer, error) {
	switch cfg.AuthMode {
	case "apikey":
		return &apiKeyAuth{key: cfg.APIKey}, nil
	case "oauth2":
		return &oauthAuth{
			tokenURL:     cfg.OAuthTokenURL,
			clientID:     cfg.ClientID,
			clientSecret: cfg.ClientSecret,
			hc:           &http.Client{Timeout: cfg.Timeout},
		}, nil
	case "mtls":
		return &noopAuth{}, nil
	default:
		return nil, domain.NewInternalError("unsupported auth mode: "+cfg.AuthMode, nil)
	}
}

type noopAuth struct{}

func (noopAuth) apply(context.Context, *retryablehttp.Request) error { return nil }

type apiKeyAuth struct{ key string }

func (a *apiKeyAuth) apply(_ context.Context, req *retryablehttp.Request) error {
	req.Header.Set("X-API-Key", a.key)
	return nil
}

type oauthAuth struct {
	tokenURL     string
	clientID     string
	clientSecret string
	hc           *http.Client

	mu     sync.Mutex
	token  string
	expiry time.Time
}

func (a *oauthAuth) apply(ctx context.Context, req *retryablehttp.Request) error {
	tok, err := a.getToken(ctx)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+tok)
	return nil
}

func (a *oauthAuth) getToken(ctx context.Context) (string, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.token != "" && time.Now().Before(a.expiry) {
		return a.token, nil
	}
	form := url.Values{}
	form.Set("grant_type", "client_credentials")
	form.Set("client_id", a.clientID)
	form.Set("client_secret", a.clientSecret)

	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, a.tokenURL, strings.NewReader(form.Encode()))
	if err != nil {
		return "", domain.NewInternalError("build token request", err)
	}
	httpReq.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := a.hc.Do(httpReq)
	if err != nil {
		return "", domain.NewUpstreamError("oauth token request failed", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return "", domain.NewUnauthorizedError(fmt.Sprintf("oauth token endpoint returned %d", resp.StatusCode), nil)
	}
	var tr struct {
		AccessToken string `json:"access_token"`
		ExpiresIn   int    `json:"expires_in"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tr); err != nil {
		return "", domain.NewUpstreamError("decode oauth token", err)
	}
	if tr.AccessToken == "" {
		return "", domain.NewUnauthorizedError("empty access token from oauth endpoint", nil)
	}
	a.token = tr.AccessToken
	ttl := time.Duration(tr.ExpiresIn) * time.Second
	if ttl <= 0 {
		ttl = 5 * time.Minute
	}
	a.expiry = time.Now().Add(ttl - 30*time.Second)
	return a.token, nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/8_altareq_client_Logfile.log at runtime.
var _ = func() bool { flog.For("8_altareq_client").Info("source file initialized"); return true }()
