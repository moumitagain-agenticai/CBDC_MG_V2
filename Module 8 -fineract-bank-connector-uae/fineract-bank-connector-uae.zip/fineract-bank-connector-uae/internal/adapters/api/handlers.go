package api

import "github.com/fineract/bank-connector-uae/pkg/flog"
import (
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"

	"github.com/fineract/bank-connector-uae/internal/domain"
	"github.com/fineract/bank-connector-uae/internal/service"
)

// Handler exposes the Open Finance connector over HTTP.
type Handler struct {
	svc      *service.Linking
	maxBytes int64
}

// NewHandler builds an HTTP handler around the linking service.
func NewHandler(svc *service.Linking, maxBytes int64) *Handler {
	if maxBytes <= 0 {
		maxBytes = 1 << 20
	}
	return &Handler{svc: svc, maxBytes: maxBytes}
}

// CreateConsent handles POST /api/v1/consents.
func (h *Handler) CreateConsent(w http.ResponseWriter, r *http.Request) {
	var req domain.CreateConsentRequest
	if !decodeJSON(w, r, h.maxBytes, &req) {
		return
	}
	res, err := h.svc.CreateConsent(r.Context(), req)
	respond(w, http.StatusCreated, res, err)
}

// GetConsent handles GET /api/v1/consents/{consent_id}.
func (h *Handler) GetConsent(w http.ResponseWriter, r *http.Request) {
	res, err := h.svc.GetConsent(r.Context(), chi.URLParam(r, "consent_id"))
	respond(w, http.StatusOK, res, err)
}

// CompleteLinking handles POST /api/v1/consents/{consent_id}/link.
func (h *Handler) CompleteLinking(w http.ResponseWriter, r *http.Request) {
	var body struct {
		AuthorizationCode string `json:"authorization_code"`
	}
	if !decodeJSON(w, r, h.maxBytes, &body) {
		return
	}
	req := domain.CompleteLinkRequest{ConsentID: chi.URLParam(r, "consent_id"), AuthorizationCode: body.AuthorizationCode}
	res, err := h.svc.CompleteLinking(r.Context(), req)
	if err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"linked_accounts": res})
}

// ListAccounts handles GET /api/v1/accounts?customer_ref=...
func (h *Handler) ListAccounts(w http.ResponseWriter, r *http.Request) {
	res, err := h.svc.ListLinkedAccounts(r.Context(), r.URL.Query().Get("customer_ref"))
	if err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"accounts": res})
}

// GetBalance handles GET /api/v1/accounts/{linkage_id}/balance.
func (h *Handler) GetBalance(w http.ResponseWriter, r *http.Request) {
	res, err := h.svc.GetBalance(r.Context(), chi.URLParam(r, "linkage_id"))
	respond(w, http.StatusOK, res, err)
}

// Unlink handles DELETE /api/v1/accounts/{linkage_id}.
func (h *Handler) Unlink(w http.ResponseWriter, r *http.Request) {
	if err := h.svc.Unlink(r.Context(), chi.URLParam(r, "linkage_id")); err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"status": "UNLINKED"})
}

func (h *Handler) Liveness(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, h.svc.Liveness())
}

func (h *Handler) Readiness(w http.ResponseWriter, r *http.Request) {
	rep := h.svc.Readiness(r.Context())
	status := http.StatusOK
	if rep.Status != "ok" {
		status = http.StatusServiceUnavailable
	}
	writeJSON(w, status, rep)
}

// ---- helpers ----

func decodeJSON(w http.ResponseWriter, r *http.Request, max int64, dst any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, max)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		writeError(w, domain.NewValidationError("invalid JSON body", err))
		return false
	}
	return true
}

func respond(w http.ResponseWriter, status int, payload any, err error) {
	if err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, status, payload)
}

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if payload != nil {
		_ = json.NewEncoder(w).Encode(payload)
	}
}

type errorBody struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, err error) {
	de := domain.AsDomainError(err)
	var body errorBody
	body.Error.Code = string(de.Code)
	body.Error.Message = de.Message
	writeJSON(w, httpStatus(de.Code), body)
}

func httpStatus(code domain.ErrorCode) int {
	switch code {
	case domain.CodeValidation:
		return http.StatusBadRequest
	case domain.CodeNotFound:
		return http.StatusNotFound
	case domain.CodeConflict:
		return http.StatusConflict
	case domain.CodeUnauthorized:
		return http.StatusUnauthorized
	case domain.CodeTimeout:
		return http.StatusGatewayTimeout
	case domain.CodeUpstream, domain.CodeCircuitOpen:
		return http.StatusBadGateway
	default:
		return http.StatusInternalServerError
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/8_handlers_Logfile.log at runtime.
var _ = func() bool { flog.For("8_handlers").Info("source file initialized"); return true }()
