package service

import "github.com/fineract/bank-connector-uae/pkg/flog"
import "context"

// HealthReport is the aggregated health of the connector.
type HealthReport struct {
	Status string            `json:"status"`
	Checks map[string]string `json:"checks"`
}

// Liveness reports process health with no I/O.
func (l *Linking) Liveness() HealthReport {
	return HealthReport{Status: "ok", Checks: map[string]string{"process": "ok"}}
}

// Readiness reports whether the connector can serve traffic: AlTareq must be
// reachable and the repository must respond.
func (l *Linking) Readiness(ctx context.Context) HealthReport {
	checks := map[string]string{}
	status := "ok"

	if err := l.client.Health(ctx); err != nil {
		checks["altareq"] = "error: " + err.Error()
		status = "degraded"
	} else {
		checks["altareq"] = "ok"
	}
	if err := l.repo.Ping(ctx); err != nil {
		checks["repository"] = "error: " + err.Error()
		status = "degraded"
	} else {
		checks["repository"] = "ok"
	}
	return HealthReport{Status: status, Checks: checks}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/8_health_Logfile.log at runtime.
var _ = func() bool { flog.For("8_health").Info("source file initialized"); return true }()
