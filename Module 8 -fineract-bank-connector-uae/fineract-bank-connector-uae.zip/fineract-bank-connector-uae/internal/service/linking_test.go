package service_test

import (
	"context"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/bank-connector-uae/internal/adapters/repository"
	"github.com/fineract/bank-connector-uae/internal/config"
	"github.com/fineract/bank-connector-uae/internal/domain"
	"github.com/fineract/bank-connector-uae/internal/ports"
	"github.com/fineract/bank-connector-uae/internal/service"
	"github.com/fineract/bank-connector-uae/pkg/metrics"
	"github.com/fineract/bank-connector-uae/test/mocks"
)

// A valid UAE IBAN (mod-97 correct).
const testIBAN = "AE070331234567890123456"

func newSvc(client ports.OpenFinanceClient) (*service.Linking, *repository.MemoryRepository) {
	repo := repository.NewMemory()
	cfg := config.Default().AlTareq
	return service.NewLinking(client, repo, cfg, metrics.New(), zap.NewNop()), repo
}

func TestCreateConsent_ReturnsAuthURL(t *testing.T) {
	client := &mocks.MockOFClient{ConsentResp: ports.ConsentResponse{
		ConsentID: "CONSENT-1", Status: "AWAITING_AUTHORIZATION", AuthorizationURL: "https://altareq.example/auth?c=CONSENT-1", ExpiresInSeconds: 3600,
	}}
	svc, repo := newSvc(client)

	c, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{CustomerRef: "CUST-1"})
	require.NoError(t, err)
	assert.Equal(t, "CONSENT-1", c.ConsentID)
	assert.Equal(t, domain.ConsentAwaitingAuthorization, c.Status)
	assert.NotEmpty(t, c.AuthorizationURL)

	stored, err := repo.GetConsent(context.Background(), "CONSENT-1")
	require.NoError(t, err)
	assert.Equal(t, "CUST-1", stored.CustomerRef)
}

func TestCreateConsent_MissingCustomerRef(t *testing.T) {
	svc, _ := newSvc(&mocks.MockOFClient{})
	_, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{})
	require.Error(t, err)
	assert.Equal(t, domain.CodeValidation, domain.AsDomainError(err).Code)
}

func TestCompleteLinking_MasksIBANAndAuthorizes(t *testing.T) {
	client := &mocks.MockOFClient{
		ConsentResp:  ports.ConsentResponse{ConsentID: "CONSENT-1", Status: "AWAITING_AUTHORIZATION"},
		AccountsResp: ports.AccountsResponse{Accounts: []ports.AccountDTO{{AccountID: "ACC-1", IBAN: testIBAN, Name: "Current", Type: "Current", Currency: "AED"}}},
	}
	svc, repo := newSvc(client)

	_, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{CustomerRef: "CUST-1"})
	require.NoError(t, err)

	accts, err := svc.CompleteLinking(context.Background(), domain.CompleteLinkRequest{ConsentID: "CONSENT-1", AuthorizationCode: "code123"})
	require.NoError(t, err)
	require.Len(t, accts, 1)
	assert.True(t, strings.HasSuffix(accts[0].MaskedIBAN, "3456"))
	assert.True(t, strings.HasPrefix(accts[0].MaskedIBAN, "****"))
	assert.NotContains(t, accts[0].MaskedIBAN, "0331234567890")
	assert.Equal(t, domain.LinkActive, accts[0].Status)

	c, _ := repo.GetConsent(context.Background(), "CONSENT-1")
	assert.Equal(t, domain.ConsentAuthorized, c.Status)
}

func TestFullFlow_ListBalanceUnlink(t *testing.T) {
	client := &mocks.MockOFClient{
		ConsentResp:  ports.ConsentResponse{ConsentID: "CONSENT-1"},
		AccountsResp: ports.AccountsResponse{Accounts: []ports.AccountDTO{{AccountID: "ACC-1", IBAN: testIBAN, Name: "Current", Type: "Current", Currency: "AED"}}},
		BalanceResp:  ports.BalanceResponse{AccountID: "ACC-1", Amount: "1234.50", Currency: "AED", Type: "available"},
	}
	svc, _ := newSvc(client)

	_, err := svc.CreateConsent(context.Background(), domain.CreateConsentRequest{CustomerRef: "CUST-1"})
	require.NoError(t, err)
	accts, err := svc.CompleteLinking(context.Background(), domain.CompleteLinkRequest{ConsentID: "CONSENT-1", AuthorizationCode: "code123"})
	require.NoError(t, err)
	linkage := accts[0].LinkageID

	// List
	list, err := svc.ListLinkedAccounts(context.Background(), "CUST-1")
	require.NoError(t, err)
	assert.Len(t, list, 1)

	// Balance
	bal, err := svc.GetBalance(context.Background(), linkage)
	require.NoError(t, err)
	assert.Equal(t, "1234.50", bal.Amount)
	assert.Equal(t, "AED", bal.Currency)

	// Unlink
	require.NoError(t, svc.Unlink(context.Background(), linkage))
	assert.Contains(t, client.Revoked, "CONSENT-1")

	// Balance after unlink -> conflict
	_, err = svc.GetBalance(context.Background(), linkage)
	require.Error(t, err)
	assert.Equal(t, domain.CodeConflict, domain.AsDomainError(err).Code)
}

func TestCompleteLinking_UnknownConsent(t *testing.T) {
	svc, _ := newSvc(&mocks.MockOFClient{})
	_, err := svc.CompleteLinking(context.Background(), domain.CompleteLinkRequest{ConsentID: "NOPE", AuthorizationCode: "x"})
	require.Error(t, err)
	assert.Equal(t, domain.CodeNotFound, domain.AsDomainError(err).Code)
}
