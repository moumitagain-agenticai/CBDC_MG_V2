package service

import "github.com/fineract/bank-connector-uae/pkg/flog"
import (
	"context"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	"github.com/fineract/bank-connector-uae/internal/config"
	"github.com/fineract/bank-connector-uae/internal/domain"
	"github.com/fineract/bank-connector-uae/internal/ports"
	"github.com/fineract/bank-connector-uae/pkg/metrics"
)

// Linking orchestrates the AlTareq Open Finance account-linking flow: create a
// consent, complete linking after authorization, then list accounts, read
// balances and unlink. Only masked account data is stored.
type Linking struct {
	client  ports.OpenFinanceClient
	repo    ports.LinkRepository
	cfg     config.AlTareqConfig
	metrics *metrics.Metrics
	log     *zap.Logger
}

// NewLinking wires the service. repo is always non-nil (in-memory or Postgres).
func NewLinking(c ports.OpenFinanceClient, repo ports.LinkRepository, cfg config.AlTareqConfig, m *metrics.Metrics, log *zap.Logger) *Linking {
	return &Linking{client: c, repo: repo, cfg: cfg, metrics: m, log: log}
}

// CreateConsent starts account linking and returns the authorization URL.
func (l *Linking) CreateConsent(ctx context.Context, req domain.CreateConsentRequest) (*domain.Consent, error) {
	defer l.observe("create_consent")()
	if err := req.Validate(); err != nil {
		return nil, l.fail("create_consent", err)
	}
	perms := req.Permissions
	if len(perms) == 0 {
		perms = l.cfg.DefaultPermissions
	}

	resp, err := l.client.CreateConsent(ctx, ports.CreateConsentRequest{CustomerRef: req.CustomerRef, Permissions: perms})
	if err != nil {
		return nil, l.fail("create_consent", err)
	}

	now := time.Now().UTC()
	expires := now.Add(l.cfg.ConsentTTL)
	if resp.ExpiresInSeconds > 0 {
		expires = now.Add(time.Duration(resp.ExpiresInSeconds) * time.Second)
	}
	c := &domain.Consent{
		ConsentID: resp.ConsentID, CustomerRef: req.CustomerRef, Permissions: perms,
		Status: consentStatus(resp.Status), AuthorizationURL: resp.AuthorizationURL,
		CreatedAt: now, ExpiresAt: expires,
	}
	if err := l.repo.SaveConsent(ctx, c); err != nil {
		return nil, l.fail("create_consent", err)
	}
	l.metrics.OpsTotal.WithLabelValues("create_consent", string(c.Status)).Inc()
	return c, nil
}

// CompleteLinking exchanges the authorization code and links the accounts.
func (l *Linking) CompleteLinking(ctx context.Context, req domain.CompleteLinkRequest) ([]domain.LinkedAccount, error) {
	defer l.observe("complete_linking")()
	if err := req.Validate(); err != nil {
		return nil, l.fail("complete_linking", err)
	}

	consent, err := l.repo.GetConsent(ctx, req.ConsentID)
	if err != nil {
		return nil, l.fail("complete_linking", err)
	}

	resp, err := l.client.ExchangeAuthorization(ctx, req.ConsentID, req.AuthorizationCode)
	if err != nil {
		return nil, l.fail("complete_linking", err)
	}

	now := time.Now().UTC()
	linked := make([]domain.LinkedAccount, 0, len(resp.Accounts))
	for _, a := range resp.Accounts {
		acct, err := domain.NewLinkedAccount(uuid.NewString(), req.ConsentID, consent.CustomerRef, a.AccountID, a.Name, a.IBAN, a.Type, a.Currency, now)
		if err != nil {
			return nil, l.fail("complete_linking", err)
		}
		if err := l.repo.SaveLinkedAccount(ctx, acct); err != nil {
			return nil, l.fail("complete_linking", err)
		}
		linked = append(linked, *acct)
	}

	if err := l.repo.UpdateConsentStatus(ctx, req.ConsentID, domain.ConsentAuthorized); err != nil {
		l.log.Error("failed to mark consent authorized", zap.Error(err))
	}
	l.metrics.OpsTotal.WithLabelValues("complete_linking", string(domain.ConsentAuthorized)).Inc()
	return linked, nil
}

// GetConsent returns a consent's current status.
func (l *Linking) GetConsent(ctx context.Context, consentID string) (*domain.Consent, error) {
	defer l.observe("get_consent")()
	c, err := l.repo.GetConsent(ctx, consentID)
	if err != nil {
		return nil, l.fail("get_consent", err)
	}
	return c, nil
}

// ListLinkedAccounts returns a customer's linked accounts (masked).
func (l *Linking) ListLinkedAccounts(ctx context.Context, customerRef string) ([]domain.LinkedAccount, error) {
	defer l.observe("list_accounts")()
	if customerRef == "" {
		return nil, l.fail("list_accounts", domain.NewValidationError("customer_ref is required", nil))
	}
	accts, err := l.repo.ListLinkedAccounts(ctx, customerRef)
	if err != nil {
		return nil, l.fail("list_accounts", err)
	}
	return accts, nil
}

// GetBalance reads a balance for a linked account.
func (l *Linking) GetBalance(ctx context.Context, linkageID string) (*domain.Balance, error) {
	defer l.observe("get_balance")()
	acct, err := l.repo.GetLinkedAccount(ctx, linkageID)
	if err != nil {
		return nil, l.fail("get_balance", err)
	}
	if acct.Status != domain.LinkActive {
		return nil, l.fail("get_balance", domain.NewConflictError("account is not active", nil))
	}

	resp, err := l.client.GetBalance(ctx, acct.ConsentID, acct.AccountID)
	if err != nil {
		return nil, l.fail("get_balance", err)
	}
	currency := resp.Currency
	if currency == "" {
		currency = acct.Currency
	}
	l.metrics.OpsTotal.WithLabelValues("get_balance", "ok").Inc()
	return &domain.Balance{LinkageID: linkageID, Amount: resp.Amount, Currency: currency, Type: resp.Type, AsOf: time.Now().UTC()}, nil
}

// Unlink revokes the consent and marks the account unlinked.
func (l *Linking) Unlink(ctx context.Context, linkageID string) error {
	defer l.observe("unlink")()
	acct, err := l.repo.GetLinkedAccount(ctx, linkageID)
	if err != nil {
		return l.fail("unlink", err)
	}
	if err := l.client.RevokeConsent(ctx, acct.ConsentID); err != nil {
		return l.fail("unlink", err)
	}
	if err := l.repo.UpdateLinkedAccountStatus(ctx, linkageID, domain.LinkUnlinked); err != nil {
		return l.fail("unlink", err)
	}
	_ = l.repo.UpdateConsentStatus(ctx, acct.ConsentID, domain.ConsentRevoked)
	l.metrics.OpsTotal.WithLabelValues("unlink", string(domain.LinkUnlinked)).Inc()
	return nil
}

// ---- helpers ----

func (l *Linking) observe(op string) func() {
	start := time.Now()
	return func() { l.metrics.OpDuration.WithLabelValues(op).Observe(time.Since(start).Seconds()) }
}

func (l *Linking) fail(op string, err error) error {
	de := domain.AsDomainError(err)
	l.metrics.OpErrorsTotal.WithLabelValues(op, string(de.Code)).Inc()
	l.log.Warn("open finance operation failed", zap.String("op", op), zap.String("code", string(de.Code)), zap.Error(err))
	return de
}

func consentStatus(s string) domain.ConsentStatus {
	switch domain.ConsentStatus(s) {
	case domain.ConsentAuthorized, domain.ConsentRejected, domain.ConsentRevoked:
		return domain.ConsentStatus(s)
	default:
		return domain.ConsentAwaitingAuthorization
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/8_linking_Logfile.log at runtime.
var _ = func() bool { flog.For("8_linking").Info("source file initialized"); return true }()
