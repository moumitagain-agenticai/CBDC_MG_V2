# fineract-bank-connector-uae

Module 8 of the E1 Cross-Border CBDC platform. It is the **UAE partner-bank
bridge**, built on **AlTareq Open Finance**. Its job is **account linking**: with
the customer's consent it links their UAE bank account, then lets the platform
list accounts, read balances, and unlink again.

It builds and runs stand-alone and follows the same convention as the other
modules (hexagonal layout, resilient upstream client with retry + circuit
breaker, Go migration runner, Prometheus metrics, graceful shutdown).

## Security first

Linking an account produces an **access token** at AlTareq. That token stays
**inside the connector's AlTareq client**, cached per consent — it is never
returned to callers, never logged, and never written to the database. The only
account data retained is a **masked IBAN** (last four characters), e.g.
`*******************3456`.

## The account-linking flow

Open Finance is consent-driven, so linking happens in stages:

```
1. POST /api/v1/consents                     -> consent_id + authorization_url
2. (customer visits authorization_url and approves, out of band)
3. POST /api/v1/consents/{id}/link           -> linked accounts (masked IBANs)
4. GET  /api/v1/accounts?customer_ref=...     -> list linked accounts
   GET  /api/v1/accounts/{linkage_id}/balance -> balance
   DELETE /api/v1/accounts/{linkage_id}        -> unlink (revoke consent)
```

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/v1/consents` | Create an account-access consent (returns `authorization_url`) |
| GET | `/api/v1/consents/{consent_id}` | Consent status |
| POST | `/api/v1/consents/{consent_id}/link` | Complete linking with the authorization code |
| GET | `/api/v1/accounts?customer_ref=...` | List linked accounts (masked) |
| GET | `/api/v1/accounts/{linkage_id}/balance` | Account balance |
| DELETE | `/api/v1/accounts/{linkage_id}` | Unlink / revoke consent |
| GET | `/healthz` / `/readyz` | Liveness / readiness (readiness pings AlTareq) |
| GET | `/metrics` | Prometheus metrics |

## Consent lifecycle

`AWAITING_AUTHORIZATION` → (customer authorizes, code exchanged) → `AUTHORIZED`
→ (unlink) → `REVOKED`. Linked accounts are `ACTIVE` until unlinked, then
`UNLINKED`. Reading a balance for a non-active account returns `409 Conflict`.

## Architecture

Hexagonal (ports & adapters):

```
cmd/server            entrypoint: config load, DI wiring, graceful shutdown
internal/domain       consent/linked-account/balance types, statuses, validation
internal/ports        interfaces (OpenFinanceClient, LinkRepository)
internal/service      linking: consent -> exchange -> link -> list/balance/unlink
internal/adapters/
  api                 chi router, handlers (body size limits), middleware
  client              AlTareq Open Finance client (retry + circuit breaker; auth
                      modes apikey|oauth2|mtls; per-consent token cache)
  repository          in-memory + PostgreSQL LinkRepository, migration runner
internal/config       YAML + env config, validated fail-fast on startup
pkg/logger            zap structured logging (never logs tokens)
pkg/metrics           Prometheus metrics on a private registry
pkg/utils             IBAN (mod-97 + UAE format) validation, IBAN masking
```

## Storage: works out of the box

Account linking needs to remember consents and linkages, so the connector
**always has a working repository**:

- **No database configured** → an **in-memory** store is used automatically. The
  full flow works immediately; state is process-local and not durable across
  restarts.
- **`DATABASE_DSN` set** → a **PostgreSQL** store is used; the connector runs
  pending migrations on startup.

## Resilience

The AlTareq client wraps every call in a timeout, retry-with-backoff
(`go-retryablehttp`) and a circuit breaker (`gobreaker`). Upstream failures map
to typed domain errors and a stable HTTP status (`502` upstream/circuit, `504`
timeout, `401` auth).

## Quick start

```bash
cp .env.example .env    # set ALTAREQ_BASE_URL, ALTAREQ_API_KEY, ALTAREQ_REDIRECT_URL
make run

# 1) create a consent
curl -X POST localhost:8080/api/v1/consents -H 'Content-Type: application/json' \
  -d '{"customer_ref":"CUST-1"}'
# 2) after the customer authorises, complete linking
curl -X POST localhost:8080/api/v1/consents/CONSENT-1/link -H 'Content-Type: application/json' \
  -d '{"authorization_code":"<code>"}'
```

## Configuration

| Env | Meaning |
|-----|---------|
| `SERVER_PORT` | HTTP port (default 8080) |
| `ALTAREQ_BASE_URL` | AlTareq Open Finance API base URL |
| `ALTAREQ_AUTH_MODE` | `apikey` \| `oauth2` \| `mtls` (app-level auth) |
| `ALTAREQ_API_KEY` | API key (auth_mode=apikey) |
| `ALTAREQ_OAUTH_TOKEN_URL` / `ALTAREQ_CLIENT_ID` / `ALTAREQ_CLIENT_SECRET` | OAuth2 client-credentials |
| `ALTAREQ_REDIRECT_URL` | Redirect URL embedded in the consent |
| `ALTAREQ_PERMISSIONS` | Comma-separated default permissions |
| `DATABASE_DSN` | Postgres DSN; setting it enables durable storage |
| `LOG_LEVEL` | `debug` \| `info` \| `warn` \| `error` |

The server **fails fast** on startup if the AlTareq base URL or the selected
auth mode's credentials are missing.

## Database migrations

When `DATABASE_DSN` is set the connector **runs pending migrations on startup**
(tracked in `schema_migrations`). Migrations are defined in Go
(`internal/adapters/repository/migration.go`); `migrations/001_init.sql` is
provided as a reference. Roll back with `go run ./cmd/server -rollback 1`.

## Building `go.sum`

The repository ships a clean `go.mod` without a `go.sum`; run `go mod tidy`
(or `make deps`) once with network access to generate it.

## Per-source-file logging (Logrus)

In addition to the primary structured logger (zap, used for console/DI logging),
this module ships a **Logrus** per-source-file logger in `pkg/flog`. Every source
file writes its own log file under `logs/`, named `8_<file>.log`
(module number + source file name), e.g. `8_main.log`,
`8_config.log`. Each file registers itself with the logger, and a
Logrus hook routes entries to the matching file (JSON formatted). The `logs/`
directory is created on startup and is git-ignored. `go.sum` for the added
`github.com/sirupsen/logrus` dependency is generated on first `go mod tidy`.
