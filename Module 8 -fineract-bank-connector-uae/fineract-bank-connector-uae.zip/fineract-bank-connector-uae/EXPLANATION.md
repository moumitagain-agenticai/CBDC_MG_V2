# EXPLANATION — fineract-bank-connector-uae (plain language)

This document explains the module in simple terms, for reviewers who are not Go
engineers.

## What is this module for?

For the UAE side of the platform, we need to connect to customers' real bank
accounts at a partner bank. The UAE has a national **Open Finance** framework
called **AlTareq** that makes this possible in a safe, consent-based way. This
module is the bridge to it. Its main job is **account linking**: with the
customer's permission, connect their bank account so the platform can see the
account and its balance.

## What is "account linking" and why the extra steps?

You cannot just read someone's bank account. The customer has to agree first.
Open Finance formalises that agreement as a **consent**. So linking happens in a
few steps:

1. **Create a consent.** We ask AlTareq to register that "this customer wants to
   let us see their accounts". AlTareq gives us back a link (an
   "authorization URL").
2. **The customer approves.** They open that link and log in to their bank to
   approve — this happens on the bank's own screens, not ours.
3. **Finish linking.** The bank hands back an "authorization code". We exchange
   that code with AlTareq, which returns the customer's account(s). We save them
   (masked) as **linked accounts**.

Once linked, we can **list** the accounts, check a **balance**, or **unlink**
(which withdraws the consent).

## The most important design choice: protect the access token

When linking succeeds, AlTareq gives us an **access token** — a key that can read
the account. This token is sensitive. The module keeps it **locked inside the
part that talks to AlTareq**, remembered per consent. It is **never** sent back
to whoever called us, never written to logs, and never saved in the database.
When we need a balance, that internal part uses the token itself; the rest of the
system never sees it. And when an account is unlinked, the token is thrown away.

We also **mask the IBAN** (the account number). Only the last four characters are
ever stored or shown — for example `*******************3456`. (This is verified by
the tests, which confirm the raw IBAN never appears in a linked account.)

## Works immediately, with or without a database

Linking has to remember things (which consents exist, which accounts are linked).
So the module always keeps that memory:

- If you don't configure a database, it keeps everything **in memory** — the
  whole flow works straight away, but the memory is wiped if the service
  restarts.
- If you configure a database, it uses **PostgreSQL** so the records survive
  restarts.

## Coping when AlTareq is slow or down

Every call to AlTareq is wrapped in safety mechanisms: a **timeout** (don't wait
forever), **automatic retries** for brief blips, and a **circuit breaker** that
stops hammering AlTareq if it is clearly down and fails fast instead. Callers
always get a clear, typed error rather than a hang.

## The features, in one line each

- **Consent-based linking**: nothing is read without the customer's approval.
- **Token protection**: access tokens never leave the connector, never logged, never stored.
- **IBAN masking**: only the last four characters are ever kept or shown.
- **Lifecycle**: consents move Awaiting → Authorized → Revoked; accounts Active → Unlinked.
- **Safe balance reads**: a balance can only be read for an active link (else a clear conflict).
- **Works out of the box**: in-memory storage by default, Postgres when configured.
- **Circuit breaker + retries**: shrug off blips, fail over fast on outages.
- **Graceful shutdown**: on stop, in-flight requests finish before exit.

## What was verified

`go build ./...`, `go vet ./...`, unit tests (create consent returns an
authorization URL; missing customer reference is rejected; completing a link
masks the IBAN and marks the consent authorized; the full list → balance →
unlink flow works and a balance read after unlink is refused; unknown consent is
a not-found) and integration tests (the full create → link → list → balance →
unlink flow over a real HTTP AlTareq, asserting the masked IBAN and the
post-unlink conflict) all pass.
