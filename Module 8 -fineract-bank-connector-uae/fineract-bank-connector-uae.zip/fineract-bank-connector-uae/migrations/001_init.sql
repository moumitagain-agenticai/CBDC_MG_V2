-- fineract-bank-connector-uae: Open Finance consent + linked-account state.
-- Stores only masked, non-sensitive data (masked IBAN). Never access tokens.
-- Apply with: psql "$DATABASE_DSN" -f migrations/001_init.sql

CREATE TABLE IF NOT EXISTS of_consents (
    consent_id   TEXT PRIMARY KEY,
    customer_ref TEXT        NOT NULL,
    permissions  TEXT        NOT NULL DEFAULT '',
    status       TEXT        NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL,
    expires_at   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_of_consents_customer ON of_consents (customer_ref);

CREATE TABLE IF NOT EXISTS linked_accounts (
    linkage_id   TEXT PRIMARY KEY,
    consent_id   TEXT        NOT NULL,
    customer_ref TEXT        NOT NULL,
    account_id   TEXT        NOT NULL,
    account_name TEXT        NOT NULL DEFAULT '',
    masked_iban  TEXT        NOT NULL DEFAULT '',
    account_type TEXT        NOT NULL DEFAULT '',
    currency     TEXT        NOT NULL DEFAULT 'AED',
    status       TEXT        NOT NULL,
    linked_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_linked_accounts_customer ON linked_accounts (customer_ref);
CREATE UNIQUE INDEX IF NOT EXISTS idx_linked_accounts_consent_account
    ON linked_accounts (consent_id, account_id);
