package utils

import "testing"

func TestIsValidIBAN(t *testing.T) {
	valid := []string{"AE070331234567890123456", "DE89370400440532013000", "GB29NWBK60161331926819"}
	for _, s := range valid {
		if !IsValidIBAN(s) {
			t.Errorf("expected %s to be valid", s)
		}
	}
	invalid := []string{"AE000331234567890123456", "DE00370400440532013000", "notaniban", "AE07033123456789012345"}
	for _, s := range invalid {
		if IsValidIBAN(s) {
			t.Errorf("expected %s to be invalid", s)
		}
	}
}

func TestIsValidUAEIBAN(t *testing.T) {
	if !IsValidUAEIBAN("AE070331234567890123456") {
		t.Error("expected valid UAE IBAN")
	}
	if IsValidUAEIBAN("DE89370400440532013000") {
		t.Error("German IBAN should not pass the UAE-specific check")
	}
}

func TestMaskIBAN(t *testing.T) {
	got := MaskIBAN("AE070331234567890123456")
	if got[len(got)-4:] != "3456" {
		t.Errorf("expected suffix 3456, got %s", got)
	}
	for i := 0; i < len(got)-4; i++ {
		if got[i] != '*' {
			t.Errorf("expected masked prefix, got %s", got)
			break
		}
	}
}
