package utils

import "github.com/fineract/bank-connector-uae/pkg/flog"
import (
	"math/big"
	"regexp"
	"strings"
)

var (
	uaeIbanRe = regexp.MustCompile(`^AE[0-9]{2}[0-9]{3}[0-9]{16}$`) // AE + 2 check + 3 bank + 16 account = 23
	ibanRe    = regexp.MustCompile(`^[A-Z]{2}[0-9]{2}[A-Z0-9]{1,30}$`)
	currRe    = regexp.MustCompile(`^[A-Z]{3}$`)
)

// IsValidCurrency reports whether s is a syntactically valid ISO 4217 code.
func IsValidCurrency(s string) bool { return currRe.MatchString(strings.TrimSpace(s)) }

// IsValidIBAN validates an IBAN with the ISO 13616 mod-97 checksum.
func IsValidIBAN(iban string) bool {
	s := strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(iban), " ", ""))
	if !ibanRe.MatchString(s) || len(s) < 15 || len(s) > 34 {
		return false
	}
	// Move the first four chars to the end, then convert letters to numbers.
	rearranged := s[4:] + s[:4]
	var sb strings.Builder
	for _, r := range rearranged {
		switch {
		case r >= '0' && r <= '9':
			sb.WriteRune(r)
		case r >= 'A' && r <= 'Z':
			sb.WriteString(bigDigit(r))
		default:
			return false
		}
	}
	n, ok := new(big.Int).SetString(sb.String(), 10)
	if !ok {
		return false
	}
	return n.Mod(n, big.NewInt(97)).Int64() == 1
}

// IsValidUAEIBAN additionally enforces the 23-character UAE account structure.
func IsValidUAEIBAN(iban string) bool {
	s := strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(iban), " ", ""))
	return uaeIbanRe.MatchString(s) && IsValidIBAN(s)
}

func bigDigit(r rune) string {
	// A=10 ... Z=35
	v := int(r-'A') + 10
	return itoa(v)
}

func itoa(v int) string {
	if v < 10 {
		return string(rune('0' + v))
	}
	return string(rune('0'+v/10)) + string(rune('0'+v%10))
}

// MaskIBAN keeps only the last four characters, e.g. "AE****...****1234".
func MaskIBAN(iban string) string {
	s := strings.ReplaceAll(strings.TrimSpace(iban), " ", "")
	if len(s) < 4 {
		return "****"
	}
	return strings.Repeat("*", len(s)-4) + s[len(s)-4:]
}

// IsPositiveOrZeroAmount reports whether s parses as a decimal ≥ 0.
func IsPositiveOrZeroAmount(s string) bool {
	r, ok := new(big.Rat).SetString(strings.TrimSpace(s))
	return ok && r.Sign() >= 0
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/8_validators_Logfile.log at runtime.
var _ = func() bool { flog.For("8_validators").Info("source file initialized"); return true }()
