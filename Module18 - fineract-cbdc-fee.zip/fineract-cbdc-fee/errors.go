package fee

import (
	"errors"
	"fmt"
)

// Code classifies a fee error.
type Code string

// Error codes.
const (
	CodeValidation Code = "validation" // malformed schedule or request
	CodeNotFound   Code = "not_found"  // schedule not found
	CodeConflict   Code = "conflict"   // duplicate schedule id
	CodeInternal   Code = "internal"   // store or unexpected failure
)

// Error is the classified error type for the fee module.
type Error struct {
	Code    Code
	Message string
	Err     error
}

func (e *Error) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

func (e *Error) Unwrap() error { return e.Err }

func newErr(c Code, m string, err error) *Error { return &Error{Code: c, Message: m, Err: err} }

// NewValidationError builds a validation error.
func NewValidationError(m string, e error) *Error { return newErr(CodeValidation, m, e) }

// NewNotFoundError builds a not-found error.
func NewNotFoundError(m string, e error) *Error { return newErr(CodeNotFound, m, e) }

// NewConflictError builds a conflict error.
func NewConflictError(m string, e error) *Error { return newErr(CodeConflict, m, e) }

// NewInternalError builds an internal error.
func NewInternalError(m string, e error) *Error { return newErr(CodeInternal, m, e) }

// CodeOf returns the classification of err.
func CodeOf(err error) Code {
	if err == nil {
		return ""
	}
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return CodeInternal
}
