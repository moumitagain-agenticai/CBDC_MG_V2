package store_test

import (
	"context"
	"os"
	"testing"

	"github.com/fineract/cbdc/fee/store"
)

func TestPostgresRoundTrip(t *testing.T) {
	dsn := os.Getenv("DATABASE_DSN")
	if dsn == "" {
		t.Skip("DATABASE_DSN not set")
	}
	db, err := store.Open(dsn)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer db.Close()
	pg := store.NewPostgres(db)
	ctx := context.Background()
	if err := pg.Migrate(ctx); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	s := sched("pg-a")
	_ = pg.Save(ctx, s)
	got, err := pg.Get(ctx, "pg-a")
	if err != nil || got.ID != "pg-a" {
		t.Fatalf("get: %+v err=%v", got, err)
	}
}
