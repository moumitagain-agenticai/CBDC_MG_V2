package store

import "github.com/fineract/cbdc/fee/types"

func feeCurrency(s string) types.Currency { return types.Currency(s) }
