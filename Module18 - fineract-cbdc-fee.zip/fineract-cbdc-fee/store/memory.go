package store

import (
	"context"
	"sort"
	"sync"

	"github.com/fineract/cbdc/fee"
)

// Memory is an in-memory schedule Store.
type Memory struct {
	mu   sync.Mutex
	data map[string]fee.Schedule
}

var _ Store = (*Memory)(nil)

// NewMemory returns a ready in-memory store.
func NewMemory() *Memory { return &Memory{data: make(map[string]fee.Schedule)} }

func cloneSchedule(s fee.Schedule) fee.Schedule {
	cp := s
	cp.Legs = append([]fee.Leg(nil), s.Legs...)
	return cp
}

// Save stores a schedule, rejecting duplicate ids.
func (m *Memory) Save(_ context.Context, s fee.Schedule) error {
	if err := s.Validate(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.data[s.ID]; ok {
		return fee.NewConflictError("schedule already exists: "+s.ID, nil)
	}
	m.data[s.ID] = cloneSchedule(s)
	return nil
}

// Get returns a schedule by id.
func (m *Memory) Get(_ context.Context, id string) (fee.Schedule, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	s, ok := m.data[id]
	if !ok {
		return fee.Schedule{}, fee.NewNotFoundError("schedule not found: "+id, nil)
	}
	return cloneSchedule(s), nil
}

// List returns all schedules ordered by id.
func (m *Memory) List(_ context.Context) ([]fee.Schedule, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make([]fee.Schedule, 0, len(m.data))
	for _, s := range m.data {
		out = append(out, cloneSchedule(s))
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out, nil
}

// Ping is always healthy.
func (m *Memory) Ping(_ context.Context) error { return nil }
