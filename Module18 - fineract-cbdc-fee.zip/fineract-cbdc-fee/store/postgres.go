package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"

	"github.com/fineract/cbdc/fee"
	_ "github.com/lib/pq"
)

// Postgres is a PostgreSQL-backed schedule Store. Legs are stored as JSON.
type Postgres struct{ db *sql.DB }

var _ Store = (*Postgres)(nil)

// NewPostgres wraps an existing *sql.DB.
func NewPostgres(db *sql.DB) *Postgres { return &Postgres{db: db} }

// Open opens a PostgreSQL database from a DSN.
func Open(dsn string) (*sql.DB, error) { return sql.Open("postgres", dsn) }

const schema = `
CREATE TABLE IF NOT EXISTS fee_schedules (
    id       TEXT PRIMARY KEY,
    name     TEXT NOT NULL,
    currency TEXT NOT NULL,
    legs     JSONB NOT NULL
);`

// Migrate creates the fee_schedules table if it does not exist.
func (s *Postgres) Migrate(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, schema)
	return err
}

// Save stores a schedule, rejecting duplicate ids.
func (s *Postgres) Save(ctx context.Context, sch fee.Schedule) error {
	if err := sch.Validate(); err != nil {
		return err
	}
	legs, err := json.Marshal(sch.Legs)
	if err != nil {
		return fee.NewInternalError("marshal legs", err)
	}
	_, err = s.db.ExecContext(ctx,
		`INSERT INTO fee_schedules (id, name, currency, legs) VALUES ($1,$2,$3,$4)`,
		sch.ID, sch.Name, string(sch.Currency), legs)
	if err != nil {
		return fee.NewConflictError("schedule already exists or insert failed: "+sch.ID, err)
	}
	return nil
}

// Get returns a schedule by id.
func (s *Postgres) Get(ctx context.Context, id string) (fee.Schedule, error) {
	var sch fee.Schedule
	var ccy string
	var legs []byte
	err := s.db.QueryRowContext(ctx,
		`SELECT id, name, currency, legs FROM fee_schedules WHERE id=$1`, id).
		Scan(&sch.ID, &sch.Name, &ccy, &legs)
	if errors.Is(err, sql.ErrNoRows) {
		return fee.Schedule{}, fee.NewNotFoundError("schedule not found: "+id, nil)
	}
	if err != nil {
		return fee.Schedule{}, fee.NewInternalError("query schedule", err)
	}
	sch.Currency = feeCurrency(ccy)
	if err := json.Unmarshal(legs, &sch.Legs); err != nil {
		return fee.Schedule{}, fee.NewInternalError("unmarshal legs", err)
	}
	return sch, nil
}

// List returns all schedules ordered by id.
func (s *Postgres) List(ctx context.Context) ([]fee.Schedule, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT id, name, currency, legs FROM fee_schedules ORDER BY id`)
	if err != nil {
		return nil, fee.NewInternalError("list schedules", err)
	}
	defer rows.Close()
	var out []fee.Schedule
	for rows.Next() {
		var sch fee.Schedule
		var ccy string
		var legs []byte
		if err := rows.Scan(&sch.ID, &sch.Name, &ccy, &legs); err != nil {
			return nil, fee.NewInternalError("scan schedule", err)
		}
		sch.Currency = feeCurrency(ccy)
		if err := json.Unmarshal(legs, &sch.Legs); err != nil {
			return nil, fee.NewInternalError("unmarshal legs", err)
		}
		out = append(out, sch)
	}
	return out, rows.Err()
}

// Ping checks database health.
func (s *Postgres) Ping(ctx context.Context) error { return s.db.PingContext(ctx) }
