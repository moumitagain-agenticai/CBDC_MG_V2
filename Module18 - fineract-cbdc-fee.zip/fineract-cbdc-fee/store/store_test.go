package store_test

import (
	"context"
	"testing"

	"github.com/fineract/cbdc/fee"
	"github.com/fineract/cbdc/fee/store"
	"github.com/fineract/cbdc/fee/types"
)

func sched(id string) fee.Schedule {
	return fee.Schedule{
		ID: id, Name: "std", Currency: types.INR,
		Legs: []fee.Leg{{LegID: "l1", Sequence: 1, Purpose: fee.PurposePlatform, Recipient: "p", RateType: fee.RatePercentage, BasisPoints: 150}},
	}
}

func TestMemorySaveGetList(t *testing.T) {
	s := store.NewMemory()
	ctx := context.Background()
	if err := s.Save(ctx, sched("a")); err != nil {
		t.Fatalf("save: %v", err)
	}
	if err := s.Save(ctx, sched("a")); fee.CodeOf(err) != fee.CodeConflict {
		t.Fatalf("want conflict on duplicate, got %v", err)
	}
	got, err := s.Get(ctx, "a")
	if err != nil || got.ID != "a" || len(got.Legs) != 1 {
		t.Fatalf("get: %+v err=%v", got, err)
	}
	if _, err := s.Get(ctx, "missing"); fee.CodeOf(err) != fee.CodeNotFound {
		t.Fatalf("want not found, got %v", err)
	}
	all, _ := s.List(ctx)
	if len(all) != 1 {
		t.Fatalf("want 1 schedule, got %d", len(all))
	}
}
