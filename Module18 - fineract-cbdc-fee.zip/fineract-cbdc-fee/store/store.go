// Package store persists fee schedules. It provides an in-memory store and a
// PostgreSQL store (using lib/pq). Multi-leg schedules are stored with their
// legs as JSON.
package store

import (
	"context"

	"github.com/fineract/cbdc/fee"
)

// Store persists fee schedules by id.
type Store interface {
	// Save stores a schedule, returning a conflict error if the id already exists.
	Save(ctx context.Context, s fee.Schedule) error
	// Get returns a schedule by id, or a not-found error.
	Get(ctx context.Context, id string) (fee.Schedule, error)
	// List returns all schedules.
	List(ctx context.Context) ([]fee.Schedule, error)
	// Ping checks backend health.
	Ping(ctx context.Context) error
}
