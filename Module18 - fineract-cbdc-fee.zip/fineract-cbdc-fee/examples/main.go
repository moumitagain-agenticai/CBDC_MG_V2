// Command example demonstrates Module 18: a multi-leg fee of 1.5% (platform) +
// 1.5% (network) on a 1,000.00 INR transaction — the exact case the old
// single-leg model could not express.
//
//	go run ./examples
package main

import (
	"fmt"

	"github.com/fineract/cbdc/fee"
	"github.com/fineract/cbdc/fee/types"
)

func main() {
	schedule := fee.Schedule{
		ID: "standard", Name: "Standard settlement fee", Currency: types.INR,
		Legs: []fee.Leg{
			fill(fee.NewLeg(1, fee.PurposePlatform, "platform-treasury", fee.RatePercentage), 150),
			fill(fee.NewLeg(2, fee.PurposeNetwork, "network-treasury", fee.RatePercentage), 150),
		},
	}

	base := types.NewAmount(1_000_00, types.INR) // 1,000.00 INR (paise)
	comp, err := fee.NewCalculator().Compute(schedule, base)
	if err != nil {
		panic(err)
	}

	fmt.Printf("base: %s\n", comp.Base)
	for _, l := range comp.Legs {
		fmt.Printf("  leg %d  %-9s -> %-18s %s\n", l.Sequence, l.Purpose, l.Recipient, l.Amount)
	}
	fmt.Printf("total fee: %s\n", comp.Total)
}

func fill(l fee.Leg, bps int64) fee.Leg { l.BasisPoints = bps; return l }
