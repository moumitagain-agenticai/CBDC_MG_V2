-- fineract-cbdc-fee: multi-leg fee schedules. Legs (with legId, sequence,
-- feePurpose, feeRecipient) are stored as JSON.
CREATE TABLE IF NOT EXISTS fee_schedules (
    id       TEXT PRIMARY KEY,
    name     TEXT NOT NULL,
    currency TEXT NOT NULL,
    legs     JSONB NOT NULL
);
