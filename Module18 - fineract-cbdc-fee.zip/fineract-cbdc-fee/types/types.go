// Package types holds primitive value types shared across the fee module:
// currency, account identifiers, and an integer-minor-unit Amount.
package types

import "strconv"

// Currency is an ISO-4217 code (e.g. "INR").
type Currency string

// Common currencies.
const (
	INR Currency = "INR"
	AED Currency = "AED"
)

// Valid reports whether c is a three-letter uppercase code.
func (c Currency) Valid() bool {
	if len(c) != 3 {
		return false
	}
	for _, r := range c {
		if r < 'A' || r > 'Z' {
			return false
		}
	}
	return true
}

// AccountID identifies the party that receives a fee leg.
type AccountID string

// Amount is money held as integer minor units plus a currency.
type Amount struct {
	Minor    int64    `json:"minor"`
	Currency Currency `json:"currency"`
}

// NewAmount builds an Amount.
func NewAmount(minor int64, ccy Currency) Amount { return Amount{Minor: minor, Currency: ccy} }

// IsPositive reports whether the amount is > 0.
func (a Amount) IsPositive() bool { return a.Minor > 0 }

// Validate reports whether the amount is well-formed and non-negative.
func (a Amount) Validate() error {
	if !a.Currency.Valid() {
		return errInvalidCurrency
	}
	if a.Minor < 0 {
		return errNegativeAmount
	}
	return nil
}

// String renders "<minor> <currency>".
func (a Amount) String() string { return strconv.FormatInt(a.Minor, 10) + " " + string(a.Currency) }
