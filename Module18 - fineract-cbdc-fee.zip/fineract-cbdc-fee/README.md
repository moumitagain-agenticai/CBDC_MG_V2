# fineract-cbdc-fee  (Module 18 — P0 rework)

The **fee model and calculator**. This rework replaces the old **single-leg** fee
model, which could not express a fee split across parties — for example a **1.5%
platform charge plus a separate 1.5% network charge** on the same transaction.

Module path: `github.com/fineract/cbdc/fee` · Go 1.21+.

## What the rework adds

A fee is now a **`Schedule`** of ordered **`Leg`s**. Each leg carries the four
fields the finalised list calls for:

| Field | Meaning |
|-------|---------|
| `LegID` | stable id for the leg |
| `Sequence` | 1-based order in which legs apply |
| `Purpose` (`feePurpose`) | why the leg is charged (`PLATFORM`, `NETWORK`, `INTERCHANGE`, `TAX`, …) |
| `Recipient` (`feeRecipient`) | which account receives the leg |

Each leg is either a **percentage** (in basis points; `150` = 1.50%) or a **flat**
amount. So `1.5% + 1.5%` to two recipients is simply two legs:

```go
schedule := fee.Schedule{ID: "standard", Currency: types.INR, Legs: []fee.Leg{
    {Sequence: 1, Purpose: fee.PurposePlatform, Recipient: "platform-treasury", RateType: fee.RatePercentage, BasisPoints: 150},
    {Sequence: 2, Purpose: fee.PurposeNetwork,  Recipient: "network-treasury",  RateType: fee.RatePercentage, BasisPoints: 150},
}}
comp, _ := fee.NewCalculator().Compute(schedule, types.NewAmount(1_000_00, types.INR))
// comp.Legs -> 1500 paise (platform) + 1500 paise (network); comp.Total -> 3000
```

## Calculation

`Calculator.Compute` applies legs in `Sequence` order and returns a per-leg
breakdown plus the total. Percentage legs use **exact integer arithmetic**
(`math/big`) with **round-half-up** — no floating point, so results are
deterministic and auditable.

## Packages

| Path | Responsibility |
|------|----------------|
| `fee.go` | `Leg`, `Schedule`, `FeePurpose`, `RateType`, `Calculator`, `Computation`. |
| `types/` | `Amount` (integer minor units), `Currency`, `AccountID`. |
| `store/` | Schedule persistence: `Store` port + in-memory and PostgreSQL (legs as JSONB) + `Migrate`. |
| `migrations/001_init.sql` | The `fee_schedules` table. |

## Build, test, run

```bash
go build ./...
go vet ./...
go test ./...                       # unit tests (incl. the 1.5%+1.5% case)
DATABASE_DSN=postgres://... go test ./store/...   # DB-gated Postgres test
go run ./examples
```

## Error model

`fee.CodeOf(err)` returns one of: `validation`, `not_found`, `conflict`,
`internal`.

## Dependencies

`github.com/google/uuid` (leg ids) and `github.com/lib/pq` (PostgreSQL driver).
