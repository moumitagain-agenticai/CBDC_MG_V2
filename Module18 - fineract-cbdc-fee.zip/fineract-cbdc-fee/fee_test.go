package fee_test

import (
	"testing"

	"github.com/fineract/cbdc/fee"
	"github.com/fineract/cbdc/fee/types"
)

// The headline requirement: a fee that is 1.5% + 1.5% to two different
// recipients/purposes — impossible under the old single-leg model.
func TestMultiLegOnePointFivePlusOnePointFive(t *testing.T) {
	sch := fee.Schedule{
		ID: "std", Name: "standard", Currency: types.INR,
		Legs: []fee.Leg{
			{LegID: "l1", Sequence: 1, Purpose: fee.PurposePlatform, Recipient: "platform-acc", RateType: fee.RatePercentage, BasisPoints: 150},
			{LegID: "l2", Sequence: 2, Purpose: fee.PurposeNetwork, Recipient: "network-acc", RateType: fee.RatePercentage, BasisPoints: 150},
		},
	}
	base := types.NewAmount(1_000_00, types.INR) // 1,000.00 INR in paise
	comp, err := fee.NewCalculator().Compute(sch, base)
	if err != nil {
		t.Fatalf("compute: %v", err)
	}
	if len(comp.Legs) != 2 {
		t.Fatalf("want 2 legs, got %d", len(comp.Legs))
	}
	// 1.5% of 100000 paise = 1500 paise each
	if comp.Legs[0].Amount.Minor != 1500 || comp.Legs[1].Amount.Minor != 1500 {
		t.Fatalf("want 1500 each, got %d and %d", comp.Legs[0].Amount.Minor, comp.Legs[1].Amount.Minor)
	}
	if comp.Total.Minor != 3000 {
		t.Fatalf("want total 3000, got %d", comp.Total.Minor)
	}
	// distinct recipients and purposes are preserved
	if comp.Legs[0].Recipient == comp.Legs[1].Recipient {
		t.Fatal("legs must keep distinct recipients")
	}
	if comp.Legs[0].Purpose != fee.PurposePlatform || comp.Legs[1].Purpose != fee.PurposeNetwork {
		t.Fatalf("purposes not preserved: %s / %s", comp.Legs[0].Purpose, comp.Legs[1].Purpose)
	}
}

func TestSequenceOrdering(t *testing.T) {
	sch := fee.Schedule{
		ID: "s", Name: "n", Currency: types.INR,
		Legs: []fee.Leg{
			{LegID: "b", Sequence: 2, Purpose: fee.PurposeNetwork, Recipient: "n", RateType: fee.RateFlat, FlatAmount: types.NewAmount(200, types.INR)},
			{LegID: "a", Sequence: 1, Purpose: fee.PurposePlatform, Recipient: "p", RateType: fee.RateFlat, FlatAmount: types.NewAmount(100, types.INR)},
		},
	}
	comp, err := fee.NewCalculator().Compute(sch, types.NewAmount(50000, types.INR))
	if err != nil {
		t.Fatalf("compute: %v", err)
	}
	if comp.Legs[0].Sequence != 1 || comp.Legs[1].Sequence != 2 {
		t.Fatalf("legs must be applied in sequence order, got %d then %d", comp.Legs[0].Sequence, comp.Legs[1].Sequence)
	}
	if comp.Total.Minor != 300 {
		t.Fatalf("want total 300, got %d", comp.Total.Minor)
	}
}

func TestRoundingHalfUp(t *testing.T) {
	// 1.5% of 333 paise = 4.995 -> rounds to 5
	sch := fee.Schedule{
		ID: "r", Name: "n", Currency: types.INR,
		Legs: []fee.Leg{{LegID: "l", Sequence: 1, Purpose: fee.PurposeTax, Recipient: "t", RateType: fee.RatePercentage, BasisPoints: 150}},
	}
	comp, err := fee.NewCalculator().Compute(sch, types.NewAmount(333, types.INR))
	if err != nil {
		t.Fatalf("compute: %v", err)
	}
	if comp.Legs[0].Amount.Minor != 5 {
		t.Fatalf("want 5 after half-up rounding, got %d", comp.Legs[0].Amount.Minor)
	}
}

func TestValidation(t *testing.T) {
	calc := fee.NewCalculator()
	// no legs
	if _, err := calc.Compute(fee.Schedule{ID: "x", Currency: types.INR}, types.NewAmount(1, types.INR)); fee.CodeOf(err) != fee.CodeValidation {
		t.Fatalf("want validation for no legs, got %v", err)
	}
	// missing purpose/recipient
	bad := fee.Schedule{ID: "x", Currency: types.INR, Legs: []fee.Leg{{Sequence: 1, RateType: fee.RatePercentage, BasisPoints: 100}}}
	if _, err := calc.Compute(bad, types.NewAmount(1, types.INR)); fee.CodeOf(err) != fee.CodeValidation {
		t.Fatalf("want validation for missing purpose/recipient, got %v", err)
	}
	// duplicate sequence
	dup := fee.Schedule{ID: "x", Currency: types.INR, Legs: []fee.Leg{
		{Sequence: 1, Purpose: fee.PurposeTax, Recipient: "a", RateType: fee.RateFlat, FlatAmount: types.NewAmount(1, types.INR)},
		{Sequence: 1, Purpose: fee.PurposeTax, Recipient: "b", RateType: fee.RateFlat, FlatAmount: types.NewAmount(1, types.INR)},
	}}
	if _, err := calc.Compute(dup, types.NewAmount(1, types.INR)); fee.CodeOf(err) != fee.CodeValidation {
		t.Fatalf("want validation for duplicate sequence, got %v", err)
	}
	// currency mismatch
	mm := fee.Schedule{ID: "x", Currency: types.INR, Legs: []fee.Leg{{Sequence: 1, Purpose: fee.PurposeTax, Recipient: "a", RateType: fee.RatePercentage, BasisPoints: 100}}}
	if _, err := calc.Compute(mm, types.NewAmount(1, types.AED)); fee.CodeOf(err) != fee.CodeValidation {
		t.Fatalf("want validation for currency mismatch, got %v", err)
	}
}
