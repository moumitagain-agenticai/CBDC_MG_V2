# BUILD REPORT — fineract-cbdc-fee (Module 18)

Toolchain: Go 1.22 (module declares `go 1.21`). Module path:
`github.com/fineract/cbdc/fee`.

| Check | Command | Result |
|-------|---------|--------|
| Formatting | `gofmt -l .` | clean |
| Dependencies | `go mod tidy` | clean (`google/uuid`, `lib/pq`) |
| Build | `go build ./...` | pass (exit 0) |
| Vet | `go vet ./...` | pass (exit 0) |
| Unit tests | `go test ./...` | pass (fee, store) |
| Example | `go run ./examples` | prints the 1.5%+1.5% breakdown |

Requirement coverage (finalised list, #18 — REWORK leg + sequence): the
single-leg model is replaced by a multi-leg `Schedule`; each `Leg` has `LegID`,
`Sequence`, `Purpose` (feePurpose), and `Recipient` (feeRecipient). The
calculator applies legs in sequence and sums the total using exact integer
(`math/big`) round-half-up arithmetic.

Tests: the headline 1.5%+1.5% case (two legs, 1500 paise each, total 3000,
distinct recipients/purposes preserved); sequence ordering; half-up rounding
(1.5% of 333 → 5); validation (no legs, missing purpose/recipient, duplicate
sequence, currency mismatch); store save/get/list with duplicate-id conflict. A
DB-gated Postgres round-trip runs when `DATABASE_DSN` is set. Nothing pushed to
any remote.
