// Package fee is Module 18 of the E1 CBDC platform: the fee model and
// calculator.
//
// This is the REWORK that replaces the old SINGLE-LEG fee model, which could not
// express a fee split across parties — for example a 1.5% platform charge plus a
// separate 1.5% network charge on the same transaction. A fee is now a Schedule
// of ordered LEGS; each leg carries its own legId, sequence, feePurpose, and
// feeRecipient, so multi-party, multi-purpose fees are first-class.
package fee

import (
	"math/big"
	"sort"

	"github.com/fineract/cbdc/fee/types"
	"github.com/google/uuid"
)

// FeePurpose describes why a leg is charged. It is an open string type; common
// values are provided.
type FeePurpose string

// Common fee purposes.
const (
	PurposePlatform    FeePurpose = "PLATFORM"    // platform operator charge
	PurposeNetwork     FeePurpose = "NETWORK"     // network/scheme charge
	PurposeInterchange FeePurpose = "INTERCHANGE" // interchange charge
	PurposeTax         FeePurpose = "TAX"         // statutory tax (e.g. GST)
)

// RateType selects how a leg's amount is derived.
type RateType string

// Rate types.
const (
	RatePercentage RateType = "PERCENTAGE" // uses BasisPoints against the base amount
	RateFlat       RateType = "FLAT"       // uses FlatAmount regardless of base
)

// Leg is one component of a fee. The four fields the rework adds — LegID,
// Sequence, Purpose, Recipient — make multi-leg fees expressible.
type Leg struct {
	LegID       string          `json:"leg_id"`
	Sequence    int             `json:"sequence"`  // 1-based order of application
	Purpose     FeePurpose      `json:"purpose"`   // why this leg is charged
	Recipient   types.AccountID `json:"recipient"` // who receives this leg
	RateType    RateType        `json:"rate_type"`
	BasisPoints int64           `json:"basis_points"` // used when RateType == PERCENTAGE (150 = 1.50%)
	FlatAmount  types.Amount    `json:"flat_amount"`  // used when RateType == FLAT
}

// Validate checks a single leg.
func (l Leg) Validate(scheduleCcy types.Currency) error {
	if l.Sequence <= 0 {
		return NewValidationError("leg sequence must be >= 1", nil)
	}
	if l.Purpose == "" {
		return NewValidationError("leg feePurpose is required", nil)
	}
	if l.Recipient == "" {
		return NewValidationError("leg feeRecipient is required", nil)
	}
	switch l.RateType {
	case RatePercentage:
		if l.BasisPoints <= 0 {
			return NewValidationError("percentage leg needs basis_points > 0", nil)
		}
	case RateFlat:
		if err := l.FlatAmount.Validate(); err != nil {
			return NewValidationError("flat leg amount invalid: "+err.Error(), err)
		}
		if !l.FlatAmount.IsPositive() {
			return NewValidationError("flat leg amount must be positive", nil)
		}
		if l.FlatAmount.Currency != scheduleCcy {
			return NewValidationError("flat leg currency must match schedule currency", nil)
		}
	default:
		return NewValidationError("leg rate_type must be PERCENTAGE or FLAT", nil)
	}
	return nil
}

// Schedule is an ordered set of legs applied to a base amount.
type Schedule struct {
	ID       string         `json:"id"`
	Name     string         `json:"name"`
	Currency types.Currency `json:"currency"`
	Legs     []Leg          `json:"legs"`
}

// NewLeg builds a leg with a fresh id.
func NewLeg(seq int, purpose FeePurpose, recipient types.AccountID, rt RateType) Leg {
	return Leg{LegID: uuid.NewString(), Sequence: seq, Purpose: purpose, Recipient: recipient, RateType: rt}
}

// Validate checks the whole schedule: at least one leg, a valid currency,
// distinct sequences, and valid legs.
func (s Schedule) Validate() error {
	if s.ID == "" {
		return NewValidationError("schedule id is required", nil)
	}
	if !s.Currency.Valid() {
		return NewValidationError("schedule currency is invalid", nil)
	}
	if len(s.Legs) == 0 {
		return NewValidationError("schedule must have at least one leg", nil)
	}
	seen := make(map[int]bool, len(s.Legs))
	for _, l := range s.Legs {
		if seen[l.Sequence] {
			return NewValidationError("duplicate leg sequence", nil)
		}
		seen[l.Sequence] = true
		if err := l.Validate(s.Currency); err != nil {
			return err
		}
	}
	return nil
}

// ComputedLeg is the resolved amount for one leg.
type ComputedLeg struct {
	LegID     string          `json:"leg_id"`
	Sequence  int             `json:"sequence"`
	Purpose   FeePurpose      `json:"purpose"`
	Recipient types.AccountID `json:"recipient"`
	Amount    types.Amount    `json:"amount"`
}

// Computation is the full fee breakdown for a base amount.
type Computation struct {
	Base  types.Amount  `json:"base"`
	Legs  []ComputedLeg `json:"legs"`
	Total types.Amount  `json:"total"`
}

// Calculator computes fees from a schedule. It uses integer/exact arithmetic
// (big.Int) with round-half-up on percentage legs — no floating point.
type Calculator struct{}

// NewCalculator returns a calculator.
func NewCalculator() Calculator { return Calculator{} }

// percentBps computes base*bps/10000 rounded half-up, exactly.
func percentBps(baseMinor, bps int64) int64 {
	num := new(big.Int).Mul(big.NewInt(baseMinor), big.NewInt(bps))
	den := big.NewInt(10000)
	q := new(big.Int)
	r := new(big.Int)
	q.QuoRem(num, den, r)
	// round half up: if 2*r >= den, add 1
	if new(big.Int).Mul(r, big.NewInt(2)).Cmp(den) >= 0 {
		q.Add(q, big.NewInt(1))
	}
	return q.Int64()
}

// Compute resolves each leg (in sequence order) for the base amount and sums the
// total. The base currency must match the schedule currency.
func (Calculator) Compute(s Schedule, base types.Amount) (Computation, error) {
	if err := s.Validate(); err != nil {
		return Computation{}, err
	}
	if err := base.Validate(); err != nil {
		return Computation{}, NewValidationError("base amount invalid: "+err.Error(), err)
	}
	if base.Currency != s.Currency {
		return Computation{}, NewValidationError("base currency must match schedule currency", nil)
	}

	legs := append([]Leg(nil), s.Legs...)
	sort.Slice(legs, func(i, j int) bool { return legs[i].Sequence < legs[j].Sequence })

	out := make([]ComputedLeg, 0, len(legs))
	var total int64
	for _, l := range legs {
		var minor int64
		switch l.RateType {
		case RatePercentage:
			minor = percentBps(base.Minor, l.BasisPoints)
		case RateFlat:
			minor = l.FlatAmount.Minor
		}
		total += minor
		out = append(out, ComputedLeg{
			LegID: l.LegID, Sequence: l.Sequence, Purpose: l.Purpose, Recipient: l.Recipient,
			Amount: types.NewAmount(minor, s.Currency),
		})
	}
	return Computation{
		Base:  base,
		Legs:  out,
		Total: types.NewAmount(total, s.Currency),
	}, nil
}
