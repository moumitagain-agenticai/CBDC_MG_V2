package cache

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"

	"github.com/fineract/fx-oracle/internal/domain"
)

func TestTTLCache_HitMissExpire(t *testing.T) {
	c := NewTTL(30 * time.Second)
	now := time.Unix(1_700_000_000, 0)
	c.now = func() time.Time { return now }

	_, ok := c.Get("USD/EUR")
	assert.False(t, ok, "empty cache is a miss")

	c.Set("USD/EUR", domain.Rate{Base: "USD", Quote: "EUR", Rate: "0.92"})
	got, ok := c.Get("USD/EUR")
	assert.True(t, ok)
	assert.Equal(t, "0.92", got.Rate)

	// Advance past the TTL: the entry is now stale.
	now = now.Add(31 * time.Second)
	_, ok = c.Get("USD/EUR")
	assert.False(t, ok, "entry should be expired")
}
