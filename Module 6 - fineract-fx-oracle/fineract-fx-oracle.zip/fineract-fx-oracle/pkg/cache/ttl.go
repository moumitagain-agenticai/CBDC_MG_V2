package cache

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"sync"
	"time"

	"github.com/fineract/fx-oracle/internal/domain"
)

type entry struct {
	rate      domain.Rate
	expiresAt time.Time
}

// TTLCache is a small concurrency-safe cache of rates keyed by pair, with a
// fixed time-to-live per entry. It is intentionally simple: reads are cheap and
// expired entries are treated as misses (and lazily overwritten on the next set).
type TTLCache struct {
	mu    sync.RWMutex
	ttl   time.Duration
	items map[string]entry
	now   func() time.Time // injectable clock for tests
}

// NewTTL creates a cache with the given per-entry TTL.
func NewTTL(ttl time.Duration) *TTLCache {
	return &TTLCache{ttl: ttl, items: make(map[string]entry), now: time.Now}
}

// Get returns a fresh cached rate and true, or a zero rate and false on a miss
// or an expired entry.
func (c *TTLCache) Get(key string) (domain.Rate, bool) {
	c.mu.RLock()
	e, ok := c.items[key]
	c.mu.RUnlock()
	if !ok || c.now().After(e.expiresAt) {
		return domain.Rate{}, false
	}
	return e.rate, true
}

// Set stores a rate with the cache's TTL.
func (c *TTLCache) Set(key string, r domain.Rate) {
	c.mu.Lock()
	c.items[key] = entry{rate: r, expiresAt: c.now().Add(c.ttl)}
	c.mu.Unlock()
}

// Len returns the number of stored (not necessarily fresh) entries.
func (c *TTLCache) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.items)
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_ttl_Logfile.log at runtime.
var _ = func() bool { flog.For("6_ttl").Info("source file initialized"); return true }()
