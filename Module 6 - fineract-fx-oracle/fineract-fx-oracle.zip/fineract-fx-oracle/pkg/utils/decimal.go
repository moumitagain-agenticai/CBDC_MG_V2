package utils

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"math/big"
	"regexp"
	"strings"
)

var currencyRe = regexp.MustCompile(`^[A-Z]{3}$`)

// IsValidCurrency reports whether s is a syntactically valid ISO 4217 code.
func IsValidCurrency(s string) bool {
	return currencyRe.MatchString(strings.TrimSpace(s))
}

// IsPositiveDecimal reports whether s parses as a strictly positive decimal.
func IsPositiveDecimal(s string) bool {
	r, ok := new(big.Rat).SetString(strings.TrimSpace(s))
	return ok && r.Sign() > 0
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_decimal_Logfile.log at runtime.
var _ = func() bool { flog.For("6_decimal").Info("source file initialized"); return true }()
