package metrics

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// Metrics holds the oracle's Prometheus collectors on a private registry.
type Metrics struct {
	RateRequests     *prometheus.CounterVec // by result: hit|fetched|error
	ProviderRequests *prometheus.CounterVec // by provider, outcome: ok|error
	Fallbacks        prometheus.Counter
	RequestLatency   *prometheus.HistogramVec
	registry         *prometheus.Registry
}

// New registers metrics on a private registry.
func New() *Metrics {
	reg := prometheus.NewRegistry()
	f := promauto.With(reg)
	return &Metrics{
		registry: reg,
		RateRequests: f.NewCounterVec(prometheus.CounterOpts{
			Name: "fx_rate_requests_total",
			Help: "Rate lookups by result (hit, fetched, error).",
		}, []string{"result"}),
		ProviderRequests: f.NewCounterVec(prometheus.CounterOpts{
			Name: "fx_provider_requests_total",
			Help: "Upstream provider calls by provider and outcome.",
		}, []string{"provider", "outcome"}),
		Fallbacks: f.NewCounter(prometheus.CounterOpts{
			Name: "fx_provider_fallbacks_total",
			Help: "Number of times the oracle fell back from one provider to the next.",
		}),
		RequestLatency: f.NewHistogramVec(prometheus.HistogramOpts{
			Name:    "fx_rate_request_duration_seconds",
			Help:    "End-to-end latency of rate lookups, by result.",
			Buckets: prometheus.DefBuckets,
		}, []string{"result"}),
	}
}

// Handler returns the /metrics HTTP handler for this registry.
func (m *Metrics) Handler() http.Handler {
	return promhttp.HandlerFor(m.registry, promhttp.HandlerOpts{})
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_metrics_Logfile.log at runtime.
var _ = func() bool { flog.For("6_metrics").Info("source file initialized"); return true }()
