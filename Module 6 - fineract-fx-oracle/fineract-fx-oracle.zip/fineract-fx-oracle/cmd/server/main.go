package main

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"context"
	"errors"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"
	"go.uber.org/zap"

	"github.com/fineract/fx-oracle/internal/adapters/api"
	"github.com/fineract/fx-oracle/internal/adapters/provider"
	"github.com/fineract/fx-oracle/internal/adapters/repository"
	"github.com/fineract/fx-oracle/internal/config"
	"github.com/fineract/fx-oracle/internal/ports"
	"github.com/fineract/fx-oracle/internal/service"
	"github.com/fineract/fx-oracle/pkg/cache"
	"github.com/fineract/fx-oracle/pkg/logger"
	"github.com/fineract/fx-oracle/pkg/metrics"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "fatal:", err)
		os.Exit(1)
	}
}

func run() error {
	configPath := flag.String("config", "configs/config.yaml", "path to YAML config file")
	rollback := flag.Int("rollback", 0, "roll back the last N database migrations and exit")
	flag.Parse()

	_ = godotenv.Load()

	cfg, err := config.Load(*configPath)
	if err != nil {
		return fmt.Errorf("load config: %w", err)
	}

	log, err := logger.New(cfg.Log.Level, cfg.Log.JSON)
	if err != nil {
		return fmt.Errorf("init logger: %w", err)
	}
	defer func() { _ = log.Sync() }()

	m := metrics.New()

	// Build the ordered provider fallback chain.
	providers := make([]ports.RateProvider, 0, len(cfg.Providers))
	names := make([]string, 0, len(cfg.Providers))
	for _, pc := range cfg.Providers {
		providers = append(providers, provider.New(pc))
		names = append(names, pc.Name)
	}
	log.Info("provider fallback chain configured", zap.Strings("order", names))

	rateCache := cache.NewTTL(cfg.Cache.TTL)

	// Persistence is optional. Keep repo a true nil interface when disabled.
	var repo ports.RateRepository
	if cfg.Database.Enabled {
		db, err := repository.OpenDB(cfg.Database)
		if err != nil {
			return fmt.Errorf("open database: %w", err)
		}
		defer func() { _ = db.Close() }()

		if *rollback > 0 {
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			if err := repository.Rollback(ctx, db, log, *rollback); err != nil {
				return fmt.Errorf("rollback: %w", err)
			}
			log.Info("rollback complete", zap.Int("count", *rollback))
			return nil
		}

		mctx, mcancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer mcancel()
		if err := repository.Migrate(mctx, db, log); err != nil {
			return fmt.Errorf("run migrations: %w", err)
		}
		repo = repository.New(db)
		log.Info("rate history enabled")
	} else {
		if *rollback > 0 {
			return fmt.Errorf("-rollback requires a database (set DATABASE_DSN)")
		}
		log.Warn("rate history disabled; fetched rates will not be persisted")
	}

	svc := service.NewOracle(providers, rateCache, repo, m, log)
	handler := api.NewHandler(svc)
	router := api.NewRouter(handler, m, log, cfg.Server.RateLimitPerMin)

	srv := &http.Server{
		Addr:         fmt.Sprintf(":%d", cfg.Server.Port),
		Handler:      router,
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
	}

	serverErr := make(chan error, 1)
	go func() {
		log.Info("server listening", zap.Int("port", cfg.Server.Port))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			serverErr <- err
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)

	select {
	case err := <-serverErr:
		return fmt.Errorf("server error: %w", err)
	case sig := <-stop:
		log.Info("shutdown signal received", zap.String("signal", sig.String()))
	}

	ctx, cancel := context.WithTimeout(context.Background(), cfg.Server.ShutdownTimeout)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		return fmt.Errorf("graceful shutdown failed: %w", err)
	}
	log.Info("server stopped cleanly")
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_main_Logfile.log at runtime.
var _ = func() bool { flog.For("6_main").Info("source file initialized"); return true }()
