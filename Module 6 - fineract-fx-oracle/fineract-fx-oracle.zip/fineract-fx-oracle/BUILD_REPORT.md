# BUILD REPORT — fineract-fx-oracle

## Summary

An FX rate oracle that fetches rates from multiple upstream providers with
real-time lookup, TTL caching and an ordered provider fallback chain. It follows
the same production convention as the other modules (hexagonal layout, resilient
upstream clients with retry + circuit breaker, optional Postgres persistence,
Go migration runner, Prometheus metrics, graceful shutdown).

## Verification

| Check | Command | Result |
|-------|---------|--------|
| Build | `go build ./...` | PASS (exit 0) |
| Vet | `go vet ./...` | PASS (exit 0) |
| Unit tests | `go test ./...` | PASS (cache + oracle service) |
| Integration | `go test -tags integration ./test/integration/...` | PASS |
| Binary | `go build -o bin/fx-oracle ./cmd/server` | PASS (~16 MB static binary) |
| Formatting | `gofmt -l .` | clean (no files) |

## Runtime smoke test

Run with a failing primary provider and a healthy backup:

- **Fallback**: `GET /api/v1/rates/USD/EUR` — primary returned `500`, the oracle
  fell back to `backup` and returned `{"rate":"0.9231","provider":"backup","cached":false}`.
- **Caching**: the next identical request returned the same value with
  `"cached":true` and the backup upstream was **not** called again (verified via
  a request counter and an unchanged `as_of` timestamp).
- **Query form**: `GET /api/v1/rates?base=usd&quote=eur` returned the cached value.
- **Identity**: `GET /api/v1/rates/USD/USD` returned `"rate":"1","provider":"identity"`
  with no upstream call.
- **Validation**: an invalid currency (`US`) returned `400`.
- **All providers down**: returns `502` with a typed error.
- **Readiness**: `/readyz` reported `providers: ok (primary, backup)`.
- **Graceful shutdown** on `SIGTERM` drains and exits cleanly.
- **Migrations**: when a database is configured the oracle auto-applies pending
  migrations on startup; `-rollback N` reverts and exits. Without a DB, rate
  history is disabled cleanly and the migration test skips.

## Resilience design

Each provider is an independent HTTP client with its own timeout, retry-with-
backoff (`go-retryablehttp`) and circuit breaker (`gobreaker`). An open breaker
surfaces as a fast typed error so the oracle fails over to the next provider
immediately. Rates are read with `json.Number` and compared with `big.Rat`, so
no floating-point rounding is introduced.

## Notes

- The repository ships a clean `go.mod` with no `go.sum`; `go mod tidy` (or
  `make deps`) generates `go.sum` on first run with network access.
- Persistence is optional: with no `DATABASE_DSN` the repository is a true nil
  interface and the service runs fully in-memory.
- Nothing here is pushed to any Git remote; the module is self-contained.
