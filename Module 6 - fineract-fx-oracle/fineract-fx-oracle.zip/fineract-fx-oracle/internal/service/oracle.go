package service

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"context"
	"strings"
	"time"

	"go.uber.org/zap"

	"github.com/fineract/fx-oracle/internal/domain"
	"github.com/fineract/fx-oracle/internal/ports"
	"github.com/fineract/fx-oracle/pkg/cache"
	"github.com/fineract/fx-oracle/pkg/metrics"
	"github.com/fineract/fx-oracle/pkg/utils"
)

// Oracle resolves FX rates: it serves fresh cached rates when available, and on
// a miss walks the configured providers in order, returning the first success
// and falling back to the next provider on any failure.
type Oracle struct {
	providers []ports.RateProvider // fallback order
	cache     *cache.TTLCache
	repo      ports.RateRepository // optional; nil disables rate history
	metrics   *metrics.Metrics
	log       *zap.Logger
}

// NewOracle wires the service. repo may be nil when persistence is disabled.
func NewOracle(providers []ports.RateProvider, c *cache.TTLCache, repo ports.RateRepository, m *metrics.Metrics, log *zap.Logger) *Oracle {
	return &Oracle{providers: providers, cache: c, repo: repo, metrics: m, log: log}
}

// GetRate returns base→quote, using the cache and provider fallback.
func (o *Oracle) GetRate(ctx context.Context, base, quote string) (rate domain.Rate, err error) {
	base = strings.ToUpper(strings.TrimSpace(base))
	quote = strings.ToUpper(strings.TrimSpace(quote))

	result := "error"
	start := time.Now()
	defer func() {
		o.metrics.RateRequests.WithLabelValues(result).Inc()
		o.metrics.RequestLatency.WithLabelValues(result).Observe(time.Since(start).Seconds())
	}()

	if !utils.IsValidCurrency(base) || !utils.IsValidCurrency(quote) {
		return domain.Rate{}, domain.NewValidationError("base and quote must be ISO 4217 codes", nil)
	}
	if base == quote {
		result = "hit"
		return domain.Rate{Base: base, Quote: quote, Rate: "1", Provider: "identity", AsOf: time.Now().UTC()}, nil
	}

	key := domain.Pair{Base: base, Quote: quote}.Key()
	if r, ok := o.cache.Get(key); ok {
		r.Cached = true
		result = "hit"
		return r, nil
	}

	var lastErr error
	for i, p := range o.providers {
		r, perr := p.GetRate(ctx, base, quote)
		if perr != nil {
			lastErr = perr
			o.metrics.ProviderRequests.WithLabelValues(p.Name(), "error").Inc()
			o.log.Warn("provider failed", zap.String("provider", p.Name()), zap.Error(perr))
			if i < len(o.providers)-1 {
				o.metrics.Fallbacks.Inc()
			}
			continue
		}
		if !utils.IsPositiveDecimal(r.Rate) {
			lastErr = domain.NewUpstreamError("provider "+p.Name()+" returned a non-positive rate", nil)
			o.metrics.ProviderRequests.WithLabelValues(p.Name(), "error").Inc()
			if i < len(o.providers)-1 {
				o.metrics.Fallbacks.Inc()
			}
			continue
		}

		o.metrics.ProviderRequests.WithLabelValues(p.Name(), "ok").Inc()
		o.cache.Set(key, r)
		o.recordHistory(ctx, r)
		result = "fetched"
		return r, nil
	}

	if lastErr == nil {
		lastErr = domain.NewUpstreamError("no providers configured", nil)
	}
	return domain.Rate{}, domain.NewUpstreamError("all providers failed for "+key, lastErr)
}

func (o *Oracle) recordHistory(ctx context.Context, r domain.Rate) {
	if o.repo == nil {
		return
	}
	if err := o.repo.Save(ctx, r); err != nil {
		o.log.Error("failed to persist rate history", zap.Error(err))
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_oracle_Logfile.log at runtime.
var _ = func() bool { flog.For("6_oracle").Info("source file initialized"); return true }()
