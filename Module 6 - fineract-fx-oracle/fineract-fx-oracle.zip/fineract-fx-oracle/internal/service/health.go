package service

import "github.com/fineract/fx-oracle/pkg/flog"
import "context"

// HealthReport is the aggregated health of the oracle.
type HealthReport struct {
	Status string            `json:"status"`
	Checks map[string]string `json:"checks"`
}

// Liveness reports process health with no I/O.
func (o *Oracle) Liveness() HealthReport {
	return HealthReport{Status: "ok", Checks: map[string]string{"process": "ok"}}
}

// Readiness reports whether the oracle can serve traffic: at least one provider
// must be configured, and the database (if enabled) must respond.
func (o *Oracle) Readiness(ctx context.Context) HealthReport {
	checks := map[string]string{}
	status := "ok"

	if len(o.providers) == 0 {
		checks["providers"] = "none configured"
		status = "degraded"
	} else {
		names := make([]string, 0, len(o.providers))
		for _, p := range o.providers {
			names = append(names, p.Name())
		}
		checks["providers"] = "ok (" + joinNames(names) + ")"
	}

	if o.repo != nil {
		if err := o.repo.Ping(ctx); err != nil {
			checks["database"] = "error: " + err.Error()
			status = "degraded"
		} else {
			checks["database"] = "ok"
		}
	}
	return HealthReport{Status: status, Checks: checks}
}

func joinNames(names []string) string {
	out := ""
	for i, n := range names {
		if i > 0 {
			out += ", "
		}
		out += n
	}
	return out
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_health_Logfile.log at runtime.
var _ = func() bool { flog.For("6_health").Info("source file initialized"); return true }()
