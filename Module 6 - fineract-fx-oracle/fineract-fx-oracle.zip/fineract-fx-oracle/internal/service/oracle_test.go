package service_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/fx-oracle/internal/domain"
	"github.com/fineract/fx-oracle/internal/ports"
	"github.com/fineract/fx-oracle/internal/service"
	"github.com/fineract/fx-oracle/pkg/cache"
	"github.com/fineract/fx-oracle/pkg/metrics"
	"github.com/fineract/fx-oracle/test/mocks"
)

// portsOf adapts fake providers into the ports.RateProvider slice the oracle wants.
func portsOf(providers ...*mocks.FakeProvider) []ports.RateProvider {
	out := make([]ports.RateProvider, len(providers))
	for i, p := range providers {
		out[i] = p
	}
	return out
}

func TestFallback_SecondProviderSucceeds(t *testing.T) {
	p1 := &mocks.FakeProvider{ProviderName: "primary", Err: errors.New("boom")}
	p2 := &mocks.FakeProvider{ProviderName: "backup", RateValue: "0.92"}
	o := service.NewOracle(portsOf(p1, p2), cache.NewTTL(time.Minute), nil, metrics.New(), zap.NewNop())

	r, err := o.GetRate(context.Background(), "usd", "eur")
	require.NoError(t, err)
	assert.Equal(t, "backup", r.Provider)
	assert.Equal(t, "0.92", r.Rate)
	assert.Equal(t, "USD", r.Base)
	assert.Equal(t, 1, p1.Calls)
	assert.Equal(t, 1, p2.Calls)
}

func TestCache_SecondCallDoesNotHitProvider(t *testing.T) {
	p1 := &mocks.FakeProvider{ProviderName: "primary", RateValue: "1.10"}
	o := service.NewOracle(portsOf(p1), cache.NewTTL(time.Minute), nil, metrics.New(), zap.NewNop())

	_, err := o.GetRate(context.Background(), "EUR", "USD")
	require.NoError(t, err)
	r2, err := o.GetRate(context.Background(), "EUR", "USD")
	require.NoError(t, err)

	assert.True(t, r2.Cached)
	assert.Equal(t, 1, p1.Calls, "provider should be called once; second served from cache")
}

func TestAllProvidersFail(t *testing.T) {
	p1 := &mocks.FakeProvider{ProviderName: "primary", Err: errors.New("down")}
	p2 := &mocks.FakeProvider{ProviderName: "backup", Err: errors.New("down")}
	o := service.NewOracle(portsOf(p1, p2), cache.NewTTL(time.Minute), nil, metrics.New(), zap.NewNop())

	_, err := o.GetRate(context.Background(), "USD", "EUR")
	require.Error(t, err)
	assert.Equal(t, domain.CodeUpstream, domain.AsDomainError(err).Code)
}

func TestIdentityPair(t *testing.T) {
	p1 := &mocks.FakeProvider{ProviderName: "primary", RateValue: "9"}
	o := service.NewOracle(portsOf(p1), cache.NewTTL(time.Minute), nil, metrics.New(), zap.NewNop())

	r, err := o.GetRate(context.Background(), "USD", "USD")
	require.NoError(t, err)
	assert.Equal(t, "1", r.Rate)
	assert.Equal(t, "identity", r.Provider)
	assert.Equal(t, 0, p1.Calls, "identity must not call a provider")
}

func TestInvalidCurrency(t *testing.T) {
	p1 := &mocks.FakeProvider{ProviderName: "primary", RateValue: "1"}
	o := service.NewOracle(portsOf(p1), cache.NewTTL(time.Minute), nil, metrics.New(), zap.NewNop())

	_, err := o.GetRate(context.Background(), "US", "EUR")
	require.Error(t, err)
	assert.Equal(t, domain.CodeValidation, domain.AsDomainError(err).Code)
}

func TestHistoryRecorded(t *testing.T) {
	repo := &mocks.FakeRepo{}
	p1 := &mocks.FakeProvider{ProviderName: "primary", RateValue: "0.5"}
	o := service.NewOracle(portsOf(p1), cache.NewTTL(time.Minute), repo, metrics.New(), zap.NewNop())

	_, err := o.GetRate(context.Background(), "USD", "GBP")
	require.NoError(t, err)
	require.Len(t, repo.Saved, 1)
	assert.Equal(t, "primary", repo.Saved[0].Provider)
}
