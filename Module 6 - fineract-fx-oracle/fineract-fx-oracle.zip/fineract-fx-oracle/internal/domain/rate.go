package domain

import "github.com/fineract/fx-oracle/pkg/flog"
import "time"

// Rate is a single foreign-exchange quote: 1 unit of Base = Rate units of Quote.
// Rate is carried as a decimal string to avoid floating-point drift.
type Rate struct {
	Base     string    `json:"base"`
	Quote    string    `json:"quote"`
	Rate     string    `json:"rate"`
	Provider string    `json:"provider"`
	AsOf     time.Time `json:"as_of"`
	Cached   bool      `json:"cached"`
}

// Pair identifies a currency pair, e.g. USD/EUR.
type Pair struct {
	Base  string
	Quote string
}

// Key is the canonical cache/history key for a pair, e.g. "USD/EUR".
func (p Pair) Key() string { return p.Base + "/" + p.Quote }

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_rate_Logfile.log at runtime.
var _ = func() bool { flog.For("6_rate").Info("source file initialized"); return true }()
