package provider

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"time"

	"github.com/hashicorp/go-retryablehttp"
	"github.com/sony/gobreaker"

	"github.com/fineract/fx-oracle/internal/config"
	"github.com/fineract/fx-oracle/internal/domain"
	"github.com/fineract/fx-oracle/internal/ports"
)

// HTTPProvider is a resilient client for one upstream FX rate source. Each call
// is retried on transient failures and guarded by a circuit breaker, so a dead
// provider fails fast and lets the oracle fall back to the next one.
type HTTPProvider struct {
	name    string
	kind    string
	baseURL string
	apiKey  string
	hc      *retryablehttp.Client
	breaker *gobreaker.CircuitBreaker
}

var _ ports.RateProvider = (*HTTPProvider)(nil)

// New builds an HTTPProvider from configuration.
func New(cfg config.ProviderConfig) *HTTPProvider {
	rc := retryablehttp.NewClient()
	rc.Logger = nil
	rc.RetryMax = cfg.MaxRetries
	rc.HTTPClient.Timeout = cfg.Timeout

	maxReq := cfg.BreakerMaxReq
	if maxReq == 0 {
		maxReq = 3
	}
	cb := gobreaker.NewCircuitBreaker(gobreaker.Settings{
		Name:        "fx-provider-" + cfg.Name,
		MaxRequests: maxReq,
		Interval:    60 * time.Second,
		Timeout:     30 * time.Second,
		ReadyToTrip: func(c gobreaker.Counts) bool {
			return c.ConsecutiveFailures >= 3
		},
	})

	return &HTTPProvider{
		name:    cfg.Name,
		kind:    cfg.Kind,
		baseURL: cfg.BaseURL,
		apiKey:  cfg.APIKey,
		hc:      rc,
		breaker: cb,
	}
}

func (p *HTTPProvider) Name() string { return p.name }

// GetRate fetches base→quote from the upstream source.
func (p *HTTPProvider) GetRate(ctx context.Context, base, quote string) (domain.Rate, error) {
	out, err := p.breaker.Execute(func() (interface{}, error) {
		return p.fetch(ctx, base, quote)
	})
	if err != nil {
		if err == gobreaker.ErrOpenState || err == gobreaker.ErrTooManyRequests {
			return domain.Rate{}, domain.NewCircuitOpenError("provider "+p.name+" circuit open", err)
		}
		return domain.Rate{}, err
	}
	return out.(domain.Rate), nil
}

func (p *HTTPProvider) fetch(ctx context.Context, base, quote string) (domain.Rate, error) {
	u, err := url.Parse(p.baseURL)
	if err != nil {
		return domain.Rate{}, domain.NewInternalError("bad provider base url", err)
	}
	q := u.Query()
	q.Set("base", base)
	q.Set("quote", quote)
	u.RawQuery = q.Encode()

	req, err := retryablehttp.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return domain.Rate{}, domain.NewInternalError("build request", err)
	}
	req.Header.Set("Accept", "application/json")
	if p.apiKey != "" {
		req.Header.Set("X-API-Key", p.apiKey)
	}

	resp, err := p.hc.Do(req)
	if err != nil {
		return domain.Rate{}, domain.NewUpstreamError("provider "+p.name+" request failed", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return domain.Rate{}, domain.NewUpstreamError(fmt.Sprintf("provider %s returned %d", p.name, resp.StatusCode), nil)
	}

	rateStr, err := parseRate(p.kind, quote, body)
	if err != nil {
		return domain.Rate{}, err
	}
	return domain.Rate{
		Base:     base,
		Quote:    quote,
		Rate:     rateStr,
		Provider: p.name,
		AsOf:     time.Now().UTC(),
	}, nil
}

// parseRate extracts the decimal rate string according to the provider's
// response shape. json.Number preserves the exact digits the provider sent.
func parseRate(kind, quote string, body []byte) (string, error) {
	dec := json.NewDecoder(bytes.NewReader(body))
	dec.UseNumber()

	switch kind {
	case "frankfurter":
		// {"base":"USD","rates":{"EUR":0.92}}
		var r struct {
			Rates map[string]json.Number `json:"rates"`
		}
		if err := dec.Decode(&r); err != nil {
			return "", domain.NewUpstreamError("decode frankfurter response", err)
		}
		v, ok := r.Rates[quote]
		if !ok {
			return "", domain.NewUpstreamError("quote currency missing in provider response", nil)
		}
		return v.String(), nil
	case "ratesapi":
		// {"base":"USD","target":"EUR","quote":"0.9187"}
		var r struct {
			Quote json.Number `json:"quote"`
		}
		if err := dec.Decode(&r); err != nil {
			return "", domain.NewUpstreamError("decode ratesapi response", err)
		}
		if r.Quote.String() == "" {
			return "", domain.NewUpstreamError("empty quote in provider response", nil)
		}
		return r.Quote.String(), nil
	default:
		return "", domain.NewInternalError("unknown provider kind: "+kind, nil)
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_http_provider_Logfile.log at runtime.
var _ = func() bool { flog.For("6_http_provider").Info("source file initialized"); return true }()
