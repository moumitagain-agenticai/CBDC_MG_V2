package repository

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"context"
	"database/sql"

	_ "github.com/lib/pq" // postgres driver (side-effect import)

	"github.com/fineract/fx-oracle/internal/config"
	"github.com/fineract/fx-oracle/internal/domain"
	"github.com/fineract/fx-oracle/internal/ports"
	"github.com/google/uuid"
)

// Repository is a PostgreSQL-backed rate-history store.
type Repository struct {
	db *sql.DB
}

var _ ports.RateRepository = (*Repository)(nil)

// OpenDB opens and configures a *sql.DB from database configuration.
func OpenDB(cfg config.DatabaseConfig) (*sql.DB, error) {
	db, err := sql.Open("postgres", cfg.DSN)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(cfg.MaxOpenConns)
	db.SetMaxIdleConns(cfg.MaxIdleConns)
	db.SetConnMaxLifetime(cfg.ConnMaxLifetime)
	return db, nil
}

// New builds a Repository over an existing *sql.DB.
func New(db *sql.DB) *Repository { return &Repository{db: db} }

func (r *Repository) Save(ctx context.Context, rate domain.Rate) error {
	const q = `
INSERT INTO fx_rate_history (id, base, quote, rate, provider, as_of)
VALUES ($1,$2,$3,$4,$5,$6)`
	_, err := r.db.ExecContext(ctx, q,
		uuid.NewString(), rate.Base, rate.Quote, rate.Rate, rate.Provider, rate.AsOf,
	)
	if err != nil {
		return domain.NewInternalError("persist rate history", err)
	}
	return nil
}

func (r *Repository) Ping(ctx context.Context) error {
	if err := r.db.PingContext(ctx); err != nil {
		return domain.NewInternalError("database ping failed", err)
	}
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_rate_repo_Logfile.log at runtime.
var _ = func() bool { flog.For("6_rate_repo").Info("source file initialized"); return true }()
