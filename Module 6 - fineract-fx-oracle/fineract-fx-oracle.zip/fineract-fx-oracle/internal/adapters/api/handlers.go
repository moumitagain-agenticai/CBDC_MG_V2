package api

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"

	"github.com/fineract/fx-oracle/internal/domain"
	"github.com/fineract/fx-oracle/internal/service"
)

// Handler exposes the FX oracle over HTTP.
type Handler struct {
	svc *service.Oracle
}

// NewHandler builds an HTTP handler around the oracle service.
func NewHandler(svc *service.Oracle) *Handler { return &Handler{svc: svc} }

// GetRatePath handles GET /api/v1/rates/{base}/{quote}.
func (h *Handler) GetRatePath(w http.ResponseWriter, r *http.Request) {
	base := chi.URLParam(r, "base")
	quote := chi.URLParam(r, "quote")
	h.respondRate(w, r, base, quote)
}

// GetRateQuery handles GET /api/v1/rates?base=..&quote=..
func (h *Handler) GetRateQuery(w http.ResponseWriter, r *http.Request) {
	base := r.URL.Query().Get("base")
	quote := r.URL.Query().Get("quote")
	h.respondRate(w, r, base, quote)
}

func (h *Handler) respondRate(w http.ResponseWriter, r *http.Request, base, quote string) {
	rate, err := h.svc.GetRate(r.Context(), base, quote)
	if err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, http.StatusOK, rate)
}

func (h *Handler) Liveness(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, h.svc.Liveness())
}

func (h *Handler) Readiness(w http.ResponseWriter, r *http.Request) {
	rep := h.svc.Readiness(r.Context())
	status := http.StatusOK
	if rep.Status != "ok" {
		status = http.StatusServiceUnavailable
	}
	writeJSON(w, status, rep)
}

// ---- helpers ----

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if payload != nil {
		_ = json.NewEncoder(w).Encode(payload)
	}
}

type errorBody struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, err error) {
	de := domain.AsDomainError(err)
	var body errorBody
	body.Error.Code = string(de.Code)
	body.Error.Message = de.Message
	writeJSON(w, httpStatus(de.Code), body)
}

func httpStatus(code domain.ErrorCode) int {
	switch code {
	case domain.CodeValidation:
		return http.StatusBadRequest
	case domain.CodeNotFound:
		return http.StatusNotFound
	case domain.CodeConflict:
		return http.StatusConflict
	case domain.CodeUnauthorized:
		return http.StatusUnauthorized
	case domain.CodeTimeout:
		return http.StatusGatewayTimeout
	case domain.CodeUpstream, domain.CodeCircuitOpen:
		return http.StatusBadGateway
	default:
		return http.StatusInternalServerError
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_handlers_Logfile.log at runtime.
var _ = func() bool { flog.For("6_handlers").Info("source file initialized"); return true }()
