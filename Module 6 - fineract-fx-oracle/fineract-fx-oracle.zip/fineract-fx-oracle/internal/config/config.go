package config

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

// Config is the fully-resolved application configuration.
type Config struct {
	Server    ServerConfig     `yaml:"server"`
	Providers []ProviderConfig `yaml:"providers"` // order defines the fallback chain
	Cache     CacheConfig      `yaml:"cache"`
	Database  DatabaseConfig   `yaml:"database"`
	Log       LogConfig        `yaml:"log"`
}

type ServerConfig struct {
	Port            int           `yaml:"port"`
	ReadTimeout     time.Duration `yaml:"read_timeout"`
	WriteTimeout    time.Duration `yaml:"write_timeout"`
	ShutdownTimeout time.Duration `yaml:"shutdown_timeout"`
	RateLimitPerMin int           `yaml:"rate_limit_per_min"`
}

// ProviderConfig configures one upstream FX source. Kind selects the response
// parser (frankfurter | ratesapi).
type ProviderConfig struct {
	Name          string        `yaml:"name"`
	Kind          string        `yaml:"kind"`
	BaseURL       string        `yaml:"base_url"`
	APIKey        string        `yaml:"api_key"`
	Timeout       time.Duration `yaml:"timeout"`
	MaxRetries    int           `yaml:"max_retries"`
	BreakerMaxReq uint32        `yaml:"breaker_max_requests"`
}

type CacheConfig struct {
	TTL time.Duration `yaml:"ttl"`
}

type DatabaseConfig struct {
	DSN             string        `yaml:"dsn"`
	MaxOpenConns    int           `yaml:"max_open_conns"`
	MaxIdleConns    int           `yaml:"max_idle_conns"`
	ConnMaxLifetime time.Duration `yaml:"conn_max_lifetime"`
	Enabled         bool          `yaml:"enabled"`
}

type LogConfig struct {
	Level string `yaml:"level"`
	JSON  bool   `yaml:"json"`
}

// Default returns production-sane defaults.
func Default() Config {
	return Config{
		Server: ServerConfig{
			Port:            8080,
			ReadTimeout:     10 * time.Second,
			WriteTimeout:    15 * time.Second,
			ShutdownTimeout: 20 * time.Second,
			RateLimitPerMin: 240,
		},
		Cache: CacheConfig{TTL: 60 * time.Second},
		Database: DatabaseConfig{
			MaxOpenConns:    25,
			MaxIdleConns:    5,
			ConnMaxLifetime: 30 * time.Minute,
			Enabled:         false,
		},
		Log: LogConfig{Level: "info", JSON: true},
	}
}

// Load reads YAML (if present), applies env overrides, then validates.
func Load(path string) (Config, error) {
	cfg := Default()
	if path != "" {
		data, err := os.ReadFile(path)
		if err == nil {
			if err := yaml.Unmarshal(data, &cfg); err != nil {
				return Config{}, fmt.Errorf("parsing config %s: %w", path, err)
			}
		} else if !os.IsNotExist(err) {
			return Config{}, fmt.Errorf("reading config %s: %w", path, err)
		}
	}
	applyEnvOverrides(&cfg)
	applyProviderDefaults(&cfg)
	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

func applyEnvOverrides(cfg *Config) {
	if v := os.Getenv("SERVER_PORT"); v != "" {
		if p, err := strconv.Atoi(v); err == nil {
			cfg.Server.Port = p
		}
	}
	if v := os.Getenv("CACHE_TTL"); v != "" {
		if d, err := time.ParseDuration(v); err == nil {
			cfg.Cache.TTL = d
		}
	}
	if v := os.Getenv("DATABASE_DSN"); v != "" {
		cfg.Database.DSN = v
		cfg.Database.Enabled = true
	}
	if v := os.Getenv("LOG_LEVEL"); v != "" {
		cfg.Log.Level = v
	}
	// Convenience: define providers entirely from env for containers.
	// FX_PROVIDERS="primary|frankfurter|https://a.example,backup|ratesapi|https://b.example"
	if v := os.Getenv("FX_PROVIDERS"); v != "" {
		cfg.Providers = parseProvidersEnv(v)
	}
}

func parseProvidersEnv(v string) []ProviderConfig {
	var out []ProviderConfig
	for _, part := range strings.Split(v, ",") {
		fields := strings.Split(strings.TrimSpace(part), "|")
		if len(fields) < 3 {
			continue
		}
		out = append(out, ProviderConfig{
			Name:    strings.TrimSpace(fields[0]),
			Kind:    strings.TrimSpace(fields[1]),
			BaseURL: strings.TrimSpace(fields[2]),
		})
	}
	return out
}

func applyProviderDefaults(cfg *Config) {
	for i := range cfg.Providers {
		if cfg.Providers[i].Timeout == 0 {
			cfg.Providers[i].Timeout = 5 * time.Second
		}
		if cfg.Providers[i].MaxRetries == 0 {
			cfg.Providers[i].MaxRetries = 2
		}
		if cfg.Providers[i].BreakerMaxReq == 0 {
			cfg.Providers[i].BreakerMaxReq = 3
		}
	}
}

// Validate fails fast on inconsistent configuration.
func (c Config) Validate() error {
	if c.Server.Port <= 0 || c.Server.Port > 65535 {
		return fmt.Errorf("invalid server port: %d", c.Server.Port)
	}
	if len(c.Providers) == 0 {
		return fmt.Errorf("at least one provider is required")
	}
	for i, p := range c.Providers {
		if p.Name == "" || p.BaseURL == "" {
			return fmt.Errorf("provider[%d]: name and base_url are required", i)
		}
		if p.Kind != "frankfurter" && p.Kind != "ratesapi" {
			return fmt.Errorf("provider[%d] %q: kind must be frankfurter|ratesapi", i, p.Name)
		}
	}
	if c.Cache.TTL <= 0 {
		return fmt.Errorf("cache.ttl must be positive")
	}
	if c.Database.Enabled && c.Database.DSN == "" {
		return fmt.Errorf("database.dsn is required when database is enabled")
	}
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_config_Logfile.log at runtime.
var _ = func() bool { flog.For("6_config").Info("source file initialized"); return true }()
