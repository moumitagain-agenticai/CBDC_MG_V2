package ports

import "github.com/fineract/fx-oracle/pkg/flog"
import (
	"context"

	"github.com/fineract/fx-oracle/internal/domain"
)

// RateProvider is an outbound port for a single upstream FX rate source.
// Implementations are expected to be resilient (timeouts, retries, circuit
// breaking) and to return a typed domain error on failure so the oracle can
// decide whether to fall back to the next provider.
type RateProvider interface {
	Name() string
	GetRate(ctx context.Context, base, quote string) (domain.Rate, error)
}

// RateRepository is the optional outbound port for the rate-history audit trail.
type RateRepository interface {
	Save(ctx context.Context, r domain.Rate) error
	Ping(ctx context.Context) error
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/6_provider_Logfile.log at runtime.
var _ = func() bool { flog.For("6_provider").Info("source file initialized"); return true }()
