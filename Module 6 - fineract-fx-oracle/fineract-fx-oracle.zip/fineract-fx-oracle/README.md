# fineract-fx-oracle

Module 6 of the E1 Cross-Border CBDC platform. It is the **FX rate oracle**: it
fetches foreign-exchange rates from **multiple upstream providers**, serves them
in **real time**, **caches** them with a short TTL, and **falls back** from one
provider to the next when a source is slow or down.

It builds and runs stand-alone and follows the same convention as the other
modules (hexagonal layout, resilient upstream clients, optional Postgres
persistence, Prometheus metrics, graceful shutdown, Go migration runner).

## Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/v1/rates/{base}/{quote}` | Rate for a pair (path form) |
| GET | `/api/v1/rates?base=USD&quote=EUR` | Rate for a pair (query form) |
| GET | `/healthz` / `/readyz` | Liveness / readiness (readiness lists providers) |
| GET | `/metrics` | Prometheus metrics |

Response:

```json
{"base":"USD","quote":"EUR","rate":"0.9231","provider":"backup",
 "as_of":"2026-07-31T19:36:15Z","cached":false}
```

`rate` is a decimal **string** (1 unit of `base` = `rate` units of `quote`) to
avoid floating-point drift. `cached` shows whether the value came from cache.
Requesting a pair where base == quote returns `1` from the `identity` provider
without calling anyone.

## How resolution works

1. **Cache first.** If a fresh (non-expired) rate for the pair is cached, it is
   returned immediately with `cached: true` — no provider is called.
2. **Provider fallback.** On a miss, the oracle walks the configured providers
   **in order**. Each provider call has its own timeout, retry-with-backoff, and
   circuit breaker; on any failure (error, bad status, open breaker, or a
   non-positive rate) the oracle moves to the next provider and increments the
   fallback counter.
3. **First success wins.** The first good rate is cached (with the configured
   TTL), optionally written to the rate-history table, and returned with
   `cached: false`.
4. **All failed.** If every provider fails, the API returns `502` with a typed
   error.

## Architecture

Hexagonal (ports & adapters):

```
cmd/server            entrypoint: config load, DI wiring, graceful shutdown
internal/domain       Rate/Pair types + typed error taxonomy
internal/ports        interfaces (RateProvider, RateRepository)
internal/service      oracle: cache lookup → provider fallback → cache + history
internal/adapters/
  api                 chi router, handlers, middleware (request-id, recover, logs)
  provider            resilient HTTP provider (retry + circuit breaker); two
                      response parsers (frankfurter, ratesapi)
  repository          PostgreSQL rate-history store (parameterized SQL)
internal/config       YAML + env config, validated fail-fast on startup
pkg/cache             concurrency-safe TTL cache
pkg/logger            zap structured logging
pkg/metrics           Prometheus metrics on a private registry
pkg/utils             currency + decimal validation
```

## Providers

Providers are configured as an **ordered list**; order defines the fallback
chain. Each has a `kind` that selects the response parser:

- `frankfurter` — expects `{"base":"USD","rates":{"EUR":0.92}}`
- `ratesapi` — expects `{"base":"USD","target":"EUR","quote":"0.9187"}`

New upstreams can be supported by adding a parser branch in
`internal/adapters/provider`. Rate values are read with `json.Number`, so the
exact digits the provider sent are preserved (no float rounding).

## Quick start

```bash
cp .env.example .env
make run   # or: go run ./cmd/server -config=configs/config.yaml

curl -s localhost:8080/api/v1/rates/USD/EUR
curl -s "localhost:8080/api/v1/rates?base=GBP&quote=USD"
```

## Configuration

Values come from `configs/config.yaml` and/or environment (env wins). Key
variables:

| Env | Meaning |
|-----|---------|
| `SERVER_PORT` | HTTP port (default 8080) |
| `FX_PROVIDERS` | Ordered chain `name\|kind\|base_url`, comma-separated (overrides YAML) |
| `CACHE_TTL` | Cache time-to-live, e.g. `60s` |
| `DATABASE_DSN` | Postgres DSN; setting it enables rate history |
| `LOG_LEVEL` | `debug` \| `info` \| `warn` \| `error` |

The server **fails fast** on startup if no providers are configured or a
provider is missing a name/base_url/valid kind.

## Database migrations

Persistence is optional. When `DATABASE_DSN` is set, the oracle **runs pending
migrations automatically on startup** and records them in a `schema_migrations`
table. Migrations are defined in Go
(`internal/adapters/repository/migration.go`) with versioned up/down SQL.

```bash
go run ./cmd/server -rollback 1   # roll back the last migration and exit
```

`migrations/001_init.sql` is also provided as a standalone reference.

## Building `go.sum`

The repository ships a clean `go.mod` without a `go.sum`; run `go mod tidy`
(or `make deps`) once with network access to generate it.

## Production features

Multi-provider fallback, per-provider retry + circuit breaker, TTL caching,
exact-decimal rate handling (`json.Number` / `big.Rat`), request-id correlation,
structured logs, Prometheus metrics (cache hits, provider outcomes, fallbacks),
a stable error-code → HTTP-status mapping, graceful shutdown, and automatic
migrations.

## Per-source-file logging (Logrus)

In addition to the primary structured logger (zap, used for console/DI logging),
this module ships a **Logrus** per-source-file logger in `pkg/flog`. Every source
file writes its own log file under `logs/`, named `6_<file>.log`
(module number + source file name), e.g. `6_main.log`,
`6_config.log`. Each file registers itself with the logger, and a
Logrus hook routes entries to the matching file (JSON formatted). The `logs/`
directory is created on startup and is git-ignored. `go.sum` for the added
`github.com/sirupsen/logrus` dependency is generated on first `go mod tidy`.
