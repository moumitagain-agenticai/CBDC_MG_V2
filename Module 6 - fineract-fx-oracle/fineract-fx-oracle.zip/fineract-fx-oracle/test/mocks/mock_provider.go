package mocks

import (
	"context"
	"sync"

	"github.com/fineract/fx-oracle/internal/domain"
	"github.com/fineract/fx-oracle/internal/ports"
)

// FakeProvider is a configurable test double for ports.RateProvider.
type FakeProvider struct {
	ProviderName string
	RateValue    string
	Err          error
	Calls        int
}

var _ ports.RateProvider = (*FakeProvider)(nil)

func (f *FakeProvider) Name() string { return f.ProviderName }

func (f *FakeProvider) GetRate(_ context.Context, base, quote string) (domain.Rate, error) {
	f.Calls++
	if f.Err != nil {
		return domain.Rate{}, f.Err
	}
	return domain.Rate{Base: base, Quote: quote, Rate: f.RateValue, Provider: f.ProviderName}, nil
}

// FakeRepo records saved rates.
type FakeRepo struct {
	mu    sync.Mutex
	Saved []domain.Rate
}

var _ ports.RateRepository = (*FakeRepo)(nil)

func (r *FakeRepo) Save(_ context.Context, rate domain.Rate) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.Saved = append(r.Saved, rate)
	return nil
}

func (r *FakeRepo) Ping(_ context.Context) error { return nil }
