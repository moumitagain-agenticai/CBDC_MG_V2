//go:build integration

package integration

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/fx-oracle/internal/adapters/api"
	"github.com/fineract/fx-oracle/internal/adapters/provider"
	"github.com/fineract/fx-oracle/internal/config"
	"github.com/fineract/fx-oracle/internal/ports"
	"github.com/fineract/fx-oracle/internal/service"
	"github.com/fineract/fx-oracle/pkg/cache"
	"github.com/fineract/fx-oracle/pkg/metrics"
)

func providerCfg(name, url string) config.ProviderConfig {
	return config.ProviderConfig{Name: name, Kind: "frankfurter", BaseURL: url, Timeout: 2 * time.Second, MaxRetries: 0, BreakerMaxReq: 3}
}

func TestFallbackAndCache_EndToEnd(t *testing.T) {
	// Primary always fails.
	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "upstream boom", http.StatusInternalServerError)
	}))
	defer primary.Close()

	// Backup succeeds and counts how many times it is hit (to prove caching).
	var backupHits int32
	backup := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt32(&backupHits, 1)
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"base":"USD","rates":{"EUR":0.9231}}`)
	}))
	defer backup.Close()

	providers := []ports.RateProvider{
		provider.New(providerCfg("primary", primary.URL)),
		provider.New(providerCfg("backup", backup.URL)),
	}
	oracle := service.NewOracle(providers, cache.NewTTL(time.Minute), nil, metrics.New(), zap.NewNop())
	srv := httptest.NewServer(api.NewRouter(api.NewHandler(oracle), metrics.New(), zap.NewNop(), 0))
	defer srv.Close()

	// First call: primary fails, falls back to backup.
	rate := getRate(t, srv.URL+"/api/v1/rates/USD/EUR")
	assert.Equal(t, "backup", rate.Provider)
	assert.Equal(t, "0.9231", rate.Rate)
	assert.False(t, rate.Cached)

	// Second call: served from cache; backup not hit again.
	rate2 := getRate(t, srv.URL+"/api/v1/rates/USD/EUR")
	assert.True(t, rate2.Cached)
	assert.Equal(t, int32(1), atomic.LoadInt32(&backupHits), "backup should be hit exactly once")
}

func TestAllProvidersDown_Returns502(t *testing.T) {
	down := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "boom", http.StatusInternalServerError)
	}))
	defer down.Close()

	providers := []ports.RateProvider{provider.New(providerCfg("only", down.URL))}
	oracle := service.NewOracle(providers, cache.NewTTL(time.Minute), nil, metrics.New(), zap.NewNop())
	srv := httptest.NewServer(api.NewRouter(api.NewHandler(oracle), metrics.New(), zap.NewNop(), 0))
	defer srv.Close()

	resp, err := http.Get(srv.URL + "/api/v1/rates/USD/EUR")
	require.NoError(t, err)
	defer resp.Body.Close()
	assert.Equal(t, http.StatusBadGateway, resp.StatusCode)
}

type rateResp struct {
	Base, Quote, Rate, Provider string
	Cached                      bool
}

func getRate(t *testing.T, url string) rateResp {
	t.Helper()
	resp, err := http.Get(url)
	require.NoError(t, err)
	defer resp.Body.Close()
	require.Equal(t, http.StatusOK, resp.StatusCode)
	var r rateResp
	require.NoError(t, json.NewDecoder(resp.Body).Decode(&r))
	return r
}
