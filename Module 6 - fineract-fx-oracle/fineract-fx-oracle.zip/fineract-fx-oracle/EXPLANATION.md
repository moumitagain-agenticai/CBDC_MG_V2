# EXPLANATION — fineract-fx-oracle (plain language)

This document explains the module in simple terms, for reviewers who are not Go
engineers.

## What is this module for?

To move money across borders you need to know the **exchange rate** — for
example, how many euros one US dollar is worth right now. This module is the
platform's **exchange-rate service**. Other modules ask it "what is USD to EUR?"
and it answers with a current rate.

It does three things that make it reliable:

1. **Talks to several rate sources**, not just one.
2. **Remembers recent answers for a short time** (caching), so it is fast and
   doesn't hammer the sources.
3. **Falls back** to the next source if one is down, so a single outage doesn't
   break the platform.

## How an answer is produced

When someone asks for USD → EUR:

1. **Check the memory (cache).** If we fetched this pair a moment ago and the
   answer is still fresh, we return it instantly and mark it `cached: true`. No
   outside call is made.
2. **Ask the providers in order.** If there's nothing fresh cached, we ask the
   first provider. If it answers, great. If it is slow, erroring, or has been
   failing repeatedly, we don't wait around — we move on to the next provider.
   This is the **fallback chain**.
3. **Use the first good answer.** We remember it (so the next request is fast),
   optionally save it to a history table, and return it as `cached: false`.
4. **If everyone is down**, we return a clear error instead of a wrong number.

There's also a shortcut: asking for a currency against itself (USD → USD) always
returns `1` without calling anyone.

## Why the "circuit breaker" matters

Each provider is wrapped in a **circuit breaker**. If a provider keeps failing,
the breaker "opens" and we stop calling it for a little while — so we fail over
to the next provider immediately instead of waiting for repeated timeouts. After
a cooldown it tries again automatically. This keeps the service fast even when a
source is having a bad day.

## Why rates are text, not numbers

Money math with normal decimal numbers (floating point) can introduce tiny
rounding errors. To avoid that, rates are carried as **exact text** all the way
through — we keep the exact digits the provider gave us.

## The reliability features, in one line each

- **Multiple providers**: more than one source of truth.
- **Fallback**: automatically use the next source if one fails.
- **Caching**: fast repeat answers, less load on providers, with a short expiry.
- **Circuit breaker + retries**: shrug off blips, fail over fast on real outages.
- **Exact rates**: no floating-point rounding.
- **Optional history**: every fetched rate can be recorded in Postgres.
- **Graceful shutdown**: on stop, in-flight requests finish before exit.
- **Metrics + logs**: cache hits, provider outcomes and fallbacks are all visible.

## Relationship to the other modules

The connectors (Modules 2–4) move CBDC and the ISO 20022 gateway (Module 5)
formats the payment messages. This oracle supplies the **exchange rates** those
cross-border flows need. It is built to the same conventions (same layout,
config, logging, metrics, migrations) so the whole platform is consistent.

## What was verified

`go build ./...`, `go vet ./...`, unit tests (cache expiry; oracle fallback,
caching, identity, all-providers-failed, validation, history) and integration
tests (end-to-end fallback + caching over real HTTP providers) all pass. The
running server, given a failing primary and a healthy backup, returned the
backup's rate, served the next identical request from cache, answered the
identity pair as `1`, rejected an invalid currency with `400`, and reported the
provider chain on `/readyz`.
