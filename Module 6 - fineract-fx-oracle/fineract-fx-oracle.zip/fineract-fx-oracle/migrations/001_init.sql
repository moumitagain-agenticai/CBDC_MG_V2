-- fineract-fx-oracle: rate-history audit trail.
-- Apply with: psql "$DATABASE_DSN" -f migrations/001_init.sql

CREATE TABLE IF NOT EXISTS fx_rate_history (
    id        UUID PRIMARY KEY,
    base      TEXT        NOT NULL,
    quote     TEXT        NOT NULL,
    rate      TEXT        NOT NULL,
    provider  TEXT        NOT NULL,
    as_of     TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fx_rate_history_pair ON fx_rate_history (base, quote);
CREATE INDEX IF NOT EXISTS idx_fx_rate_history_as_of ON fx_rate_history (as_of);
