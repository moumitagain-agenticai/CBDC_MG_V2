package store

import (
	"context"
	"sync"
	"time"

	idem "github.com/fineract/cbdc/idempotency-gateway"
)

// Memory is an in-memory Store for tests and local development. Its Reserve is
// atomic under a mutex.
type Memory struct {
	mu      sync.Mutex
	records map[string]*idem.Record
}

var _ Store = (*Memory)(nil)

// NewMemory returns a ready in-memory store.
func NewMemory() *Memory { return &Memory{records: make(map[string]*idem.Record)} }

func clone(r *idem.Record) *idem.Record {
	cp := *r
	cp.Result.Payload = append([]byte(nil), r.Result.Payload...)
	if r.CompletedAt != nil {
		t := *r.CompletedAt
		cp.CompletedAt = &t
	}
	return &cp
}

// Reserve atomically creates an IN_PROGRESS record if key is new.
func (s *Memory) Reserve(_ context.Context, key, requestHash string) (*idem.Record, bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if existing, ok := s.records[key]; ok {
		return clone(existing), false, nil
	}
	s.records[key] = &idem.Record{
		Key: key, RequestHash: requestHash, Status: idem.StatusInProgress, CreatedAt: time.Now().UTC(),
	}
	return nil, true, nil
}

// Complete stores the result and marks the record COMPLETED.
func (s *Memory) Complete(_ context.Context, key string, res idem.Result) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	r, ok := s.records[key]
	if !ok {
		return idem.NewInternalError("record not found for completion", nil)
	}
	now := time.Now().UTC()
	r.Status = idem.StatusCompleted
	r.Result = idem.Result{Code: res.Code, Payload: append([]byte(nil), res.Payload...)}
	r.CompletedAt = &now
	return nil
}

// Delete removes a record.
func (s *Memory) Delete(_ context.Context, key string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.records, key)
	return nil
}

// Get returns a record or nil.
func (s *Memory) Get(_ context.Context, key string) (*idem.Record, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if r, ok := s.records[key]; ok {
		return clone(r), nil
	}
	return nil, nil
}

// Ping is always healthy.
func (s *Memory) Ping(_ context.Context) error { return nil }
