package store_test

import (
	"context"
	"os"
	"testing"

	idem "github.com/fineract/cbdc/idempotency-gateway"
	"github.com/fineract/cbdc/idempotency-gateway/store"
)

func TestPostgresReserveComplete(t *testing.T) {
	dsn := os.Getenv("DATABASE_DSN")
	if dsn == "" {
		t.Skip("DATABASE_DSN not set")
	}
	db, err := store.Open(dsn)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer db.Close()
	pg := store.NewPostgres(db)
	ctx := context.Background()
	if err := pg.Migrate(ctx); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	key, hash := "itest-key", idem.HashRequest([]byte(`{"amount":1}`))
	_, created, err := pg.Reserve(ctx, key, hash)
	if err != nil {
		t.Fatalf("reserve: %v", err)
	}
	if !created {
		// clean up from a prior run and retry once
		_ = pg.Delete(ctx, key)
		_, created, _ = pg.Reserve(ctx, key, hash)
	}
	if !created {
		t.Fatal("expected to win reservation")
	}
	// second reserve returns existing, not created
	existing, created2, err := pg.Reserve(ctx, key, hash)
	if err != nil || created2 || existing == nil {
		t.Fatalf("second reserve: created=%v existing=%v err=%v", created2, existing, err)
	}
	if err := pg.Complete(ctx, key, idem.Result{Code: 200, Payload: []byte("ok")}); err != nil {
		t.Fatalf("complete: %v", err)
	}
	got, _ := pg.Get(ctx, key)
	if got == nil || got.Status != idem.StatusCompleted {
		t.Fatalf("want completed, got %+v", got)
	}
	_ = pg.Delete(ctx, key)
}
