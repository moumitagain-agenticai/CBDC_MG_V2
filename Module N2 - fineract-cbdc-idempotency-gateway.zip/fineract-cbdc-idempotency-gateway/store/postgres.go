package store

import (
	"context"
	"database/sql"
	"errors"
	"time"

	idem "github.com/fineract/cbdc/idempotency-gateway"
	_ "github.com/lib/pq"
)

// Postgres is a PostgreSQL-backed Store. Reserve uses INSERT ... ON CONFLICT DO
// NOTHING so concurrent callers race to a single winner atomically.
type Postgres struct{ db *sql.DB }

var _ Store = (*Postgres)(nil)

// NewPostgres wraps an existing *sql.DB.
func NewPostgres(db *sql.DB) *Postgres { return &Postgres{db: db} }

// Open opens a PostgreSQL database from a DSN.
func Open(dsn string) (*sql.DB, error) { return sql.Open("postgres", dsn) }

const schema = `
CREATE TABLE IF NOT EXISTS idempotency_records (
    key          TEXT PRIMARY KEY,
    request_hash TEXT NOT NULL,
    status       TEXT NOT NULL,
    result_code  INTEGER NOT NULL DEFAULT 0,
    result_body  BYTEA,
    created_at   TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ
);`

// Migrate creates the idempotency table if it does not exist.
func (s *Postgres) Migrate(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, schema)
	return err
}

// Reserve atomically inserts an IN_PROGRESS record if key is new.
func (s *Postgres) Reserve(ctx context.Context, key, requestHash string) (*idem.Record, bool, error) {
	const ins = `INSERT INTO idempotency_records (key, request_hash, status, created_at)
	    VALUES ($1,$2,$3,$4) ON CONFLICT (key) DO NOTHING`
	res, err := s.db.ExecContext(ctx, ins, key, requestHash, idem.StatusInProgress, time.Now().UTC())
	if err != nil {
		return nil, false, err
	}
	if n, _ := res.RowsAffected(); n == 1 {
		return nil, true, nil
	}
	existing, err := s.Get(ctx, key)
	if err != nil {
		return nil, false, err
	}
	return existing, false, nil
}

// Complete stores the result and marks the record COMPLETED.
func (s *Postgres) Complete(ctx context.Context, key string, r idem.Result) error {
	const q = `UPDATE idempotency_records
	    SET status=$2, result_code=$3, result_body=$4, completed_at=now() WHERE key=$1`
	res, err := s.db.ExecContext(ctx, q, key, idem.StatusCompleted, r.Code, r.Payload)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return idem.NewInternalError("record not found for completion", nil)
	}
	return nil
}

// Delete removes a record.
func (s *Postgres) Delete(ctx context.Context, key string) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM idempotency_records WHERE key=$1`, key)
	return err
}

// Get returns a record by key, or nil if absent.
func (s *Postgres) Get(ctx context.Context, key string) (*idem.Record, error) {
	const q = `SELECT key, request_hash, status, result_code, result_body, created_at, completed_at
	    FROM idempotency_records WHERE key=$1`
	var r idem.Record
	var body []byte
	err := s.db.QueryRowContext(ctx, q, key).
		Scan(&r.Key, &r.RequestHash, &r.Status, &r.Result.Code, &body, &r.CreatedAt, &r.CompletedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	r.Result.Payload = body
	return &r, nil
}

// Ping checks database health.
func (s *Postgres) Ping(ctx context.Context) error { return s.db.PingContext(ctx) }
