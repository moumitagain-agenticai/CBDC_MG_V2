// Package store defines the idempotency persistence port and provides an
// in-memory implementation and a PostgreSQL implementation (using lib/pq).
//
// The critical operation is Reserve: it must atomically create an IN_PROGRESS
// record for a key only if that key does not already exist, so that concurrent
// callers race to a single winner. The PostgreSQL store implements this with
// INSERT ... ON CONFLICT DO NOTHING.
package store

import (
	"context"

	idem "github.com/fineract/cbdc/idempotency-gateway"
)

// Store persists idempotency records.
type Store interface {
	// Reserve atomically inserts an IN_PROGRESS record for key with the given
	// request hash if key does not exist. It returns created=true when the caller
	// won the reservation, or the existing record when key was already present.
	Reserve(ctx context.Context, key, requestHash string) (existing *idem.Record, created bool, err error)
	// Complete transitions an IN_PROGRESS record to COMPLETED with its result.
	Complete(ctx context.Context, key string, res idem.Result) error
	// Delete removes a record (used to release a reservation after a failure so
	// the key can be retried).
	Delete(ctx context.Context, key string) error
	// Get returns a record by key, or nil if absent.
	Get(ctx context.Context, key string) (*idem.Record, error)
	// Ping checks backend health.
	Ping(ctx context.Context) error
}
