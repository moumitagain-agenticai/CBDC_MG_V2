-- fineract-cbdc-idempotency-gateway: idempotency records table.
CREATE TABLE IF NOT EXISTS idempotency_records (
    key          TEXT PRIMARY KEY,
    request_hash TEXT NOT NULL,
    status       TEXT NOT NULL,
    result_code  INTEGER NOT NULL DEFAULT 0,
    result_body  BYTEA,
    created_at   TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ
);
