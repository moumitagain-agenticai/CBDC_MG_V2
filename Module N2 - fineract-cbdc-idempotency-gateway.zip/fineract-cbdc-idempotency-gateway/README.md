# fineract-cbdc-idempotency-gateway  (Module N2 — P0 new build)

**Idempotency for every Fineract write.** It ensures a write happens **at most
once per idempotency key**, so a retried request never produces a **duplicate
transaction**. It is designed to sit **directly in front of the API adapter
(Module 69)** on the money path.

Module path: `github.com/fineract/cbdc/idempotency-gateway` · Go 1.21+.

## Position on the money path

```
caller ─▶ idempotency-gateway (N2) ─▶ api-adapter (69) ─▶ Fineract
```

The client supplies an **idempotency key** (e.g. an `Idempotency-Key` header) and
the gateway wraps the adapter call.

## Behaviour

For a call `Execute(ctx, key, requestHash, op)`:

| Situation | Result |
|-----------|--------|
| First call for `key` | `op` runs once; its result is stored and returned — `OutcomeExecuted`. |
| Retry: same `key`, same request | Stored result is replayed; `op` does **not** run — `OutcomeReplayed`. |
| Same `key`, **different** request | Rejected — `conflict` (a key must identify one request). |
| Concurrent call while the first is still running | Rejected — `in_progress`; retry shortly. |
| First call where `op` fails | Reservation is released so the **same key can be retried**; `op`'s error is returned. |

`requestHash` is any stable hash of the request; `idempotency.HashRequest(body)`
provides a SHA-256 helper.

```go
g := gateway.New(store)              // store: in-memory or Postgres
res, outcome, err := g.Execute(ctx, key, idempotency.HashRequest(body),
    func(ctx context.Context) (idempotency.Result, error) {
        // call the API adapter (Module 69) here
        return idempotency.Result{Code: 200, Payload: respJSON}, nil
    })
```

## Why the store's `Reserve` is the heart of it

`Reserve` atomically creates an `IN_PROGRESS` record **only if the key is new**,
so two concurrent callers with the same key race to a single winner. The
PostgreSQL store implements this with `INSERT ... ON CONFLICT (key) DO NOTHING`;
the in-memory store does it under a mutex.

## Packages

| Path | Responsibility |
|------|----------------|
| `idempotency.go` (`idempotency`) | `Record`, `Result`, `Status`, `HashRequest`. |
| `errors.go` | Classified errors + `CodeOf` (`validation`, `conflict`, `in_progress`, `internal`). |
| `store/` | The `Store` port + in-memory and PostgreSQL (`Reserve`, `Complete`, `Delete`, `Get`, `Migrate`). |
| `gateway/` | The `Gateway`: `Execute`, `Outcome`, `Operation`. |
| `migrations/001_init.sql` | The `idempotency_records` table DDL. |

## Build, test, run

```bash
go build ./...
go vet ./...
go test ./...                       # unit tests (in-memory)
DATABASE_DSN=postgres://... go test ./store/...   # DB-gated Postgres test
go run ./examples                   # 3 sends -> op runs once
```

## Relationship to N1

N1 (outbox-relay) delivers events **at-least-once**, so consumers may see
duplicates. N2 is the mechanism that makes those consumers — and any retrying
client — safe: it collapses duplicates back to a single effect.

## Dependencies

Only `github.com/lib/pq` (PostgreSQL driver); everything else is the standard
library. The store is behind an interface, so any backend can be substituted.
