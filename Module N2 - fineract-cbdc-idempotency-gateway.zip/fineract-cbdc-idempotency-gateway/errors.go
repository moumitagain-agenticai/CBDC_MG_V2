package idempotency

import (
	"errors"
	"fmt"
)

// Code classifies a gateway error.
type Code string

// Error codes.
const (
	CodeValidation Code = "validation"  // missing key or request hash
	CodeConflict   Code = "conflict"    // same key reused with a different request
	CodeInProgress Code = "in_progress" // an earlier call with this key is still running
	CodeInternal   Code = "internal"    // store or unexpected failure
)

// Error is the classified error type returned by the gateway.
type Error struct {
	Code    Code
	Message string
	Err     error
}

func (e *Error) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

func (e *Error) Unwrap() error { return e.Err }

func newErr(c Code, m string, err error) *Error { return &Error{Code: c, Message: m, Err: err} }

// NewValidationError reports a missing key or request hash.
func NewValidationError(m string, e error) *Error { return newErr(CodeValidation, m, e) }

// NewConflictError reports a key reused with a different request.
func NewConflictError(m string, e error) *Error { return newErr(CodeConflict, m, e) }

// NewInProgressError reports that an earlier call with this key is still running.
func NewInProgressError(m string, e error) *Error { return newErr(CodeInProgress, m, e) }

// NewInternalError reports a store or unexpected failure.
func NewInternalError(m string, e error) *Error { return newErr(CodeInternal, m, e) }

// CodeOf returns the classification of err.
func CodeOf(err error) Code {
	if err == nil {
		return ""
	}
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return CodeInternal
}
