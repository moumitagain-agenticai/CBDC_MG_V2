# BUILD REPORT — fineract-cbdc-idempotency-gateway (Module N2)

Toolchain: Go 1.22 (module declares `go 1.21`). Module path:
`github.com/fineract/cbdc/idempotency-gateway`.

| Check | Command | Result |
|-------|---------|--------|
| Formatting | `gofmt -l .` | clean |
| Dependencies | `go mod tidy` | clean (`github.com/lib/pq`) |
| Build | `go build ./...` | pass (exit 0) |
| Vet | `go vet ./...` | pass (exit 0) |
| Unit tests | `go test ./...` | pass (gateway, store) |
| Example | `go run ./examples` | 3 sends → op runs once, retry replays, key-reuse conflicts |

Requirement coverage (finalised list, N2): idempotency for ALL Fineract writes,
sitting in front of the API adapter (69), preventing duplicate transactions.
Implemented via an atomic `Reserve` (Postgres `INSERT ... ON CONFLICT DO NOTHING`;
in-memory under a mutex) plus `Execute`, which runs the wrapped operation at most
once and replays the stored result to duplicate callers.

Tests: first call executes; duplicate replays without running the op; same key +
different request → conflict; failed op releases the reservation so the key can
be retried; a still-in-progress key → in_progress; validation of key and hash. A
DB-gated Postgres reserve/complete test runs when `DATABASE_DSN` is set.

Design note: the gateway lives in its own package (`gateway`) so the dependency
graph is acyclic — `gateway` depends on `idempotency` and `store`, neither of
which depends back on it. Nothing pushed to any remote.
