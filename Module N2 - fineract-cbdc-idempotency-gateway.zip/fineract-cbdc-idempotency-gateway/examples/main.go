// Command example demonstrates the idempotency gateway sitting in front of a
// money-path write: the same request retried with the same key runs the
// operation once and replays the stored result on the retry.
//
//	go run ./examples
package main

import (
	"context"
	"fmt"

	idem "github.com/fineract/cbdc/idempotency-gateway"
	"github.com/fineract/cbdc/idempotency-gateway/gateway"
	"github.com/fineract/cbdc/idempotency-gateway/store"
)

func main() {
	ctx := context.Background()
	g := gateway.New(store.NewMemory())

	requestBody := []byte(`{"account":"acc-1","amount":50000,"op":"settle"}`)
	key := "client-supplied-idempotency-key-123"
	hash := idem.HashRequest(requestBody)

	calls := 0
	// In production this closure would call the API adapter (Module 69).
	settle := func(context.Context) (idem.Result, error) {
		calls++
		return idem.Result{Code: 200, Payload: []byte(`{"settle_txn":"txn-abc"}`)}, nil
	}

	// First send: executes.
	res1, out1, _ := g.Execute(ctx, key, hash, settle)
	fmt.Printf("send #1: outcome=%s code=%d body=%s\n", out1, res1.Code, res1.Payload)

	// Retry (network glitch, client resend): replays, does NOT run the op again.
	res2, out2, _ := g.Execute(ctx, key, hash, settle)
	fmt.Printf("send #2: outcome=%s code=%d body=%s\n", out2, res2.Code, res2.Payload)

	// Same key, different request: rejected.
	_, _, err := g.Execute(ctx, key, idem.HashRequest([]byte(`{"amount":999}`)), settle)
	fmt.Printf("send #3 (same key, different body): error code=%s\n", idem.CodeOf(err))

	fmt.Printf("\nunderlying settle operation ran %d time(s) despite 3 sends\n", calls)
}
