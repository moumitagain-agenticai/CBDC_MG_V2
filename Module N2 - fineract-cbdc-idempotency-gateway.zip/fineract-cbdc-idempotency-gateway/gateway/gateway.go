// Package gateway holds the idempotency Gateway: it makes an operation run at
// most once per idempotency key. It depends on the idempotency domain and the
// store port, which keeps the dependency graph acyclic.
package gateway

import (
	"context"
	"strings"

	idem "github.com/fineract/cbdc/idempotency-gateway"
	"github.com/fineract/cbdc/idempotency-gateway/store"
)

// Outcome describes how Execute handled a call.
type Outcome string

// Execute outcomes.
const (
	OutcomeExecuted Outcome = "executed" // the operation ran (first time for this key)
	OutcomeReplayed Outcome = "replayed" // a stored result was returned; op did NOT run
)

// Operation is the write the gateway makes idempotent — for example a call to the
// API adapter (Module 69). It returns the Result to store and replay.
type Operation func(ctx context.Context) (idem.Result, error)

// Gateway makes operations idempotent by an idempotency key.
type Gateway struct {
	store store.Store
}

// New builds a gateway over a store.
func New(s store.Store) *Gateway { return &Gateway{store: s} }

// Execute runs op at most once per idempotency key.
//
//   - First call for a key: op runs; its result is stored and returned with
//     OutcomeExecuted. If op fails, the reservation is released so the key can be
//     retried, and op's error is returned.
//   - Later call, same key and same request: the stored result is returned with
//     OutcomeReplayed; op does NOT run.
//   - Later call, same key but a DIFFERENT request: a conflict error is returned.
//   - Concurrent call while the first is still running: an in-progress error is
//     returned; the caller should retry shortly.
func (g *Gateway) Execute(ctx context.Context, key, requestHash string, op Operation) (idem.Result, Outcome, error) {
	if strings.TrimSpace(key) == "" {
		return idem.Result{}, "", idem.NewValidationError("idempotency key is required", nil)
	}
	if strings.TrimSpace(requestHash) == "" {
		return idem.Result{}, "", idem.NewValidationError("request hash is required", nil)
	}

	existing, created, err := g.store.Reserve(ctx, key, requestHash)
	if err != nil {
		return idem.Result{}, "", idem.NewInternalError("reserve failed", err)
	}

	if !created {
		if existing.RequestHash != requestHash {
			return idem.Result{}, "", idem.NewConflictError("idempotency key reused with a different request", nil)
		}
		switch existing.Status {
		case idem.StatusCompleted:
			return existing.Result, OutcomeReplayed, nil
		case idem.StatusInProgress:
			return idem.Result{}, "", idem.NewInProgressError("an earlier request with this key is still in progress", nil)
		default:
			return idem.Result{}, "", idem.NewInternalError("record in unexpected state", nil)
		}
	}

	// We own the reservation: run the operation exactly once.
	res, opErr := op(ctx)
	if opErr != nil {
		_ = g.store.Delete(ctx, key) // release so a retry with the same key can proceed
		return idem.Result{}, OutcomeExecuted, opErr
	}
	if err := g.store.Complete(ctx, key, res); err != nil {
		return idem.Result{}, "", idem.NewInternalError("failed to store result", err)
	}
	return res, OutcomeExecuted, nil
}

// Health reports whether the backing store is reachable.
func (g *Gateway) Health(ctx context.Context) error { return g.store.Ping(ctx) }
