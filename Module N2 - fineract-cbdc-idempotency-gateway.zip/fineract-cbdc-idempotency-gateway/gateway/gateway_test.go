package gateway_test

import (
	"context"
	"errors"
	"testing"

	idem "github.com/fineract/cbdc/idempotency-gateway"
	"github.com/fineract/cbdc/idempotency-gateway/gateway"
	"github.com/fineract/cbdc/idempotency-gateway/store"
)

func newGateway() (*gateway.Gateway, *store.Memory) {
	s := store.NewMemory()
	return gateway.New(s), s
}

func okOp(code int, body string) gateway.Operation {
	return func(context.Context) (idem.Result, error) {
		return idem.Result{Code: code, Payload: []byte(body)}, nil
	}
}

func TestFirstCallExecutes(t *testing.T) {
	g, _ := newGateway()
	hash := idem.HashRequest([]byte(`{"amount":100}`))
	res, outcome, err := g.Execute(context.Background(), "key-1", hash, okOp(200, "done"))
	if err != nil {
		t.Fatalf("execute: %v", err)
	}
	if outcome != gateway.OutcomeExecuted || res.Code != 200 || string(res.Payload) != "done" {
		t.Fatalf("unexpected: outcome=%s res=%+v", outcome, res)
	}
}

func TestDuplicateReplaysWithoutRunningOp(t *testing.T) {
	g, _ := newGateway()
	hash := idem.HashRequest([]byte(`{"amount":100}`))
	ctx := context.Background()
	if _, _, err := g.Execute(ctx, "key-1", hash, okOp(200, "first")); err != nil {
		t.Fatalf("first: %v", err)
	}
	ran := false
	res, outcome, err := g.Execute(ctx, "key-1", hash, func(context.Context) (idem.Result, error) {
		ran = true
		return idem.Result{Code: 999, Payload: []byte("SHOULD-NOT-RUN")}, nil
	})
	if err != nil {
		t.Fatalf("second: %v", err)
	}
	if ran {
		t.Fatal("operation must NOT run on a duplicate key")
	}
	if outcome != gateway.OutcomeReplayed || res.Code != 200 || string(res.Payload) != "first" {
		t.Fatalf("expected replay of first result, got outcome=%s res=%+v", outcome, res)
	}
}

func TestSameKeyDifferentRequestConflicts(t *testing.T) {
	g, _ := newGateway()
	ctx := context.Background()
	if _, _, err := g.Execute(ctx, "key-1", idem.HashRequest([]byte(`{"amount":100}`)), okOp(200, "a")); err != nil {
		t.Fatalf("first: %v", err)
	}
	_, _, err := g.Execute(ctx, "key-1", idem.HashRequest([]byte(`{"amount":999}`)), okOp(200, "b"))
	if idem.CodeOf(err) != idem.CodeConflict {
		t.Fatalf("want conflict for same key different request, got %v", err)
	}
}

func TestFailedOperationAllowsRetry(t *testing.T) {
	g, _ := newGateway()
	ctx := context.Background()
	hash := idem.HashRequest([]byte(`{"amount":100}`))
	boom := func(context.Context) (idem.Result, error) { return idem.Result{}, errors.New("downstream failed") }
	if _, _, err := g.Execute(ctx, "key-1", hash, boom); err == nil {
		t.Fatal("expected error from failing op")
	}
	res, outcome, err := g.Execute(ctx, "key-1", hash, okOp(200, "recovered"))
	if err != nil {
		t.Fatalf("retry: %v", err)
	}
	if outcome != gateway.OutcomeExecuted || string(res.Payload) != "recovered" {
		t.Fatalf("expected retry to execute, got outcome=%s res=%+v", outcome, res)
	}
}

func TestInProgressConflicts(t *testing.T) {
	g, s := newGateway()
	ctx := context.Background()
	hash := idem.HashRequest([]byte(`{"amount":100}`))
	if _, created, err := s.Reserve(ctx, "key-1", hash); err != nil || !created {
		t.Fatalf("reserve: created=%v err=%v", created, err)
	}
	_, _, err := g.Execute(ctx, "key-1", hash, okOp(200, "x"))
	if idem.CodeOf(err) != idem.CodeInProgress {
		t.Fatalf("want in_progress, got %v", err)
	}
}

func TestValidation(t *testing.T) {
	g, _ := newGateway()
	ctx := context.Background()
	if _, _, err := g.Execute(ctx, "", "hash", okOp(200, "x")); idem.CodeOf(err) != idem.CodeValidation {
		t.Fatalf("want validation for empty key, got %v", err)
	}
	if _, _, err := g.Execute(ctx, "key", "", okOp(200, "x")); idem.CodeOf(err) != idem.CodeValidation {
		t.Fatalf("want validation for empty hash, got %v", err)
	}
}
