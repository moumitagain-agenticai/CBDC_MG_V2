// Package idempotency is Module N2 of the E1 CBDC platform: an idempotency
// gateway that ensures every Fineract write happens AT MOST ONCE, even if a
// caller retries. It is designed to sit directly in front of the API adapter
// (Module 69) on the money path, so a retried payment never results in a
// duplicate transaction.
//
// A caller wraps its write in Gateway.Execute together with an idempotency key
// and a hash of the request. The first call with a given key runs the operation
// and stores its result; any later call with the same key returns the stored
// result without running the operation again. Re-using a key with a DIFFERENT
// request is rejected as a conflict.
package idempotency

import (
	"crypto/sha256"
	"encoding/hex"
	"time"
)

// Status is the lifecycle state of an idempotency record.
type Status string

// Record statuses.
const (
	StatusInProgress Status = "IN_PROGRESS" // operation is currently executing
	StatusCompleted  Status = "COMPLETED"   // operation finished; result stored
)

// Result is the stored outcome of a wrapped operation. Code is an
// application-defined status (for example an HTTP status), and Payload is the
// opaque response body to replay to duplicate callers.
type Result struct {
	Code    int    `json:"code"`
	Payload []byte `json:"payload"`
}

// Record is a persisted idempotency entry keyed by the caller's idempotency key.
type Record struct {
	Key         string     `json:"key"`
	RequestHash string     `json:"request_hash"`
	Status      Status     `json:"status"`
	Result      Result     `json:"result"`
	CreatedAt   time.Time  `json:"created_at"`
	CompletedAt *time.Time `json:"completed_at,omitempty"`
}

// HashRequest returns a stable hex-encoded SHA-256 of the request bytes, for use
// as the requestHash argument to Execute. Callers may supply their own hash
// instead if they prefer.
func HashRequest(body []byte) string {
	sum := sha256.Sum256(body)
	return hex.EncodeToString(sum[:])
}
