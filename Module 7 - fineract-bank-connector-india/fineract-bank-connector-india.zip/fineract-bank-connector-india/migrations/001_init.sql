-- fineract-bank-connector-india: transaction audit trail.
-- Stores only masked, non-sensitive data. Never PAN, PIN, CVV or OTP.
-- Apply with: psql "$DATABASE_DSN" -f migrations/001_init.sql

CREATE TABLE IF NOT EXISTS bank_transactions (
    id                  UUID PRIMARY KEY,
    reference_id        TEXT        NOT NULL DEFAULT '',
    transaction_id      TEXT        NOT NULL DEFAULT '',
    type                TEXT        NOT NULL,
    status              TEXT        NOT NULL,
    amount              TEXT        NOT NULL DEFAULT '0',
    currency            TEXT        NOT NULL DEFAULT 'INR',
    masked_card         TEXT        NOT NULL DEFAULT '',
    beneficiary_account TEXT        NOT NULL DEFAULT '',
    beneficiary_ifsc    TEXT        NOT NULL DEFAULT '',
    utr                 TEXT        NOT NULL DEFAULT '',
    failure_reason      TEXT        NOT NULL DEFAULT '',
    created_at          TIMESTAMPTZ NOT NULL,
    updated_at          TIMESTAMPTZ NOT NULL
);

-- Idempotency: at most one row per non-empty reference_id.
CREATE UNIQUE INDEX IF NOT EXISTS idx_bank_transactions_reference_id
    ON bank_transactions (reference_id) WHERE reference_id <> '';
CREATE INDEX IF NOT EXISTS idx_bank_transactions_transaction_id ON bank_transactions (transaction_id);
CREATE INDEX IF NOT EXISTS idx_bank_transactions_status ON bank_transactions (status);
