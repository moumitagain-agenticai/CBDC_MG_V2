# BUILD REPORT — fineract-bank-connector-india

## Summary

India sponsor-bank API bridge providing debit-card authentication, IMPS transfer
initiation and OTP verification. It follows the same production convention as the
other modules (hexagonal layout, resilient upstream client with retry + circuit
breaker, optional Postgres persistence, Go migration runner, Prometheus metrics,
graceful shutdown) and adds strict handling of sensitive instrument data.

## Verification

| Check | Command | Result |
|-------|---------|--------|
| Build | `go build ./...` | PASS (exit 0) |
| Vet | `go vet ./...` | PASS (exit 0) |
| Unit tests | `go test ./...` | PASS (bridge service) |
| Integration | `go test -tags integration ./test/integration/...` | PASS |
| Binary | `go build -o bin/bank-connector-india ./cmd/server` | PASS (~16 MB) |
| Formatting | `gofmt -l .` | clean (no files) |

## Runtime evidence

- **Integration test `TestFullFlow_CardAuthImpsOtp`** drives the full flow over a
  real `BankClient` against an in-process HTTP bank: card authentication returns
  `masked_card = ************1111`; IMPS initiation returns `OTP_REQUIRED`; OTP
  verification returns `SUCCESS` with the bank UTR. Bad-card and bad-IFSC
  requests are rejected with `400`.
- **Live server run**: an over-limit IMPS transfer (`amount = 500000.01`) was
  rejected with HTTP `400`, and a scan of the running server's logs found
  **0 occurrences** of the test card number — confirming PAN is never logged.

## Security posture

- PAN, PIN, CVV and OTP are never persisted or logged. Card and account numbers
  are masked to the last four digits (`utils.MaskCard`, `utils.MaskAccount`)
  before any storage or response.
- Request bodies are size-limited and reject unknown fields.
- The audit table stores only masked, non-sensitive data.

## Resilience & correctness

- Sponsor-bank client: per-call timeout, retry-with-backoff (`go-retryablehttp`)
  and circuit breaker (`gobreaker`); typed error mapping to HTTP status.
- IMPS initiation is idempotent on `reference_id`.
- Amounts handled as decimal strings / `big.Rat` (no floating-point), enforcing
  ≤2 fraction digits and the ₹5,00,000 IMPS ceiling.

## Notes

- The repository ships a clean `go.mod` with no `go.sum`; `go mod tidy` (or
  `make deps`) generates `go.sum` on first run with network access.
- Persistence is optional: with no `DATABASE_DSN` the repository is a true nil
  interface and the service runs fully in-memory.
- Nothing here is pushed to any Git remote; the module is self-contained.
