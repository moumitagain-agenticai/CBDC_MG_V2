# fineract-bank-connector-india

Module 7 of the E1 Cross-Border CBDC platform. It is the **India sponsor-bank
API bridge** for fiat rails: it authenticates customers with their **debit
card**, initiates **IMPS** fund transfers, and completes them after **OTP
verification** — the standard two-factor flow an Indian sponsor bank requires.

It builds and runs stand-alone and follows the same convention as the other
modules (hexagonal layout, resilient upstream client with retry + circuit
breaker, optional Postgres persistence, Prometheus metrics, graceful shutdown,
Go migration runner).

## Security first

This module handles sensitive instrument data. By design it **never persists or
logs** the PAN (card number), PIN, CVV or OTP. Those fields are used only to
call the bank. Everything stored or returned is **masked** (e.g.
`************1111`) or a non-sensitive reference (auth reference, bank
transaction id, UTR).

## The flow

```
1. POST /api/v1/card/authenticate   -> auth_reference   (card authenticated)
2. POST /api/v1/imps/transfer       -> OTP_REQUIRED      (bank sends OTP to mobile)
3. POST /api/v1/otp/verify          -> SUCCESS + UTR     (transfer executed)
```

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/v1/card/authenticate` | Authenticate a debit card |
| POST | `/api/v1/imps/transfer` | Initiate an IMPS transfer (returns `OTP_REQUIRED`) |
| POST | `/api/v1/otp/verify` | Verify OTP; returns the bank **UTR** on success |
| GET | `/api/v1/transactions/{transaction_id}` | Transaction status |
| GET | `/healthz` / `/readyz` | Liveness / readiness (readiness pings the bank) |
| GET | `/metrics` | Prometheus metrics |

## Validation

Requests are validated before any bank call:

- **Card**: Luhn checksum + length, expiry not in the past.
- **IMPS amount**: positive, ≤2 fraction digits, and **≤ ₹5,00,000** (the NPCI
  per-transaction IMPS ceiling).
- **Beneficiary**: either `beneficiary_account` + `beneficiary_ifsc`
  (IFSC `^[A-Z]{4}0[A-Z0-9]{6}$`) **or** `beneficiary_mmid` (7 digits) +
  `beneficiary_mobile` (10 digits).
- **OTP**: 4–6 digits.

## Architecture

Hexagonal (ports & adapters):

```
cmd/server            entrypoint: config load, DI wiring, graceful shutdown
internal/domain       card/IMPS/OTP types, statuses, validation, error taxonomy
internal/ports        interfaces (BankClient, TransactionRepository)
internal/service      bridge: orchestrates card auth -> IMPS -> OTP; idempotency
internal/adapters/
  api                 chi router, handlers (body size limits), middleware
  client              sponsor-bank HTTP client (retry + circuit breaker; auth
                      modes apikey|oauth2|mtls)
  repository          PostgreSQL audit store (masked data only)
internal/config       YAML + env config, validated fail-fast on startup
pkg/logger            zap structured logging (never logs sensitive fields)
pkg/metrics           Prometheus metrics on a private registry
pkg/utils             Luhn / IFSC / account / OTP / mobile validators, masking
```

## Resilience

The sponsor-bank client wraps every call in a timeout, retry-with-backoff
(`go-retryablehttp`) and a circuit breaker (`gobreaker`). Upstream failures map
to typed domain errors and a stable HTTP status (`502` for upstream/circuit,
`504` for timeout, `401` for auth). IMPS initiation is **idempotent** on
`reference_id`: a repeated request returns the original result instead of
issuing a second transfer.

## Quick start

```bash
cp .env.example .env    # set BANK_BASE_URL, BANK_API_KEY
make run                # or: go run ./cmd/server -config=configs/config.yaml

curl -X POST localhost:8080/api/v1/card/authenticate -H 'Content-Type: application/json' \
  -d '{"card_number":"4111111111111111","expiry_month":12,"expiry_year":2030,"pin":"1234","customer_ref":"CUST-1"}'
```

## Configuration

Values come from `configs/config.yaml` and/or environment (env wins):

| Env | Meaning |
|-----|---------|
| `SERVER_PORT` | HTTP port (default 8080) |
| `BANK_BASE_URL` | Sponsor-bank API base URL |
| `BANK_AUTH_MODE` | `apikey` \| `oauth2` \| `mtls` |
| `BANK_API_KEY` | API key (auth_mode=apikey) |
| `BANK_OAUTH_TOKEN_URL` / `BANK_CLIENT_ID` / `BANK_CLIENT_SECRET` | OAuth2 client-credentials |
| `DATABASE_DSN` | Postgres DSN; setting it enables the audit trail |
| `LOG_LEVEL` | `debug` \| `info` \| `warn` \| `error` |

The server **fails fast** on startup if the bank base URL or the selected auth
mode's credentials are missing.

## Database migrations

Persistence is optional. When `DATABASE_DSN` is set the bridge **runs pending
migrations automatically on startup** (tracked in `schema_migrations`).
Migrations are defined in Go (`internal/adapters/repository/migration.go`) with
versioned up/down SQL; `migrations/001_init.sql` is also provided as a reference.

```bash
go run ./cmd/server -rollback 1   # roll back the last migration and exit
```

## Building `go.sum`

The repository ships a clean `go.mod` without a `go.sum`; run `go mod tidy`
(or `make deps`) once with network access to generate it.

## Per-source-file logging (Logrus)

In addition to the primary structured logger (zap, used for console/DI logging),
this module ships a **Logrus** per-source-file logger in `pkg/flog`. Every source
file writes its own log file under `logs/`, named `7_<file>.log`
(module number + source file name), e.g. `7_main.log`,
`7_config.log`. Each file registers itself with the logger, and a
Logrus hook routes entries to the matching file (JSON formatted). The `logs/`
directory is created on startup and is git-ignored. `go.sum` for the added
`github.com/sirupsen/logrus` dependency is generated on first `go mod tidy`.
