//go:build integration

package integration

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/bank-connector-india/internal/adapters/api"
	"github.com/fineract/bank-connector-india/internal/adapters/client"
	"github.com/fineract/bank-connector-india/internal/config"
	"github.com/fineract/bank-connector-india/internal/service"
	"github.com/fineract/bank-connector-india/pkg/metrics"
)

func fakeBank() *httptest.Server {
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/card/authenticate", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"auth_reference": "AUTH-1", "approved": true})
	})
	mux.HandleFunc("/v1/imps/initiate", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"transaction_id": "BANKTXN-1", "otp_required": true})
	})
	mux.HandleFunc("/v1/otp/verify", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"transaction_id": "BANKTXN-1", "approved": true, "utr": "UTRXYZ789"})
	})
	mux.HandleFunc("/v1/transactions/", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"transaction_id": "BANKTXN-1", "status": "SUCCESS", "utr": "UTRXYZ789"})
	})
	mux.HandleFunc("/v1/health", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	return httptest.NewServer(mux)
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}

func testServer(t *testing.T, bankURL string) *httptest.Server {
	t.Helper()
	bc, err := client.New(config.BankConfig{
		BaseURL: bankURL, AuthMode: "apikey", APIKey: "k",
		Timeout: 2 * time.Second, MaxRetries: 0, BreakerMaxReq: 3, BreakerName: "test",
	})
	require.NoError(t, err)
	svc := service.NewBridge(bc, nil, metrics.New(), zap.NewNop())
	return httptest.NewServer(api.NewRouter(api.NewHandler(svc, 1<<20), metrics.New(), zap.NewNop(), 0))
}

func post(t *testing.T, url, body string) (int, map[string]any) {
	t.Helper()
	resp, err := http.Post(url, "application/json", bytes.NewReader([]byte(body)))
	require.NoError(t, err)
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	var m map[string]any
	_ = json.Unmarshal(b, &m)
	return resp.StatusCode, m
}

func TestFullFlow_CardAuthImpsOtp(t *testing.T) {
	bank := fakeBank()
	defer bank.Close()
	srv := testServer(t, bank.URL)
	defer srv.Close()

	// 1) Card authentication.
	code, res := post(t, srv.URL+"/api/v1/card/authenticate",
		`{"card_number":"4111111111111111","expiry_month":12,"expiry_year":2030,"pin":"1234","customer_ref":"CUST-1"}`)
	require.Equal(t, http.StatusOK, code)
	assert.Equal(t, "AUTH-1", res["auth_reference"])
	assert.Equal(t, "************1111", res["masked_card"])

	// 2) IMPS initiation -> OTP required.
	code, res = post(t, srv.URL+"/api/v1/imps/transfer",
		`{"auth_reference":"AUTH-1","reference_id":"REF-1","amount":"1500.00","remitter_account":"123456789012","beneficiary_name":"Beta","beneficiary_account":"987654321098","beneficiary_ifsc":"HDFC0001234"}`)
	require.Equal(t, http.StatusOK, code)
	assert.Equal(t, "OTP_REQUIRED", res["status"])
	assert.Equal(t, "BANKTXN-1", res["transaction_id"])

	// 3) OTP verification -> success + UTR.
	code, res = post(t, srv.URL+"/api/v1/otp/verify", `{"transaction_id":"BANKTXN-1","otp":"123456"}`)
	require.Equal(t, http.StatusOK, code)
	assert.Equal(t, "SUCCESS", res["status"])
	assert.Equal(t, "UTRXYZ789", res["utr"])
}

func TestValidation_BadCardRejected(t *testing.T) {
	bank := fakeBank()
	defer bank.Close()
	srv := testServer(t, bank.URL)
	defer srv.Close()

	code, _ := post(t, srv.URL+"/api/v1/card/authenticate",
		`{"card_number":"1234","expiry_month":12,"expiry_year":2030,"customer_ref":"C"}`)
	assert.Equal(t, http.StatusBadRequest, code)
}

func TestValidation_BadIFSCRejected(t *testing.T) {
	bank := fakeBank()
	defer bank.Close()
	srv := testServer(t, bank.URL)
	defer srv.Close()

	code, _ := post(t, srv.URL+"/api/v1/imps/transfer",
		`{"auth_reference":"A","reference_id":"R","amount":"10.00","remitter_account":"123456789012","beneficiary_name":"B","beneficiary_account":"987654321098","beneficiary_ifsc":"BAD"}`)
	assert.Equal(t, http.StatusBadRequest, code)
}
