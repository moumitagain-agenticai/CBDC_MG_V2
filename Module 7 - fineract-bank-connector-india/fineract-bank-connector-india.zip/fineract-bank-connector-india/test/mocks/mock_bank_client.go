package mocks

import (
	"context"
	"sync"

	"github.com/fineract/bank-connector-india/internal/domain"
	"github.com/fineract/bank-connector-india/internal/ports"
)

// MockBankClient is a configurable test double for ports.BankClient.
type MockBankClient struct {
	AuthResp   ports.CardAuthResponse
	AuthErr    error
	InitResp   ports.ImpsInitResponse
	InitErr    error
	OtpResp    ports.OtpResponse
	OtpErr     error
	StatusResp ports.StatusResponse
	StatusErr  error
	HealthErr  error

	LastCardNumber string // to assert we never persist the full PAN elsewhere
}

var _ ports.BankClient = (*MockBankClient)(nil)

func (m *MockBankClient) AuthenticateCard(_ context.Context, req domain.CardAuthRequest) (ports.CardAuthResponse, error) {
	m.LastCardNumber = req.CardNumber
	return m.AuthResp, m.AuthErr
}
func (m *MockBankClient) InitiateIMPS(_ context.Context, _ domain.ImpsTransferRequest) (ports.ImpsInitResponse, error) {
	return m.InitResp, m.InitErr
}
func (m *MockBankClient) VerifyOTP(_ context.Context, _ string, _ string) (ports.OtpResponse, error) {
	return m.OtpResp, m.OtpErr
}
func (m *MockBankClient) GetStatus(_ context.Context, _ string) (ports.StatusResponse, error) {
	return m.StatusResp, m.StatusErr
}
func (m *MockBankClient) Health(_ context.Context) error { return m.HealthErr }

// MockRepo is an in-memory TransactionRepository.
type MockRepo struct {
	mu      sync.Mutex
	byID    map[string]*domain.Transaction
	byRef   map[string]*domain.Transaction
	byTxnID map[string]*domain.Transaction
}

var _ ports.TransactionRepository = (*MockRepo)(nil)

func NewMockRepo() *MockRepo {
	return &MockRepo{
		byID:    map[string]*domain.Transaction{},
		byRef:   map[string]*domain.Transaction{},
		byTxnID: map[string]*domain.Transaction{},
	}
}

func (r *MockRepo) Save(_ context.Context, tx *domain.Transaction) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	cp := *tx
	r.byID[tx.ID] = &cp
	if tx.ReferenceID != "" {
		r.byRef[tx.ReferenceID] = &cp
	}
	if tx.TransactionID != "" {
		r.byTxnID[tx.TransactionID] = &cp
	}
	return nil
}

func (r *MockRepo) UpdateStatus(_ context.Context, id string, status domain.Status, utr, reason string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	t, ok := r.byID[id]
	if !ok {
		return domain.NewNotFoundError("not found", nil)
	}
	t.Status = status
	t.UTR = utr
	t.FailureReason = reason
	return nil
}

func (r *MockRepo) GetByReferenceID(_ context.Context, ref string) (*domain.Transaction, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if t, ok := r.byRef[ref]; ok {
		return t, nil
	}
	return nil, domain.NewNotFoundError("not found", nil)
}

func (r *MockRepo) GetByTransactionID(_ context.Context, txID string) (*domain.Transaction, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if t, ok := r.byTxnID[txID]; ok {
		return t, nil
	}
	return nil, domain.NewNotFoundError("not found", nil)
}

func (r *MockRepo) GetByID(_ context.Context, id string) (*domain.Transaction, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if t, ok := r.byID[id]; ok {
		return t, nil
	}
	return nil, domain.NewNotFoundError("not found", nil)
}

func (r *MockRepo) Ping(_ context.Context) error { return nil }
