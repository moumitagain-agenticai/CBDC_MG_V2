package config

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"fmt"
	"os"
	"strconv"
	"time"

	"gopkg.in/yaml.v3"
)

// Config is the fully-resolved application configuration.
type Config struct {
	Server   ServerConfig   `yaml:"server"`
	Bank     BankConfig     `yaml:"bank"`
	Database DatabaseConfig `yaml:"database"`
	Log      LogConfig      `yaml:"log"`
}

type ServerConfig struct {
	Port            int           `yaml:"port"`
	ReadTimeout     time.Duration `yaml:"read_timeout"`
	WriteTimeout    time.Duration `yaml:"write_timeout"`
	ShutdownTimeout time.Duration `yaml:"shutdown_timeout"`
	RateLimitPerMin int           `yaml:"rate_limit_per_min"`
}

// BankConfig holds the India sponsor-bank API connection and resilience settings.
type BankConfig struct {
	BaseURL       string        `yaml:"base_url"`
	AuthMode      string        `yaml:"auth_mode"` // apikey | oauth2 | mtls
	APIKey        string        `yaml:"api_key"`
	OAuthTokenURL string        `yaml:"oauth_token_url"`
	ClientID      string        `yaml:"client_id"`
	ClientSecret  string        `yaml:"client_secret"`
	Timeout       time.Duration `yaml:"timeout"`
	MaxRetries    int           `yaml:"max_retries"`
	BreakerMaxReq uint32        `yaml:"breaker_max_requests"`
	BreakerName   string        `yaml:"breaker_name"`
}

type DatabaseConfig struct {
	DSN             string        `yaml:"dsn"`
	MaxOpenConns    int           `yaml:"max_open_conns"`
	MaxIdleConns    int           `yaml:"max_idle_conns"`
	ConnMaxLifetime time.Duration `yaml:"conn_max_lifetime"`
	Enabled         bool          `yaml:"enabled"`
}

type LogConfig struct {
	Level string `yaml:"level"`
	JSON  bool   `yaml:"json"`
}

// Default returns production-sane defaults.
func Default() Config {
	return Config{
		Server: ServerConfig{
			Port:            8080,
			ReadTimeout:     10 * time.Second,
			WriteTimeout:    15 * time.Second,
			ShutdownTimeout: 20 * time.Second,
			RateLimitPerMin: 120,
		},
		Bank: BankConfig{
			AuthMode:      "apikey",
			Timeout:       8 * time.Second,
			MaxRetries:    3,
			BreakerMaxReq: 5,
			BreakerName:   "sponsor-bank-india",
		},
		Database: DatabaseConfig{
			MaxOpenConns:    25,
			MaxIdleConns:    5,
			ConnMaxLifetime: 30 * time.Minute,
			Enabled:         false,
		},
		Log: LogConfig{Level: "info", JSON: true},
	}
}

// Load reads YAML (if present), applies env overrides, then validates.
func Load(path string) (Config, error) {
	cfg := Default()
	if path != "" {
		data, err := os.ReadFile(path)
		if err == nil {
			if err := yaml.Unmarshal(data, &cfg); err != nil {
				return Config{}, fmt.Errorf("parsing config %s: %w", path, err)
			}
		} else if !os.IsNotExist(err) {
			return Config{}, fmt.Errorf("reading config %s: %w", path, err)
		}
	}
	applyEnvOverrides(&cfg)
	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

func applyEnvOverrides(cfg *Config) {
	if v := os.Getenv("SERVER_PORT"); v != "" {
		if p, err := strconv.Atoi(v); err == nil {
			cfg.Server.Port = p
		}
	}
	if v := os.Getenv("BANK_BASE_URL"); v != "" {
		cfg.Bank.BaseURL = v
	}
	if v := os.Getenv("BANK_AUTH_MODE"); v != "" {
		cfg.Bank.AuthMode = v
	}
	if v := os.Getenv("BANK_API_KEY"); v != "" {
		cfg.Bank.APIKey = v
	}
	if v := os.Getenv("BANK_OAUTH_TOKEN_URL"); v != "" {
		cfg.Bank.OAuthTokenURL = v
	}
	if v := os.Getenv("BANK_CLIENT_ID"); v != "" {
		cfg.Bank.ClientID = v
	}
	if v := os.Getenv("BANK_CLIENT_SECRET"); v != "" {
		cfg.Bank.ClientSecret = v
	}
	if v := os.Getenv("DATABASE_DSN"); v != "" {
		cfg.Database.DSN = v
		cfg.Database.Enabled = true
	}
	if v := os.Getenv("LOG_LEVEL"); v != "" {
		cfg.Log.Level = v
	}
}

// Validate fails fast on inconsistent configuration.
func (c Config) Validate() error {
	if c.Server.Port <= 0 || c.Server.Port > 65535 {
		return fmt.Errorf("invalid server port: %d", c.Server.Port)
	}
	if c.Bank.BaseURL == "" {
		return fmt.Errorf("bank.base_url is required")
	}
	switch c.Bank.AuthMode {
	case "apikey":
		if c.Bank.APIKey == "" {
			return fmt.Errorf("bank.api_key is required when auth_mode=apikey")
		}
	case "oauth2":
		if c.Bank.OAuthTokenURL == "" || c.Bank.ClientID == "" || c.Bank.ClientSecret == "" {
			return fmt.Errorf("oauth2 auth requires oauth_token_url, client_id and client_secret")
		}
	case "mtls":
		// Certificates are mounted at deploy time.
	default:
		return fmt.Errorf("unsupported bank.auth_mode %q (want apikey|oauth2|mtls)", c.Bank.AuthMode)
	}
	if c.Database.Enabled && c.Database.DSN == "" {
		return fmt.Errorf("database.dsn is required when database is enabled")
	}
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_config_Logfile.log at runtime.
var _ = func() bool { flog.For("7_config").Info("source file initialized"); return true }()
