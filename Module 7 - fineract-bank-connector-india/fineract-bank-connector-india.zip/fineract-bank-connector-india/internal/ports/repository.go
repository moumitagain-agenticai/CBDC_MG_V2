package ports

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"context"

	"github.com/fineract/bank-connector-india/internal/domain"
)

// TransactionRepository is the outbound port for the transaction audit trail.
// Implementations live in internal/adapters/repository and store only masked,
// non-sensitive data.
type TransactionRepository interface {
	// Save persists a new transaction record.
	Save(ctx context.Context, tx *domain.Transaction) error
	// UpdateStatus transitions a transaction to a new status, recording the UTR
	// and any failure reason.
	UpdateStatus(ctx context.Context, id string, status domain.Status, utr, failureReason string) error
	// GetByReferenceID enables idempotency checks on transfer initiation.
	GetByReferenceID(ctx context.Context, referenceID string) (*domain.Transaction, error)
	// GetByTransactionID fetches by the bank/bridge transaction id (for OTP + status).
	GetByTransactionID(ctx context.Context, transactionID string) (*domain.Transaction, error)
	// GetByID fetches a single transaction by internal id.
	GetByID(ctx context.Context, id string) (*domain.Transaction, error)
	// Ping verifies connectivity for readiness checks.
	Ping(ctx context.Context) error
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_repository_Logfile.log at runtime.
var _ = func() bool { flog.For("7_repository").Info("source file initialized"); return true }()
