package ports

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"context"

	"github.com/fineract/bank-connector-india/internal/domain"
)

// BankClient is the outbound port for the India sponsor-bank API bridge. It
// covers debit-card authentication, IMPS initiation and OTP verification.
type BankClient interface {
	// AuthenticateCard authenticates the customer via their debit card and
	// returns a short-lived auth reference.
	AuthenticateCard(ctx context.Context, req domain.CardAuthRequest) (CardAuthResponse, error)
	// InitiateIMPS starts an IMPS transfer. The bank typically responds that an
	// OTP has been dispatched to the registered mobile.
	InitiateIMPS(ctx context.Context, req domain.ImpsTransferRequest) (ImpsInitResponse, error)
	// VerifyOTP confirms a pending transfer and, on success, returns the UTR.
	VerifyOTP(ctx context.Context, transactionID, otp string) (OtpResponse, error)
	// GetStatus queries the current state of a transaction at the bank.
	GetStatus(ctx context.Context, transactionID string) (StatusResponse, error)
	// Health reports upstream reachability for readiness checks.
	Health(ctx context.Context) error
}

// CardAuthResponse is the bank's reply to a card authentication.
type CardAuthResponse struct {
	AuthReference string
	Approved      bool
	Message       string
}

// ImpsInitResponse is the bank's reply to an IMPS initiation.
type ImpsInitResponse struct {
	TransactionID string
	OTPRequired   bool
	Message       string
}

// OtpResponse is the bank's reply to an OTP verification.
type OtpResponse struct {
	TransactionID string
	Approved      bool
	UTR           string
	Message       string
}

// StatusResponse is the bank's reply to a status query.
type StatusResponse struct {
	TransactionID string
	Status        domain.Status
	UTR           string
	Message       string
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_bank_client_Logfile.log at runtime.
var _ = func() bool { flog.For("7_bank_client").Info("source file initialized"); return true }()
