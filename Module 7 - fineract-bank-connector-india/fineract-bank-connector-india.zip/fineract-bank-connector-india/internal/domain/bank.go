package domain

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"time"

	"github.com/fineract/bank-connector-india/pkg/utils"
)

// CurrencyINR is the only currency this bridge handles.
const CurrencyINR = "INR"

// ImpsPerTxnLimit is the NPCI per-transaction ceiling for IMPS (₹5,00,000).
const ImpsPerTxnLimit = "500000"

// Status is the lifecycle state of a bank operation.
type Status string

const (
	StatusPending     Status = "PENDING"
	StatusOTPRequired Status = "OTP_REQUIRED"
	StatusSuccess     Status = "SUCCESS"
	StatusFailed      Status = "FAILED"
)

// TxnType is the kind of bank operation recorded.
type TxnType string

const (
	TxnCardAuth TxnType = "CARD_AUTH"
	TxnIMPS     TxnType = "IMPS_TRANSFER"
	TxnOTP      TxnType = "OTP_VERIFY"
)

// CardAuthRequest authenticates a customer via their debit card. Sensitive
// fields (PAN, PIN/CVV) are used only to call the bank and are never persisted
// or logged.
type CardAuthRequest struct {
	CardNumber  string `json:"card_number"`
	ExpiryMonth int    `json:"expiry_month"`
	ExpiryYear  int    `json:"expiry_year"`
	PIN         string `json:"pin,omitempty"` // ATM PIN or CVV, per bank scheme
	CustomerRef string `json:"customer_ref"`
}

// Validate checks the card-auth request format. It does not verify the card
// exists — that is the bank's job.
func (r CardAuthRequest) Validate(now time.Time) error {
	if !utils.LuhnValid(r.CardNumber) {
		return NewValidationError("card_number failed format/Luhn check", nil)
	}
	if r.ExpiryMonth < 1 || r.ExpiryMonth > 12 {
		return NewValidationError("expiry_month must be 1–12", nil)
	}
	// Two- or four-digit years accepted; normalise to four digits for the check.
	yr := r.ExpiryYear
	if yr < 100 {
		yr += 2000
	}
	exp := time.Date(yr, time.Month(r.ExpiryMonth), 1, 0, 0, 0, 0, time.UTC).AddDate(0, 1, 0)
	if !exp.After(now) {
		return NewValidationError("card has expired", nil)
	}
	if r.PIN != "" && (len(r.PIN) < 3 || len(r.PIN) > 6) {
		return NewValidationError("pin/cvv length is invalid", nil)
	}
	if r.CustomerRef == "" {
		return NewValidationError("customer_ref is required", nil)
	}
	return nil
}

// CardAuthResult is returned to the caller after a card authentication.
type CardAuthResult struct {
	AuthReference string `json:"auth_reference"`
	MaskedCard    string `json:"masked_card"`
	Status        Status `json:"status"`
}

// ImpsTransferRequest initiates an IMPS fund transfer. Either an account+IFSC or
// an MMID+mobile pair identifies the beneficiary.
type ImpsTransferRequest struct {
	AuthReference     string `json:"auth_reference"`
	ReferenceID       string `json:"reference_id"` // idempotency key
	Amount            string `json:"amount"`
	RemitterAccount   string `json:"remitter_account"`
	BeneficiaryName   string `json:"beneficiary_name"`
	BeneficiaryAcct   string `json:"beneficiary_account,omitempty"`
	BeneficiaryIFSC   string `json:"beneficiary_ifsc,omitempty"`
	BeneficiaryMMID   string `json:"beneficiary_mmid,omitempty"`
	BeneficiaryMobile string `json:"beneficiary_mobile,omitempty"`
	Remarks           string `json:"remarks,omitempty"`
}

// Validate checks the transfer request.
func (r ImpsTransferRequest) Validate() error {
	if r.AuthReference == "" {
		return NewValidationError("auth_reference is required (authenticate the card first)", nil)
	}
	if r.ReferenceID == "" {
		return NewValidationError("reference_id is required for idempotency", nil)
	}
	if !utils.IsPositiveAmount(r.Amount) {
		return NewValidationError("amount must be a positive decimal with ≤2 fraction digits", nil)
	}
	if !utils.AmountAtMost(r.Amount, ImpsPerTxnLimit) {
		return NewValidationError("amount exceeds the IMPS per-transaction limit of ₹"+ImpsPerTxnLimit, nil)
	}
	if !utils.IsValidAccountNumber(r.RemitterAccount) {
		return NewValidationError("remitter_account is invalid", nil)
	}
	if r.BeneficiaryName == "" {
		return NewValidationError("beneficiary_name is required", nil)
	}
	// Route by account+IFSC or MMID+mobile.
	hasAcct := r.BeneficiaryAcct != "" || r.BeneficiaryIFSC != ""
	hasMMID := r.BeneficiaryMMID != "" || r.BeneficiaryMobile != ""
	switch {
	case hasAcct && !hasMMID:
		if !utils.IsValidAccountNumber(r.BeneficiaryAcct) {
			return NewValidationError("beneficiary_account is invalid", nil)
		}
		if !utils.IsValidIFSC(r.BeneficiaryIFSC) {
			return NewValidationError("beneficiary_ifsc is invalid", nil)
		}
	case hasMMID && !hasAcct:
		if !utils.IsValidMMID(r.BeneficiaryMMID) {
			return NewValidationError("beneficiary_mmid must be 7 digits", nil)
		}
		if !utils.IsValidMobile(r.BeneficiaryMobile) {
			return NewValidationError("beneficiary_mobile must be a valid 10-digit number", nil)
		}
	default:
		return NewValidationError("provide either beneficiary_account+beneficiary_ifsc or beneficiary_mmid+beneficiary_mobile", nil)
	}
	return nil
}

// OtpVerifyRequest confirms a pending IMPS transfer with the OTP the bank sent.
type OtpVerifyRequest struct {
	TransactionID string `json:"transaction_id"`
	OTP           string `json:"otp"`
}

// Validate checks the OTP request.
func (r OtpVerifyRequest) Validate() error {
	if r.TransactionID == "" {
		return NewValidationError("transaction_id is required", nil)
	}
	if !utils.IsValidOTP(r.OTP) {
		return NewValidationError("otp must be 4–6 digits", nil)
	}
	return nil
}

// OperationResult is the outcome of an IMPS/OTP operation.
type OperationResult struct {
	TransactionID string `json:"transaction_id"`
	Status        Status `json:"status"`
	UTR           string `json:"utr,omitempty"` // bank Unique Transaction Reference
	Message       string `json:"message,omitempty"`
}

// Transaction is the persisted audit record. It deliberately holds only
// non-sensitive, masked data — never PAN, PIN, CVV or OTP.
type Transaction struct {
	ID              string    `json:"id"`
	ReferenceID     string    `json:"reference_id"`
	TransactionID   string    `json:"transaction_id"`
	Type            TxnType   `json:"type"`
	Status          Status    `json:"status"`
	Amount          string    `json:"amount"`
	Currency        string    `json:"currency"`
	MaskedCard      string    `json:"masked_card,omitempty"`
	BeneficiaryAcct string    `json:"beneficiary_account,omitempty"` // masked
	BeneficiaryIFSC string    `json:"beneficiary_ifsc,omitempty"`
	UTR             string    `json:"utr,omitempty"`
	FailureReason   string    `json:"failure_reason,omitempty"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_bank_Logfile.log at runtime.
var _ = func() bool { flog.For("7_bank").Info("source file initialized"); return true }()
