package repository

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"context"
	"database/sql"
	"errors"
	"time"

	_ "github.com/lib/pq" // postgres driver (side-effect import)

	"github.com/fineract/bank-connector-india/internal/config"
	"github.com/fineract/bank-connector-india/internal/domain"
	"github.com/fineract/bank-connector-india/internal/ports"
)

// Repository is a PostgreSQL-backed transaction audit store. It persists only
// masked, non-sensitive data.
type Repository struct {
	db *sql.DB
}

var _ ports.TransactionRepository = (*Repository)(nil)

// OpenDB opens and configures a *sql.DB from database configuration.
func OpenDB(cfg config.DatabaseConfig) (*sql.DB, error) {
	db, err := sql.Open("postgres", cfg.DSN)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(cfg.MaxOpenConns)
	db.SetMaxIdleConns(cfg.MaxIdleConns)
	db.SetConnMaxLifetime(cfg.ConnMaxLifetime)
	return db, nil
}

// New builds a Repository over an existing *sql.DB.
func New(db *sql.DB) *Repository { return &Repository{db: db} }

func (r *Repository) Save(ctx context.Context, tx *domain.Transaction) error {
	const q = `
INSERT INTO bank_transactions
  (id, reference_id, transaction_id, type, status, amount, currency,
   masked_card, beneficiary_account, beneficiary_ifsc, utr, failure_reason, created_at, updated_at)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`
	_, err := r.db.ExecContext(ctx, q,
		tx.ID, tx.ReferenceID, tx.TransactionID, tx.Type, tx.Status, tx.Amount, tx.Currency,
		tx.MaskedCard, tx.BeneficiaryAcct, tx.BeneficiaryIFSC, tx.UTR, tx.FailureReason, tx.CreatedAt, tx.UpdatedAt,
	)
	if err != nil {
		return domain.NewInternalError("persist transaction", err)
	}
	return nil
}

func (r *Repository) UpdateStatus(ctx context.Context, id string, status domain.Status, utr, failureReason string) error {
	const q = `
UPDATE bank_transactions
   SET status = $2, utr = $3, failure_reason = $4, updated_at = $5
 WHERE id = $1`
	res, err := r.db.ExecContext(ctx, q, id, status, utr, failureReason, time.Now().UTC())
	if err != nil {
		return domain.NewInternalError("update transaction status", err)
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return domain.NewNotFoundError("transaction not found: "+id, nil)
	}
	return nil
}

func (r *Repository) GetByReferenceID(ctx context.Context, referenceID string) (*domain.Transaction, error) {
	return r.queryOne(ctx, `WHERE reference_id = $1 AND reference_id <> ''`, referenceID)
}

func (r *Repository) GetByTransactionID(ctx context.Context, transactionID string) (*domain.Transaction, error) {
	return r.queryOne(ctx, `WHERE transaction_id = $1 AND transaction_id <> ''`, transactionID)
}

func (r *Repository) GetByID(ctx context.Context, id string) (*domain.Transaction, error) {
	return r.queryOne(ctx, `WHERE id = $1`, id)
}

func (r *Repository) queryOne(ctx context.Context, where, arg string) (*domain.Transaction, error) {
	const cols = `
SELECT id, reference_id, transaction_id, type, status, amount, currency,
       masked_card, beneficiary_account, beneficiary_ifsc, utr, failure_reason, created_at, updated_at
  FROM bank_transactions `
	row := r.db.QueryRowContext(ctx, cols+where+" LIMIT 1", arg)
	var t domain.Transaction
	err := row.Scan(&t.ID, &t.ReferenceID, &t.TransactionID, &t.Type, &t.Status, &t.Amount, &t.Currency,
		&t.MaskedCard, &t.BeneficiaryAcct, &t.BeneficiaryIFSC, &t.UTR, &t.FailureReason, &t.CreatedAt, &t.UpdatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, domain.NewNotFoundError("transaction not found", err)
	}
	if err != nil {
		return nil, domain.NewInternalError("scan transaction", err)
	}
	return &t, nil
}

func (r *Repository) Ping(ctx context.Context) error {
	if err := r.db.PingContext(ctx); err != nil {
		return domain.NewInternalError("database ping failed", err)
	}
	return nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_transaction_repo_Logfile.log at runtime.
var _ = func() bool { flog.For("7_transaction_repo").Info("source file initialized"); return true }()
