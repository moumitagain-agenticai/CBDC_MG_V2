package api

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"

	"github.com/fineract/bank-connector-india/internal/domain"
	"github.com/fineract/bank-connector-india/internal/service"
)

// Handler exposes the bank bridge over HTTP.
type Handler struct {
	svc      *service.Bridge
	maxBytes int64
}

// NewHandler builds an HTTP handler around the bridge service.
func NewHandler(svc *service.Bridge, maxBytes int64) *Handler {
	if maxBytes <= 0 {
		maxBytes = 1 << 20
	}
	return &Handler{svc: svc, maxBytes: maxBytes}
}

// AuthenticateCard handles POST /api/v1/card/authenticate.
func (h *Handler) AuthenticateCard(w http.ResponseWriter, r *http.Request) {
	var req domain.CardAuthRequest
	if !decodeJSON(w, r, h.maxBytes, &req) {
		return
	}
	res, err := h.svc.AuthenticateCard(r.Context(), req)
	respond(w, http.StatusOK, res, err)
}

// InitiateTransfer handles POST /api/v1/imps/transfer.
func (h *Handler) InitiateTransfer(w http.ResponseWriter, r *http.Request) {
	var req domain.ImpsTransferRequest
	if !decodeJSON(w, r, h.maxBytes, &req) {
		return
	}
	res, err := h.svc.InitiateTransfer(r.Context(), req)
	respond(w, http.StatusOK, res, err)
}

// VerifyOTP handles POST /api/v1/otp/verify.
func (h *Handler) VerifyOTP(w http.ResponseWriter, r *http.Request) {
	var req domain.OtpVerifyRequest
	if !decodeJSON(w, r, h.maxBytes, &req) {
		return
	}
	res, err := h.svc.VerifyOTP(r.Context(), req)
	respond(w, http.StatusOK, res, err)
}

// GetStatus handles GET /api/v1/transactions/{transaction_id}.
func (h *Handler) GetStatus(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "transaction_id")
	res, err := h.svc.GetStatus(r.Context(), id)
	respond(w, http.StatusOK, res, err)
}

func (h *Handler) Liveness(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, h.svc.Liveness())
}

func (h *Handler) Readiness(w http.ResponseWriter, r *http.Request) {
	rep := h.svc.Readiness(r.Context())
	status := http.StatusOK
	if rep.Status != "ok" {
		status = http.StatusServiceUnavailable
	}
	writeJSON(w, status, rep)
}

// ---- helpers ----

func decodeJSON(w http.ResponseWriter, r *http.Request, max int64, dst any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, max)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		writeError(w, domain.NewValidationError("invalid JSON body", err))
		return false
	}
	return true
}

func respond(w http.ResponseWriter, status int, payload any, err error) {
	if err != nil {
		writeError(w, err)
		return
	}
	writeJSON(w, status, payload)
}

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if payload != nil {
		_ = json.NewEncoder(w).Encode(payload)
	}
}

type errorBody struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, err error) {
	de := domain.AsDomainError(err)
	var body errorBody
	body.Error.Code = string(de.Code)
	body.Error.Message = de.Message
	writeJSON(w, httpStatus(de.Code), body)
}

func httpStatus(code domain.ErrorCode) int {
	switch code {
	case domain.CodeValidation:
		return http.StatusBadRequest
	case domain.CodeNotFound:
		return http.StatusNotFound
	case domain.CodeConflict:
		return http.StatusConflict
	case domain.CodeUnauthorized:
		return http.StatusUnauthorized
	case domain.CodeTimeout:
		return http.StatusGatewayTimeout
	case domain.CodeUpstream, domain.CodeCircuitOpen:
		return http.StatusBadGateway
	default:
		return http.StatusInternalServerError
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_handlers_Logfile.log at runtime.
var _ = func() bool { flog.For("7_handlers").Info("source file initialized"); return true }()
