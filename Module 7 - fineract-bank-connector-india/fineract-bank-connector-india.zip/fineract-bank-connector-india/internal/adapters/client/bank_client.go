package client

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/hashicorp/go-retryablehttp"
	"github.com/sony/gobreaker"

	"github.com/fineract/bank-connector-india/internal/config"
	"github.com/fineract/bank-connector-india/internal/domain"
	"github.com/fineract/bank-connector-india/internal/ports"
)

// BankClient is the concrete India sponsor-bank API adapter. It wraps a retrying
// HTTP client with a circuit breaker and pluggable authentication.
type BankClient struct {
	baseURL string
	http    *retryablehttp.Client
	breaker *gobreaker.CircuitBreaker
	auth    authorizer
}

var _ ports.BankClient = (*BankClient)(nil)

// New builds a BankClient from configuration.
func New(cfg config.BankConfig) (*BankClient, error) {
	rc := retryablehttp.NewClient()
	rc.RetryMax = cfg.MaxRetries
	rc.HTTPClient.Timeout = cfg.Timeout
	rc.Logger = nil

	cb := gobreaker.NewCircuitBreaker(gobreaker.Settings{
		Name:        cfg.BreakerName,
		MaxRequests: cfg.BreakerMaxReq,
		Interval:    60 * time.Second,
		Timeout:     30 * time.Second,
		ReadyToTrip: func(c gobreaker.Counts) bool { return c.ConsecutiveFailures >= 5 },
	})

	auth, err := newAuthorizer(cfg)
	if err != nil {
		return nil, err
	}
	return &BankClient{
		baseURL: strings.TrimRight(cfg.BaseURL, "/"),
		http:    rc,
		breaker: cb,
		auth:    auth,
	}, nil
}

// ---- wire DTOs (bank API JSON shapes) ----

type cardAuthWire struct {
	CardNumber  string `json:"card_number"`
	ExpiryMonth int    `json:"expiry_month"`
	ExpiryYear  int    `json:"expiry_year"`
	PIN         string `json:"pin,omitempty"`
	CustomerRef string `json:"customer_ref"`
}

type cardAuthRespWire struct {
	AuthReference string `json:"auth_reference"`
	Approved      bool   `json:"approved"`
	Message       string `json:"message"`
}

type impsInitWire struct {
	AuthReference     string `json:"auth_reference"`
	ReferenceID       string `json:"reference_id"`
	Amount            string `json:"amount"`
	RemitterAccount   string `json:"remitter_account"`
	BeneficiaryName   string `json:"beneficiary_name"`
	BeneficiaryAcct   string `json:"beneficiary_account,omitempty"`
	BeneficiaryIFSC   string `json:"beneficiary_ifsc,omitempty"`
	BeneficiaryMMID   string `json:"beneficiary_mmid,omitempty"`
	BeneficiaryMobile string `json:"beneficiary_mobile,omitempty"`
	Remarks           string `json:"remarks,omitempty"`
}

type impsInitRespWire struct {
	TransactionID string `json:"transaction_id"`
	OTPRequired   bool   `json:"otp_required"`
	Message       string `json:"message"`
}

type otpWire struct {
	TransactionID string `json:"transaction_id"`
	OTP           string `json:"otp"`
}

type otpRespWire struct {
	TransactionID string `json:"transaction_id"`
	Approved      bool   `json:"approved"`
	UTR           string `json:"utr"`
	Message       string `json:"message"`
}

type statusRespWire struct {
	TransactionID string `json:"transaction_id"`
	Status        string `json:"status"`
	UTR           string `json:"utr"`
	Message       string `json:"message"`
}

// ---- BankClient methods ----

func (c *BankClient) AuthenticateCard(ctx context.Context, req domain.CardAuthRequest) (ports.CardAuthResponse, error) {
	body := cardAuthWire{
		CardNumber:  req.CardNumber,
		ExpiryMonth: req.ExpiryMonth,
		ExpiryYear:  req.ExpiryYear,
		PIN:         req.PIN,
		CustomerRef: req.CustomerRef,
	}
	var out cardAuthRespWire
	if err := c.postJSON(ctx, "/v1/card/authenticate", body, &out); err != nil {
		return ports.CardAuthResponse{}, err
	}
	return ports.CardAuthResponse{AuthReference: out.AuthReference, Approved: out.Approved, Message: out.Message}, nil
}

func (c *BankClient) InitiateIMPS(ctx context.Context, req domain.ImpsTransferRequest) (ports.ImpsInitResponse, error) {
	body := impsInitWire{
		AuthReference:     req.AuthReference,
		ReferenceID:       req.ReferenceID,
		Amount:            req.Amount,
		RemitterAccount:   req.RemitterAccount,
		BeneficiaryName:   req.BeneficiaryName,
		BeneficiaryAcct:   req.BeneficiaryAcct,
		BeneficiaryIFSC:   req.BeneficiaryIFSC,
		BeneficiaryMMID:   req.BeneficiaryMMID,
		BeneficiaryMobile: req.BeneficiaryMobile,
		Remarks:           req.Remarks,
	}
	var out impsInitRespWire
	if err := c.postJSON(ctx, "/v1/imps/initiate", body, &out); err != nil {
		return ports.ImpsInitResponse{}, err
	}
	return ports.ImpsInitResponse{TransactionID: out.TransactionID, OTPRequired: out.OTPRequired, Message: out.Message}, nil
}

func (c *BankClient) VerifyOTP(ctx context.Context, transactionID, otp string) (ports.OtpResponse, error) {
	var out otpRespWire
	if err := c.postJSON(ctx, "/v1/otp/verify", otpWire{TransactionID: transactionID, OTP: otp}, &out); err != nil {
		return ports.OtpResponse{}, err
	}
	return ports.OtpResponse{TransactionID: out.TransactionID, Approved: out.Approved, UTR: out.UTR, Message: out.Message}, nil
}

func (c *BankClient) GetStatus(ctx context.Context, transactionID string) (ports.StatusResponse, error) {
	var out statusRespWire
	path := "/v1/transactions/" + url.PathEscape(transactionID)
	if err := c.getJSON(ctx, path, &out); err != nil {
		return ports.StatusResponse{}, err
	}
	return ports.StatusResponse{
		TransactionID: out.TransactionID,
		Status:        mapStatus(out.Status),
		UTR:           out.UTR,
		Message:       out.Message,
	}, nil
}

func (c *BankClient) Health(ctx context.Context) error {
	return c.getJSON(ctx, "/v1/health", nil)
}

func mapStatus(s string) domain.Status {
	switch strings.ToUpper(strings.TrimSpace(s)) {
	case "SUCCESS", "COMPLETED":
		return domain.StatusSuccess
	case "OTP_REQUIRED", "PENDING_OTP":
		return domain.StatusOTPRequired
	case "FAILED", "DECLINED":
		return domain.StatusFailed
	default:
		return domain.StatusPending
	}
}

// ---- HTTP plumbing (breaker + retry + auth) ----

func (c *BankClient) postJSON(ctx context.Context, path string, body, out any) error {
	payload, err := json.Marshal(body)
	if err != nil {
		return domain.NewInternalError("marshal request", err)
	}
	return c.do(ctx, http.MethodPost, path, payload, out)
}

func (c *BankClient) getJSON(ctx context.Context, path string, out any) error {
	return c.do(ctx, http.MethodGet, path, nil, out)
}

func (c *BankClient) do(ctx context.Context, method, path string, payload []byte, out any) error {
	_, err := c.breaker.Execute(func() (any, error) {
		return nil, c.roundtrip(ctx, method, path, payload, out)
	})
	if err == gobreaker.ErrOpenState || err == gobreaker.ErrTooManyRequests {
		return domain.NewCircuitOpenError("sponsor bank circuit open", err)
	}
	return err
}

func (c *BankClient) roundtrip(ctx context.Context, method, path string, payload []byte, out any) error {
	var reader io.Reader
	if payload != nil {
		reader = bytes.NewReader(payload)
	}
	req, err := retryablehttp.NewRequestWithContext(ctx, method, c.baseURL+path, reader)
	if err != nil {
		return domain.NewInternalError("build request", err)
	}
	req.Header.Set("Accept", "application/json")
	if payload != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if err := c.auth.apply(ctx, req); err != nil {
		return err
	}

	resp, err := c.http.Do(req)
	if err != nil {
		if ctx.Err() == context.DeadlineExceeded {
			return domain.NewTimeoutError("sponsor bank timeout", err)
		}
		return domain.NewUpstreamError("sponsor bank request failed", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode >= 400 {
		return mapHTTPError(resp.StatusCode, respBody)
	}
	if out != nil && len(respBody) > 0 {
		if err := json.Unmarshal(respBody, out); err != nil {
			return domain.NewUpstreamError("decode sponsor bank response", err)
		}
	}
	return nil
}

func mapHTTPError(status int, body []byte) error {
	msg := fmt.Sprintf("sponsor bank returned %d", status)
	if snippet := strings.TrimSpace(string(body)); snippet != "" {
		msg = msg + ": " + snippet
	}
	switch {
	case status == http.StatusUnauthorized, status == http.StatusForbidden:
		return domain.NewUnauthorizedError(msg, nil)
	case status == http.StatusNotFound:
		return domain.NewNotFoundError(msg, nil)
	case status == http.StatusConflict:
		return domain.NewConflictError(msg, nil)
	default:
		return domain.NewUpstreamError(msg, nil)
	}
}

// ---- authentication strategies ----

type authorizer interface {
	apply(ctx context.Context, req *retryablehttp.Request) error
}

func newAuthorizer(cfg config.BankConfig) (authorizer, error) {
	switch cfg.AuthMode {
	case "apikey":
		return &apiKeyAuth{key: cfg.APIKey}, nil
	case "oauth2":
		return &oauthAuth{
			tokenURL:     cfg.OAuthTokenURL,
			clientID:     cfg.ClientID,
			clientSecret: cfg.ClientSecret,
			hc:           &http.Client{Timeout: cfg.Timeout},
		}, nil
	case "mtls":
		return &noopAuth{}, nil
	default:
		return nil, domain.NewInternalError("unsupported auth mode: "+cfg.AuthMode, nil)
	}
}

type noopAuth struct{}

func (noopAuth) apply(context.Context, *retryablehttp.Request) error { return nil }

type apiKeyAuth struct{ key string }

func (a *apiKeyAuth) apply(_ context.Context, req *retryablehttp.Request) error {
	req.Header.Set("X-API-Key", a.key)
	return nil
}

type oauthAuth struct {
	tokenURL     string
	clientID     string
	clientSecret string
	hc           *http.Client

	mu     sync.Mutex
	token  string
	expiry time.Time
}

func (a *oauthAuth) apply(ctx context.Context, req *retryablehttp.Request) error {
	tok, err := a.getToken(ctx)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+tok)
	return nil
}

func (a *oauthAuth) getToken(ctx context.Context) (string, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.token != "" && time.Now().Before(a.expiry) {
		return a.token, nil
	}
	form := url.Values{}
	form.Set("grant_type", "client_credentials")
	form.Set("client_id", a.clientID)
	form.Set("client_secret", a.clientSecret)

	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, a.tokenURL, strings.NewReader(form.Encode()))
	if err != nil {
		return "", domain.NewInternalError("build token request", err)
	}
	httpReq.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := a.hc.Do(httpReq)
	if err != nil {
		return "", domain.NewUpstreamError("oauth token request failed", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return "", domain.NewUnauthorizedError(fmt.Sprintf("oauth token endpoint returned %d", resp.StatusCode), nil)
	}
	var tr struct {
		AccessToken string `json:"access_token"`
		ExpiresIn   int    `json:"expires_in"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tr); err != nil {
		return "", domain.NewUpstreamError("decode oauth token", err)
	}
	if tr.AccessToken == "" {
		return "", domain.NewUnauthorizedError("empty access token from oauth endpoint", nil)
	}
	a.token = tr.AccessToken
	ttl := time.Duration(tr.ExpiresIn) * time.Second
	if ttl <= 0 {
		ttl = 5 * time.Minute
	}
	a.expiry = time.Now().Add(ttl - 30*time.Second)
	return a.token, nil
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_bank_client_Logfile.log at runtime.
var _ = func() bool { flog.For("7_bank_client").Info("source file initialized"); return true }()
