package service_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/fineract/bank-connector-india/internal/domain"
	"github.com/fineract/bank-connector-india/internal/ports"
	"github.com/fineract/bank-connector-india/internal/service"
	"github.com/fineract/bank-connector-india/pkg/metrics"
	"github.com/fineract/bank-connector-india/test/mocks"
)

// A Luhn-valid test PAN (Visa test number).
const testCard = "4111111111111111"

func cardReq() domain.CardAuthRequest {
	return domain.CardAuthRequest{CardNumber: testCard, ExpiryMonth: 12, ExpiryYear: 2030, PIN: "1234", CustomerRef: "CUST-1"}
}

func transferReq() domain.ImpsTransferRequest {
	return domain.ImpsTransferRequest{
		AuthReference: "AUTH-1", ReferenceID: "REF-1", Amount: "1500.00",
		RemitterAccount: "123456789012", BeneficiaryName: "Beta",
		BeneficiaryAcct: "987654321098", BeneficiaryIFSC: "HDFC0001234",
	}
}

func TestCardAuth_ApprovedAndMasked(t *testing.T) {
	repo := mocks.NewMockRepo()
	bank := &mocks.MockBankClient{AuthResp: ports.CardAuthResponse{AuthReference: "AUTH-9", Approved: true}}
	b := service.NewBridge(bank, repo, metrics.New(), zap.NewNop())

	res, err := b.AuthenticateCard(context.Background(), cardReq())
	require.NoError(t, err)
	assert.Equal(t, "AUTH-9", res.AuthReference)
	assert.Equal(t, "************1111", res.MaskedCard)

	// The persisted record must never contain the full PAN.
	rec, err := repo.GetByTransactionID(context.Background(), "AUTH-9")
	require.NoError(t, err)
	assert.Equal(t, "************1111", rec.MaskedCard)
	assert.NotContains(t, rec.MaskedCard, testCard)
}

func TestCardAuth_Declined(t *testing.T) {
	bank := &mocks.MockBankClient{AuthResp: ports.CardAuthResponse{Approved: false, Message: "invalid pin"}}
	b := service.NewBridge(bank, nil, metrics.New(), zap.NewNop())

	_, err := b.AuthenticateCard(context.Background(), cardReq())
	require.Error(t, err)
	assert.Equal(t, domain.CodeUnauthorized, domain.AsDomainError(err).Code)
}

func TestCardAuth_ExpiredCard(t *testing.T) {
	bank := &mocks.MockBankClient{AuthResp: ports.CardAuthResponse{Approved: true}}
	b := service.NewBridge(bank, nil, metrics.New(), zap.NewNop())
	req := cardReq()
	req.ExpiryYear = 2000
	_, err := b.AuthenticateCard(context.Background(), req)
	require.Error(t, err)
	assert.Equal(t, domain.CodeValidation, domain.AsDomainError(err).Code)
}

func TestIMPS_InitiateRequiresOTP(t *testing.T) {
	repo := mocks.NewMockRepo()
	bank := &mocks.MockBankClient{InitResp: ports.ImpsInitResponse{TransactionID: "BANKTXN-1", OTPRequired: true}}
	b := service.NewBridge(bank, repo, metrics.New(), zap.NewNop())

	res, err := b.InitiateTransfer(context.Background(), transferReq())
	require.NoError(t, err)
	assert.Equal(t, domain.StatusOTPRequired, res.Status)
	assert.Equal(t, "BANKTXN-1", res.TransactionID)

	// Beneficiary account is stored masked.
	rec, err := repo.GetByTransactionID(context.Background(), "BANKTXN-1")
	require.NoError(t, err)
	assert.Equal(t, "********1098", rec.BeneficiaryAcct)
}

func TestIMPS_Idempotent(t *testing.T) {
	repo := mocks.NewMockRepo()
	bank := &mocks.MockBankClient{InitResp: ports.ImpsInitResponse{TransactionID: "BANKTXN-1", OTPRequired: true}}
	b := service.NewBridge(bank, repo, metrics.New(), zap.NewNop())

	r1, err := b.InitiateTransfer(context.Background(), transferReq())
	require.NoError(t, err)
	r2, err := b.InitiateTransfer(context.Background(), transferReq())
	require.NoError(t, err)
	assert.Equal(t, r1.TransactionID, r2.TransactionID)
}

func TestIMPS_ExceedsLimit(t *testing.T) {
	bank := &mocks.MockBankClient{}
	b := service.NewBridge(bank, nil, metrics.New(), zap.NewNop())
	req := transferReq()
	req.Amount = "500000.01"
	_, err := b.InitiateTransfer(context.Background(), req)
	require.Error(t, err)
	assert.Equal(t, domain.CodeValidation, domain.AsDomainError(err).Code)
}

func TestOTP_VerifySuccessReturnsUTR(t *testing.T) {
	repo := mocks.NewMockRepo()
	bank := &mocks.MockBankClient{
		InitResp: ports.ImpsInitResponse{TransactionID: "BANKTXN-1", OTPRequired: true},
		OtpResp:  ports.OtpResponse{TransactionID: "BANKTXN-1", Approved: true, UTR: "UTR123456"},
	}
	b := service.NewBridge(bank, repo, metrics.New(), zap.NewNop())

	_, err := b.InitiateTransfer(context.Background(), transferReq())
	require.NoError(t, err)

	res, err := b.VerifyOTP(context.Background(), domain.OtpVerifyRequest{TransactionID: "BANKTXN-1", OTP: "123456"})
	require.NoError(t, err)
	assert.Equal(t, domain.StatusSuccess, res.Status)
	assert.Equal(t, "UTR123456", res.UTR)

	rec, _ := repo.GetByTransactionID(context.Background(), "BANKTXN-1")
	assert.Equal(t, domain.StatusSuccess, rec.Status)
	assert.Equal(t, "UTR123456", rec.UTR)
}

func TestOTP_InvalidFormat(t *testing.T) {
	b := service.NewBridge(&mocks.MockBankClient{}, nil, metrics.New(), zap.NewNop())
	_, err := b.VerifyOTP(context.Background(), domain.OtpVerifyRequest{TransactionID: "X", OTP: "12"})
	require.Error(t, err)
	assert.Equal(t, domain.CodeValidation, domain.AsDomainError(err).Code)
}
