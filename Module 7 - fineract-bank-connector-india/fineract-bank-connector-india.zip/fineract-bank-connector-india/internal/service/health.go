package service

import "github.com/fineract/bank-connector-india/pkg/flog"
import "context"

// HealthReport is the aggregated health of the bridge.
type HealthReport struct {
	Status string            `json:"status"`
	Checks map[string]string `json:"checks"`
}

// Liveness reports process health with no I/O.
func (b *Bridge) Liveness() HealthReport {
	return HealthReport{Status: "ok", Checks: map[string]string{"process": "ok"}}
}

// Readiness reports whether the bridge can serve traffic: the sponsor bank must
// be reachable and the database (if enabled) must respond.
func (b *Bridge) Readiness(ctx context.Context) HealthReport {
	checks := map[string]string{}
	status := "ok"

	if err := b.bank.Health(ctx); err != nil {
		checks["sponsor_bank"] = "error: " + err.Error()
		status = "degraded"
	} else {
		checks["sponsor_bank"] = "ok"
	}

	if b.repo != nil {
		if err := b.repo.Ping(ctx); err != nil {
			checks["database"] = "error: " + err.Error()
			status = "degraded"
		} else {
			checks["database"] = "ok"
		}
	}
	return HealthReport{Status: status, Checks: checks}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_health_Logfile.log at runtime.
var _ = func() bool { flog.For("7_health").Info("source file initialized"); return true }()
