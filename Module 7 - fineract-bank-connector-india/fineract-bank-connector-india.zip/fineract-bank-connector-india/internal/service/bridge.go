package service

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"context"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	"github.com/fineract/bank-connector-india/internal/domain"
	"github.com/fineract/bank-connector-india/internal/ports"
	"github.com/fineract/bank-connector-india/pkg/metrics"
	"github.com/fineract/bank-connector-india/pkg/utils"
)

// Bridge orchestrates the India sponsor-bank flow: debit-card authentication,
// IMPS initiation and OTP verification. It persists only masked, non-sensitive
// audit data and never logs PAN, PIN, CVV or OTP.
type Bridge struct {
	bank    ports.BankClient
	repo    ports.TransactionRepository // optional; nil disables persistence
	metrics *metrics.Metrics
	log     *zap.Logger
}

// NewBridge wires the service. repo may be nil when persistence is disabled.
func NewBridge(bank ports.BankClient, repo ports.TransactionRepository, m *metrics.Metrics, log *zap.Logger) *Bridge {
	return &Bridge{bank: bank, repo: repo, metrics: m, log: log}
}

// AuthenticateCard authenticates the customer's debit card.
func (b *Bridge) AuthenticateCard(ctx context.Context, req domain.CardAuthRequest) (*domain.CardAuthResult, error) {
	defer b.observe("card_auth")()
	if err := req.Validate(time.Now().UTC()); err != nil {
		return nil, b.fail("card_auth", err)
	}

	resp, err := b.bank.AuthenticateCard(ctx, req)
	if err != nil {
		return nil, b.fail("card_auth", err)
	}
	if !resp.Approved {
		return nil, b.fail("card_auth", domain.NewUnauthorizedError("card authentication declined: "+resp.Message, nil))
	}

	masked := utils.MaskCard(req.CardNumber)
	b.audit(ctx, &domain.Transaction{
		ID: uuid.NewString(), TransactionID: resp.AuthReference, Type: domain.TxnCardAuth,
		Status: domain.StatusSuccess, MaskedCard: masked, Currency: domain.CurrencyINR,
		CreatedAt: time.Now().UTC(), UpdatedAt: time.Now().UTC(),
	})
	b.metrics.OpsTotal.WithLabelValues("card_auth", string(domain.StatusSuccess)).Inc()

	return &domain.CardAuthResult{AuthReference: resp.AuthReference, MaskedCard: masked, Status: domain.StatusSuccess}, nil
}

// InitiateTransfer starts an IMPS transfer. The bank dispatches an OTP; the
// transfer completes only after VerifyOTP.
func (b *Bridge) InitiateTransfer(ctx context.Context, req domain.ImpsTransferRequest) (*domain.OperationResult, error) {
	defer b.observe("imps_initiate")()
	if err := req.Validate(); err != nil {
		return nil, b.fail("imps_initiate", err)
	}

	// Idempotency: return the prior result for a repeated reference id.
	if b.repo != nil {
		if existing, err := b.repo.GetByReferenceID(ctx, req.ReferenceID); err == nil && existing != nil {
			return &domain.OperationResult{TransactionID: existing.TransactionID, Status: existing.Status, UTR: existing.UTR}, nil
		}
	}

	resp, err := b.bank.InitiateIMPS(ctx, req)
	if err != nil {
		return nil, b.fail("imps_initiate", err)
	}

	status := domain.StatusOTPRequired
	if !resp.OTPRequired {
		status = domain.StatusPending
	}

	now := time.Now().UTC()
	b.audit(ctx, &domain.Transaction{
		ID: uuid.NewString(), ReferenceID: req.ReferenceID, TransactionID: resp.TransactionID,
		Type: domain.TxnIMPS, Status: status, Amount: req.Amount, Currency: domain.CurrencyINR,
		BeneficiaryAcct: utils.MaskAccount(req.BeneficiaryAcct), BeneficiaryIFSC: req.BeneficiaryIFSC,
		CreatedAt: now, UpdatedAt: now,
	})

	b.metrics.OpsTotal.WithLabelValues("imps_initiate", string(status)).Inc()
	return &domain.OperationResult{TransactionID: resp.TransactionID, Status: status, Message: resp.Message}, nil
}

// VerifyOTP confirms a pending transfer and returns the UTR on success.
func (b *Bridge) VerifyOTP(ctx context.Context, req domain.OtpVerifyRequest) (*domain.OperationResult, error) {
	defer b.observe("otp_verify")()
	if err := req.Validate(); err != nil {
		return nil, b.fail("otp_verify", err)
	}

	resp, err := b.bank.VerifyOTP(ctx, req.TransactionID, req.OTP)
	if err != nil {
		return nil, b.fail("otp_verify", err)
	}
	if !resp.Approved {
		b.setStatusByTxnID(ctx, req.TransactionID, domain.StatusFailed, "", "otp declined")
		b.metrics.OpsTotal.WithLabelValues("otp_verify", string(domain.StatusFailed)).Inc()
		return &domain.OperationResult{TransactionID: req.TransactionID, Status: domain.StatusFailed, Message: resp.Message}, nil
	}

	b.setStatusByTxnID(ctx, req.TransactionID, domain.StatusSuccess, resp.UTR, "")
	b.metrics.OpsTotal.WithLabelValues("otp_verify", string(domain.StatusSuccess)).Inc()
	return &domain.OperationResult{TransactionID: req.TransactionID, Status: domain.StatusSuccess, UTR: resp.UTR}, nil
}

// GetStatus returns the current state of a transaction, preferring the local
// record and falling back to the bank.
func (b *Bridge) GetStatus(ctx context.Context, transactionID string) (*domain.OperationResult, error) {
	defer b.observe("status")()
	if b.repo != nil {
		if rec, err := b.repo.GetByTransactionID(ctx, transactionID); err == nil && rec != nil {
			return &domain.OperationResult{TransactionID: rec.TransactionID, Status: rec.Status, UTR: rec.UTR}, nil
		}
	}
	resp, err := b.bank.GetStatus(ctx, transactionID)
	if err != nil {
		return nil, b.fail("status", err)
	}
	return &domain.OperationResult{TransactionID: resp.TransactionID, Status: resp.Status, UTR: resp.UTR, Message: resp.Message}, nil
}

// ---- helpers ----

func (b *Bridge) observe(op string) func() {
	start := time.Now()
	return func() { b.metrics.OpDuration.WithLabelValues(op).Observe(time.Since(start).Seconds()) }
}

func (b *Bridge) fail(op string, err error) error {
	de := domain.AsDomainError(err)
	b.metrics.OpErrorsTotal.WithLabelValues(op, string(de.Code)).Inc()
	b.log.Warn("bank operation failed", zap.String("op", op), zap.String("code", string(de.Code)), zap.Error(err))
	return de
}

func (b *Bridge) audit(ctx context.Context, rec *domain.Transaction) {
	if b.repo == nil {
		return
	}
	if err := b.repo.Save(ctx, rec); err != nil {
		b.log.Error("failed to persist transaction", zap.Error(err))
	}
}

func (b *Bridge) setStatusByTxnID(ctx context.Context, bankTxnID string, status domain.Status, utr, reason string) {
	if b.repo == nil {
		return
	}
	rec, err := b.repo.GetByTransactionID(ctx, bankTxnID)
	if err != nil || rec == nil {
		return
	}
	if err := b.repo.UpdateStatus(ctx, rec.ID, status, utr, reason); err != nil {
		b.log.Error("failed to update transaction status", zap.Error(err))
	}
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_bridge_Logfile.log at runtime.
var _ = func() bool { flog.For("7_bridge").Info("source file initialized"); return true }()
