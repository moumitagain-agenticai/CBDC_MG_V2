# EXPLANATION — fineract-bank-connector-india (plain language)

This document explains the module in simple terms, for reviewers who are not Go
engineers.

## What is this module for?

The CBDC connectors (Modules 2–4) move digital currency. But cross-border
payments still need to touch the ordinary banking system — real rupee accounts
at a partner ("sponsor") bank in India. This module is the **bridge to that
India sponsor bank**. It lets the platform move money over **IMPS** (India's
instant bank-to-bank transfer network) after confirming the customer with their
**debit card** and a **one-time password (OTP)**.

## The three steps

Sending money through the sponsor bank happens in three steps, mirroring how
Indian banks protect a transfer:

1. **Authenticate the debit card.** The customer proves who they are with their
   card number, expiry and PIN. The bank confirms and gives us an "auth
   reference".
2. **Start the IMPS transfer.** We tell the bank the amount and the
   beneficiary. The bank doesn't move the money yet — it sends a **one-time
   password** to the customer's mobile and replies "OTP required".
3. **Verify the OTP.** The customer enters the code; we pass it to the bank; the
   bank executes the transfer and returns a **UTR** — the official reference
   number that proves the transfer happened.

## The most important design choice: protect sensitive data

Card numbers, PINs and OTPs are extremely sensitive. This module is built so
that it **never writes them to the database and never writes them to logs**.
They are passed straight to the bank and then forgotten. Anything we keep or
show is **masked** — for example a card becomes `************1111`, showing only
the last four digits. If you search the logs for a card number, you will find
nothing. (This is verified: a live run found **zero** occurrences of the test
card number in the logs.)

## Guarding against mistakes

Before we ever call the bank, we check the request:

- The card number must pass the standard checksum and not be expired.
- The transfer amount must be positive and **not exceed ₹5,00,000**, which is
  the limit for a single IMPS transfer.
- The beneficiary must be identified correctly — either an account number plus
  its IFSC branch code, or an MMID plus mobile number.
- The OTP must look like a real 4–6 digit code.

If any check fails, we reject the request immediately with a clear message and
never bother the bank.

## Not paying twice

Every transfer carries a "reference id". If the same request is sent again (say
the network hiccuped and the caller retried), we recognise the reference id and
return the original result instead of sending the money a second time. This is
called **idempotency**.

## Coping when the bank is slow or down

Talking to the bank is wrapped in safety mechanisms: a **timeout** (don't wait
forever), **automatic retries** for brief blips, and a **circuit breaker** that
stops hammering the bank if it is clearly down and fails fast instead. Callers
always get a clear, typed error rather than a hang.

## The reliability features, in one line each

- **Two-factor flow**: card authentication + OTP before any money moves.
- **Masking**: only the last four digits of cards/accounts are ever stored/shown.
- **No sensitive logging**: PAN, PIN, CVV and OTP never reach logs or the database.
- **Validation**: bad cards, over-limit amounts and malformed inputs are stopped early.
- **Idempotency**: the same reference id never sends money twice.
- **Circuit breaker + retries**: shrug off blips, fail over fast on outages.
- **Optional audit trail**: masked transaction records in Postgres.
- **Graceful shutdown**: on stop, in-flight requests finish before exit.

## What was verified

`go build ./...`, `go vet ./...`, unit tests (card auth approved/declined/
expired; IMPS initiation requires OTP; beneficiary masked; idempotency;
over-limit rejected; OTP success returns UTR; bad OTP rejected) and integration
tests (the full card → IMPS → OTP → UTR flow over a real HTTP bank, asserting
the masked card) all pass. A running instance also rejected an over-limit
transfer with `400`, and a scan of its logs found **zero** occurrences of the
card number.
