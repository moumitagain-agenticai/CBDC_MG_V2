package utils

import "github.com/fineract/bank-connector-india/pkg/flog"
import (
	"math/big"
	"regexp"
	"strings"
)

var (
	ifscRe   = regexp.MustCompile(`^[A-Z]{4}0[A-Z0-9]{6}$`) // 11 chars, 5th is '0'
	acctRe   = regexp.MustCompile(`^[0-9]{9,18}$`)
	otpRe    = regexp.MustCompile(`^[0-9]{4,6}$`)
	mobileRe = regexp.MustCompile(`^[6-9][0-9]{9}$`) // Indian mobile
	mmidRe   = regexp.MustCompile(`^[0-9]{7}$`)
	digitsRe = regexp.MustCompile(`^[0-9]+$`)
)

// IsValidIFSC reports whether s is a syntactically valid IFSC code.
func IsValidIFSC(s string) bool { return ifscRe.MatchString(strings.ToUpper(strings.TrimSpace(s))) }

// IsValidAccountNumber reports whether s is a plausible bank account number.
func IsValidAccountNumber(s string) bool { return acctRe.MatchString(strings.TrimSpace(s)) }

// IsValidOTP reports whether s is a 4–6 digit OTP.
func IsValidOTP(s string) bool { return otpRe.MatchString(strings.TrimSpace(s)) }

// IsValidMobile reports whether s is a valid 10-digit Indian mobile number.
func IsValidMobile(s string) bool { return mobileRe.MatchString(strings.TrimSpace(s)) }

// IsValidMMID reports whether s is a valid 7-digit MMID.
func IsValidMMID(s string) bool { return mmidRe.MatchString(strings.TrimSpace(s)) }

// LuhnValid reports whether the digit string passes the Luhn checksum. Used to
// sanity-check a card number's format (not to validate that a card exists).
func LuhnValid(number string) bool {
	number = strings.ReplaceAll(strings.TrimSpace(number), " ", "")
	if len(number) < 12 || len(number) > 19 || !digitsRe.MatchString(number) {
		return false
	}
	sum := 0
	double := false
	for i := len(number) - 1; i >= 0; i-- {
		d := int(number[i] - '0')
		if double {
			d *= 2
			if d > 9 {
				d -= 9
			}
		}
		sum += d
		double = !double
	}
	return sum%10 == 0
}

// MaskCard returns a masked PAN keeping only the last four digits, e.g.
// "************1234". It never returns the full number.
func MaskCard(number string) string {
	number = strings.ReplaceAll(strings.TrimSpace(number), " ", "")
	if len(number) < 4 {
		return "****"
	}
	return strings.Repeat("*", len(number)-4) + number[len(number)-4:]
}

// MaskAccount masks all but the last four digits of an account number.
func MaskAccount(acct string) string {
	acct = strings.TrimSpace(acct)
	if len(acct) < 4 {
		return "****"
	}
	return strings.Repeat("*", len(acct)-4) + acct[len(acct)-4:]
}

// IsPositiveAmount reports whether s is a positive decimal with ≤ 2 fraction
// digits (INR paise precision).
func IsPositiveAmount(s string) bool {
	s = strings.TrimSpace(s)
	r, ok := new(big.Rat).SetString(s)
	if !ok || r.Sign() <= 0 {
		return false
	}
	if dot := strings.IndexByte(s, '.'); dot >= 0 && len(s)-dot-1 > 2 {
		return false
	}
	return true
}

// AmountAtMost reports whether amount <= limit (both decimal strings).
func AmountAtMost(amount, limit string) bool {
	a, ok := new(big.Rat).SetString(strings.TrimSpace(amount))
	if !ok {
		return false
	}
	l, ok := new(big.Rat).SetString(strings.TrimSpace(limit))
	if !ok {
		return false
	}
	return a.Cmp(l) <= 0
}

// flogMarker registers this source file with the Logrus per-file logger,
// producing logs/7_validators_Logfile.log at runtime.
var _ = func() bool { flog.For("7_validators").Info("source file initialized"); return true }()
